/* ============================================================
   MCPE ADDONS STORE V2 – Main Application Logic
   Google Auth + Hamburger Menu + Real-time Data + 0 Initial Data
   ============================================================ */

'use strict';

// ─── State ───────────────────────────────────────────────────
const State = {
  user:            null,
  addons:          [],
  filteredAddons:  [],
  currentCategory: 'all',
  currentPlatform: 'all',
  searchQuery:     '',
  page:            1,
  perPage:         12,
  currentAddon:    null,
  purchases:       [],
};

// Subidas de usuario en memoria (data URLs)
let _upImage = null, _upFile = null, _upFileName = null;
let _profAvatar = null, _profFrame = 'none';

// ─── DOM Ready ────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initLoadingScreen();
  initParticles();
  initNavbar();
  initSheetDrag();
  initGoogleAuth();
  initScrollReveal();
  initTypingEffect();
  loadAddons();
  updateStats();
  restoreSession();
  listenRealtime();
  renderPlans();
  populateUploadTypes();
});

/* ============================================================
   LOADING SCREEN
   ============================================================ */
function initLoadingScreen() {
  const fill = document.getElementById('loading-bar-fill');
  let progress = 0;
  const iv = setInterval(() => {
    progress += Math.random() * 18;
    if (progress >= 100) {
      progress = 100;
      clearInterval(iv);
      setTimeout(() => {
        document.getElementById('loading-screen').classList.add('hidden');
      }, 300);
    }
    fill.style.width = progress + '%';
  }, 120);
}

/* ============================================================
   PARTICLES CANVAS
   ============================================================ */
function initParticles() {
  const canvas = document.getElementById('particles-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let W, H, particles = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const COLORS = ['#00d4ff', '#7c3aed', '#a78bfa', '#f59e0b', '#10b981'];

  class Particle {
    constructor() { this.reset(true); }
    reset(init = false) {
      this.x    = Math.random() * W;
      this.y    = init ? Math.random() * H : H + 10;
      this.size = Math.random() * 2 + 0.5;
      this.speedY = -(Math.random() * 0.4 + 0.1);
      this.speedX =  (Math.random() - 0.5) * 0.2;
      this.alpha  = Math.random() * 0.5 + 0.1;
      this.color  = COLORS[Math.floor(Math.random() * COLORS.length)];
    }
    update() {
      this.x += this.speedX;
      this.y += this.speedY;
      if (this.y < -20) this.reset();
    }
    draw() {
      ctx.globalAlpha = this.alpha;
      ctx.fillStyle   = this.color;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  for (let i = 0; i < 80; i++) particles.push(new Particle());

  function animate() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => { p.update(); p.draw(); });
    ctx.globalAlpha = 1;
    requestAnimationFrame(animate);
  }
  animate();
}

/* ============================================================
   NAVBAR (scroll behavior)
   ============================================================ */
function initNavbar() {
  const navbar = document.getElementById('navbar');
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 40);
    // Highlight active nav link
    const sections = ['hero','addons','featured','pricing','contact'];
    let current = '';
    sections.forEach(id => {
      const el = document.getElementById(id);
      if (el && window.scrollY >= el.offsetTop - 100) current = id;
    });
    document.querySelectorAll('.nav-link').forEach(l => {
      l.classList.toggle('active', l.getAttribute('href') === '#' + current);
    });
  });
}

/* ============================================================
   HAMBURGER MENU
   ============================================================ */
function toggleHamburger() {
  const btn     = document.getElementById('hamburger-btn');
  const menu    = document.getElementById('nav-menu');
  const overlay = document.getElementById('mobile-menu-overlay');

  const isOpen = menu.classList.contains('open');

  if (isOpen) {
    closeHamburger();
  } else {
    btn.classList.add('open');
    menu.classList.add('open');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}

function closeHamburger() {
  const btn     = document.getElementById('hamburger-btn');
  const menu    = document.getElementById('nav-menu');
  const overlay = document.getElementById('mobile-menu-overlay');

  btn.classList.remove('open');
  menu.classList.remove('open');
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}

/* ============================================================
   MENÚ MÓVIL v6.0 — Bottom sheet deslizable y profesional
   ============================================================ */
function renderSheet() {
  const body = document.getElementById('msheet-body');
  if (!body) return;
  const u = State.user;

  const links = `
    <nav class="msheet-links">
      <a href="#hero" onclick="closeSheet()"><i class="fas fa-house"></i> Inicio</a>
      <a href="#addons" onclick="closeSheet()"><i class="fas fa-puzzle-piece"></i> Add-ons</a>
      <a href="#featured" onclick="closeSheet()"><i class="fas fa-fire"></i> Destacados</a>
      <a href="#pricing" onclick="closeSheet()"><i class="fas fa-crown"></i> Planes</a>
      <a href="#contact" onclick="closeSheet()"><i class="fas fa-envelope"></i> Contacto</a>
      <a href="admin.html" class="msheet-admin"><i class="fas fa-user-shield"></i> Panel Admin</a>
    </nav>`;

  let userSection;
  if (u) {
    userSection = `
      <div class="msheet-user">
        <img class="msheet-avatar ${frameClass(u.frame)}" src="${escHtml(userAvatar(u))}" alt="" onerror="this.style.opacity=0" />
        <div class="msheet-user-info">
          <strong>${escHtml(userDisplayName(u))}</strong>
          <small>${escHtml(u.email || '')}</small>
        </div>
      </div>
      <div class="msheet-actions">
        <button class="btn btn-primary btn-full" onclick="closeSheet();openUploadModal()"><i class="fas fa-cloud-arrow-up"></i> Subir Add-on</button>
        <button class="btn btn-outline btn-full" onclick="closeSheet();openProfileModal()"><i class="fas fa-id-badge"></i> Mi Perfil</button>
        <button class="btn btn-outline btn-full" onclick="closeSheet();openPurchasesModal()"><i class="fas fa-box"></i> Mis Compras</button>
        <button class="btn btn-ghost btn-full logout-link" onclick="closeSheet();logout()"><i class="fas fa-sign-out-alt"></i> Cerrar sesión</button>
      </div>`;
  } else {
    userSection = `
      <div class="msheet-actions">
        <button class="btn btn-primary btn-full btn-glow" onclick="closeSheet();openAuthModal('login')"><i class="fab fa-google"></i> Iniciar sesión con Google</button>
      </div>`;
  }

  body.innerHTML = links + '<div class="msheet-divider"></div>' + userSection;
}

function openSheet() {
  renderSheet();
  const sheet = document.getElementById('msheet');
  const bd = document.getElementById('sheet-backdrop');
  if (!sheet) return;
  sheet.style.transform = '';
  sheet.classList.add('open');
  bd.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeSheet() {
  const sheet = document.getElementById('msheet');
  const bd = document.getElementById('sheet-backdrop');
  if (!sheet) return;
  sheet.classList.remove('open');
  bd.classList.remove('open');
  sheet.style.transform = '';
  document.body.style.overflow = '';
}

function initSheetDrag() {
  const sheet = document.getElementById('msheet');
  const grip  = document.getElementById('msheet-grip');
  const body  = document.getElementById('msheet-body');
  if (!sheet) return;

  let sy = 0, dy = 0, dragging = false, fromGrip = false;

  function start(y, isGrip) {
    sy = y; dy = 0; dragging = true; fromGrip = !!isGrip;
    sheet.style.transition = 'none';
  }
  function move(y) {
    if (!dragging) return;
    dy = y - sy;
    const atTop = !body || body.scrollTop <= 0;
    // Solo se cierra arrastrando hacia abajo (desde el grip, o desde arriba del contenido)
    if (dy > 0 && (fromGrip || atTop)) {
      sheet.style.transform = `translateY(${dy}px)`;
    } else if (dy < 0) {
      sheet.style.transform = '';
    }
  }
  function end() {
    if (!dragging) return;
    dragging = false;
    sheet.style.transition = '';
    if (dy > 110) closeSheet();
    else sheet.style.transform = '';
  }

  // Touch (móvil)
  sheet.addEventListener('touchstart', e => start(e.touches[0].clientY, e.target === grip), { passive: true });
  sheet.addEventListener('touchmove',  e => move(e.touches[0].clientY), { passive: true });
  sheet.addEventListener('touchend', end);
  sheet.addEventListener('touchcancel', end);

  // Mouse en el grip (para escritorio/pruebas)
  grip.addEventListener('mousedown', e => {
    start(e.clientY, true); e.preventDefault();
    const mm = ev => move(ev.clientY);
    const mu = () => { end(); document.removeEventListener('mousemove', mm); document.removeEventListener('mouseup', mu); };
    document.addEventListener('mousemove', mm);
    document.addEventListener('mouseup', mu);
  });

  // Cerrar con tecla Escape
  window.addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });
}

/* ============================================================
   USER DROPDOWN (Desktop)
   ============================================================ */
function toggleUserDropdown() {
  const dd  = document.getElementById('user-dropdown');
  const btn = document.querySelector('.user-avatar-btn');
  dd.classList.toggle('open');
  btn.classList.toggle('open');
}

document.addEventListener('click', e => {
  if (!e.target.closest('.user-avatar-btn') && !e.target.closest('.user-dropdown')) {
    document.getElementById('user-dropdown')?.classList.remove('open');
    document.querySelector('.user-avatar-btn')?.classList.remove('open');
  }
});

/* ============================================================
   TYPING EFFECT
   ============================================================ */
function initTypingEffect() {
  const words = ['Add-ons', 'Texturas', 'Mapas', 'Mods', 'Skins'];
  const el    = document.getElementById('typing-text');
  if (!el) return;
  let wi = 0, ci = 0, deleting = false;

  function tick() {
    const word = words[wi];
    if (deleting) {
      el.textContent = word.substring(0, ci--);
      if (ci < 0) { deleting = false; wi = (wi + 1) % words.length; setTimeout(tick, 400); return; }
    } else {
      el.textContent = word.substring(0, ci++);
      if (ci > word.length) { deleting = true; setTimeout(tick, 1800); return; }
    }
    setTimeout(tick, deleting ? 60 : 110);
  }
  tick();
}

/* ============================================================
   SCROLL REVEAL
   ============================================================ */
function initScrollReveal() {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
  }, { threshold: 0.1 });

  document.querySelectorAll('.section-header, .feature-item, .pricing-card').forEach(el => {
    el.classList.add('reveal');
    obs.observe(el);
  });
}

/* ============================================================
   STATS (Real values from DB - starts at 0)
   ============================================================ */
function updateStats() {
  const all     = DB.get(DB_KEYS.ADDONS);
  const addons  = all.filter(a => a.status !== 'pending' && a.status !== 'rejected');
  const users   = DB.get(DB_KEYS.USERS);
  const totalDl = addons.reduce((s, a) => s + (a.downloads || 0), 0);

  document.getElementById('stat-addons').textContent    = addons.length;
  document.getElementById('stat-users').textContent     = users.length;
  document.getElementById('stat-downloads').textContent = totalDl;
}

/* ============================================================
   GOOGLE AUTH
   ============================================================ */
function initGoogleAuth() {
  if (typeof google === 'undefined') {
    setTimeout(initGoogleAuth, 500);
    return;
  }
  google.accounts.id.initialize({
    client_id: GOOGLE_CLIENT_ID,
    callback:  handleGoogleCredential,
    auto_select: false,
    cancel_on_tap_outside: true,
  });

  google.accounts.id.renderButton(
    document.getElementById('google-signin-btn'),
    {
      theme:   'filled_black',
      size:    'large',
      shape:   'pill',
      text:    'signin_with',
      width:   280,
    }
  );
}

function handleGoogleCredential(response) {
  try {
    const payload = parseJwt(response.credential);
    const user = {
      id:      payload.sub,
      name:    payload.name,
      email:   payload.email,
      avatar:  payload.picture,
      token:   response.credential,
      loginAt: Date.now(),
    };
    loginUser(user);
  } catch (err) {
    showToast('Error al iniciar sesión. Intenta de nuevo.', 'error');
    console.error(err);
  }
}

function parseJwt(token) {
  const base64 = token.split('.')[1].replace(/-/g,'+').replace(/_/g,'/');
  return JSON.parse(atob(base64));
}

function loginUser(user) {
  // Conservar datos de perfil existentes (plan, marco, país, bio, etc.)
  const users = DB.get(DB_KEYS.USERS);
  const idx   = users.findIndex(u => u.id === user.id);
  const existing = idx !== -1 ? users[idx] : {};
  const merged = { ...existing, ...user };
  merged.plan        = existing.plan        || 'free';
  merged.frame       = existing.frame       || 'none';
  merged.country     = existing.country     || '';
  merged.bio         = existing.bio         || '';
  if (existing.displayName)  merged.displayName  = existing.displayName;
  if (existing.customAvatar) merged.customAvatar = existing.customAvatar;

  State.user = merged;
  localStorage.setItem('mcpe_current_user', JSON.stringify(merged));

  if (idx === -1) users.push(merged); else users[idx] = merged;
  DB.set(DB_KEYS.USERS, users);

  updateAuthUI(merged);
  closeModal('auth-modal');
  showToast(`¡Bienvenido, ${userDisplayName(merged)}!`, 'success');
  loadPurchases();
  updateStats();
  renderPlans();
}

function restoreSession() {
  try {
    const saved = localStorage.getItem('mcpe_current_user');
    if (saved) {
      const user = JSON.parse(saved);
      if (Date.now() - user.loginAt < 7 * 24 * 3600 * 1000) {
        State.user = user;
        updateAuthUI(user);
        loadPurchases();
      } else {
        localStorage.removeItem('mcpe_current_user');
      }
    }
  } catch { localStorage.removeItem('mcpe_current_user'); }
}

function updateAuthUI(user) {
  const av    = userAvatar(user);
  const dname = userDisplayName(user);
  const fcls  = frameClass(user.frame);

  // Mobile menu
  document.getElementById('logged-out-btns').style.display = 'none';
  document.getElementById('logged-in-btns').style.display  = 'block';
  const mAv = document.getElementById('menu-user-avatar');
  mAv.src = av; mAv.className = 'user-avatar-small ' + fcls;
  document.getElementById('menu-user-name').textContent   = dname;
  document.getElementById('menu-user-email').textContent  = user.email;

  // Desktop
  document.getElementById('desktop-logged-out').style.display = 'none';
  document.getElementById('desktop-logged-in').style.display  = 'flex';
  const nAv = document.getElementById('nav-user-avatar');
  nAv.src = av; nAv.className = 'user-avatar-small ' + fcls;
  document.getElementById('nav-user-name').textContent   = dname.split(' ')[0];
  const dAv = document.getElementById('dropdown-avatar');
  dAv.src = av; dAv.className = fcls;
  document.getElementById('dropdown-name').textContent   = dname;
  document.getElementById('dropdown-email').textContent  = user.email;
}

function logout() {
  State.user = null;
  localStorage.removeItem('mcpe_current_user');

  // Mobile menu
  document.getElementById('logged-out-btns').style.display = 'block';
  document.getElementById('logged-in-btns').style.display  = 'none';

  // Desktop
  document.getElementById('desktop-logged-out').style.display = 'block';
  document.getElementById('desktop-logged-in').style.display  = 'none';
  document.getElementById('user-dropdown').classList.remove('open');

  if (typeof google !== 'undefined') google.accounts.id.disableAutoSelect();
  showToast('Sesión cerrada correctamente', 'info');
  renderPlans();
}

/* ============================================================
   MODALS
   ============================================================ */
function openModal(id) {
  document.getElementById(id)?.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
  document.body.style.overflow = '';
}

window.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      m.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});

document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) {
      overlay.classList.remove('open');
      document.body.style.overflow = '';
    }
  });
});

function openAuthModal(mode = 'login') {
  const title    = document.getElementById('auth-modal-title');
  const subtitle = document.getElementById('auth-modal-subtitle');
  if (mode === 'login') {
    title.textContent    = 'Bienvenido de vuelta';
    subtitle.textContent = 'Inicia sesión para descargar add-ons premium';
  } else {
    title.textContent    = 'Crear cuenta';
    subtitle.textContent = 'Únete a miles de usuarios de MCPE';
  }
  openModal('auth-modal');
}

function openPurchasesModal() {
  document.getElementById('user-dropdown')?.classList.remove('open');
  renderPurchases();
  openModal('purchases-modal');
}

/* ============================================================
   LOAD ADDONS (Real-time from localStorage - starts empty)
   ============================================================ */
function loadAddons() {
  const addons = DB.get(DB_KEYS.ADDONS);
  State.addons = addons;
  applyFilters();
}

function listenRealtime() {
  window.addEventListener('db-updated', e => {
    if (e.detail.key === DB_KEYS.ADDONS) {
      State.addons = e.detail.data;
      applyFilters();
      updateStats();
    }
  });
  // Poll every 3s for cross-tab updates
  setInterval(() => {
    const fresh = DB.get(DB_KEYS.ADDONS);
    if (JSON.stringify(fresh) !== JSON.stringify(State.addons)) {
      State.addons = fresh;
      applyFilters();
      updateStats();
    }
  }, 3000);
}

function applyFilters() {
  // Solo se muestran add-ons aprobados (los pendientes/rechazados se ocultan).
  // Los add-ons sin estado (legacy o del admin) se consideran visibles.
  let list = State.addons.filter(a => a.status !== 'pending' && a.status !== 'rejected');

  // Platform filter
  if (State.currentPlatform !== 'all') {
    list = list.filter(a => (a.platform || 'bedrock') === State.currentPlatform);
  }

  // Category / content-type filter
  const cat = State.currentCategory;
  if (cat === 'free')         list = list.filter(a => a.price == 0 || a.price === '0');
  else if (cat === 'premium') list = list.filter(a => parseFloat(a.price) > 0);
  else if (cat !== 'all')     list = list.filter(a => (a.contentType || a.category) === cat);

  // Search filter
  if (State.searchQuery) {
    const q = State.searchQuery.toLowerCase();
    list = list.filter(a =>
      a.name.toLowerCase().includes(q) ||
      (a.description || '').toLowerCase().includes(q) ||
      (a.category || '').toLowerCase().includes(q) ||
      (a.authorName || '').toLowerCase().includes(q)
    );
  }

  State.filteredAddons = list;
  State.page = 1;
  renderAddons();
  renderFeatured();
}

function setPlatform(p, btn) {
  State.currentPlatform = p;
  document.querySelectorAll('.ptab').forEach(c => c.classList.remove('active'));
  if (btn) btn.classList.add('active');
  applyFilters();
}

function setCategory(cat, btn) {
  State.currentCategory = cat;
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  applyFilters();
}

function filterAddons() {
  State.searchQuery = document.getElementById('search-input').value.trim();
  applyFilters();
}

/* ============================================================
   RENDER ADDONS GRID
   ============================================================ */
function renderAddons() {
  const grid  = document.getElementById('addons-grid');
  const empty = document.getElementById('empty-state');
  const more  = document.getElementById('load-more-wrap');

  const visible = State.filteredAddons.slice(0, State.page * State.perPage);

  if (State.filteredAddons.length === 0) {
    empty.style.display = 'block';
    grid.innerHTML = '';
    grid.appendChild(empty);
    more.style.display = 'none';
    return;
  }

  empty.style.display = 'none';
  grid.innerHTML = '';

  visible.forEach((addon, i) => {
    const card = buildAddonCard(addon, i);
    grid.appendChild(card);
  });

  more.style.display = State.filteredAddons.length > visible.length ? 'block' : 'none';
}

function buildAddonCard(addon, index) {
  const el   = document.createElement('div');
  el.className = 'addon-card';
  el.style.animationDelay = `${index * 0.05}s`;

  const isFree    = !addon.price || parseFloat(addon.price) === 0;
  const price     = isFree ? 'Gratis' : `$${parseFloat(addon.price).toFixed(2)}`;
  const priceClass = isFree ? 'free' : 'premium';

  el.innerHTML = `
    ${addon.image
      ? `<img class="addon-card-img" src="${escHtml(addon.image)}" alt="${escHtml(addon.name)}" loading="lazy" onerror="this.outerHTML='<div class=addon-card-img-placeholder>&#9638;</div>'" />`
      : `<div class="addon-card-img-placeholder">${addon.emoji ? escHtml(addon.emoji) : '<i class=\"fas fa-cube\"></i>'}</div>`
    }
    <div class="addon-card-body">
      <div class="addon-card-badges">
        <span class="badge ${isFree ? 'badge-free' : 'badge-premium'}">${isFree ? '<i class="fas fa-gift"></i> Gratis' : '<i class="fas fa-crown"></i> Premium'}</span>
        ${addon.platform ? `<span class="badge badge-platform"><i class="fas ${addon.platform === 'java' ? 'fa-desktop' : 'fa-mobile-screen-button'}"></i> ${platformShort(addon.platform)}</span>` : ''}
        ${(addon.contentType || addon.category) ? `<span class="badge badge-category">${escHtml(typeName(addon.contentType || addon.category))}</span>` : ''}
        ${addon.isNew     ? '<span class="badge badge-new"><i class="fas fa-certificate"></i> Nuevo</span>' : ''}
        ${addon.isFeatured? '<span class="badge badge-hot"><i class="fas fa-fire"></i> Top</span>'  : ''}
      </div>
      <h3 class="addon-card-title">${escHtml(addon.name)}</h3>
      <p class="addon-card-desc">${escHtml(addon.description || 'Sin descripción disponible.')}</p>
      ${addon.authorName ? `<div class="addon-card-author"><i class="fas fa-user"></i> ${escHtml(addon.authorName)}</div>` : ''}
      <div class="addon-card-meta">
        <span class="addon-card-price ${priceClass}">${price}</span>
        <span class="addon-card-downloads">
          <i class="fas fa-download"></i> ${(addon.downloads || 0).toLocaleString()}
        </span>
      </div>
    </div>
    <div class="addon-card-actions">
      <button class="btn btn-outline btn-sm" onclick="openAddonDetail('${addon.id}')">
        <i class="fas fa-info-circle"></i> Detalles
      </button>
      ${isFree
        ? `<button class="btn btn-success btn-sm" onclick="downloadAddon(event,'${addon.id}')">
             <i class="fas fa-download"></i> Descargar
           </button>`
        : `<button class="btn btn-gold btn-sm" onclick="openAddonDetail('${addon.id}')">
             <i class="fas fa-crown"></i> Comprar
           </button>`
      }
    </div>
  `;
  return el;
}

function loadMore() {
  State.page++;
  renderAddons();
}

/* ============================================================
   RENDER FEATURED
   ============================================================ */
function renderFeatured() {
  const container = document.getElementById('featured-slider');
  const featured  = State.addons.filter(a => a.isFeatured && a.status !== 'pending' && a.status !== 'rejected');

  if (featured.length === 0) {
    container.innerHTML = `
      <div class="no-featured">
        <i class="fas fa-star"></i>
        <p>Los add-ons destacados aparecerán aquí</p>
      </div>`;
    return;
  }

  container.innerHTML = '';
  featured.forEach(addon => {
    const isFree = !addon.price || parseFloat(addon.price) === 0;
    const card   = document.createElement('div');
    card.className = 'featured-card';
    card.onclick = () => openAddonDetail(addon.id);
    card.innerHTML = `
      ${addon.image
        ? `<img class="featured-card-img" src="${escHtml(addon.image)}" alt="${escHtml(addon.name)}" loading="lazy" onerror="this.style.display='none'" />`
        : `<div class="featured-card-img" style="background:linear-gradient(135deg,var(--bg-card2),rgba(0,212,255,.05));display:flex;align-items:center;justify-content:center;font-size:4rem">${addon.emoji ? escHtml(addon.emoji) : '<i class=\"fas fa-cube\"></i>'}</div>`
      }
      <div class="featured-badge"><i class="fas fa-star"></i> Destacado</div>
      <div class="featured-card-body">
        <h3 class="featured-card-title">${escHtml(addon.name)}</h3>
        <p style="color:var(--text-muted);font-size:.85rem;margin:.4rem 0 .8rem">${escHtml(addon.description||'').substring(0,80)}…</p>
        <div style="display:flex;align-items:center;justify-content:space-between">
          <span class="featured-card-price">${isFree ? '<i class="fas fa-gift"></i> Gratis' : `<i class="fas fa-dollar-sign"></i> $${parseFloat(addon.price).toFixed(2)}`}</span>
          <span class="btn btn-primary btn-sm">Ver más</span>
        </div>
      </div>`;
    container.appendChild(card);
  });
}

/* ============================================================
   ADDON DETAIL MODAL
   ============================================================ */
function openAddonDetail(id) {
  const addon = State.addons.find(a => a.id === id);
  if (!addon) return;
  State.currentAddon = addon;

  const isFree = !addon.price || parseFloat(addon.price) === 0;
  const inner  = document.getElementById('addon-modal-inner');

  inner.innerHTML = `
    ${addon.image
      ? `<img class="addon-modal-img" src="${escHtml(addon.image)}" alt="${escHtml(addon.name)}" onerror="this.outerHTML='<div class=addon-modal-img-placeholder>${addon.emoji ? escHtml(addon.emoji) : '&#9638;'}</div>'" />`
      : `<div class="addon-modal-img-placeholder">${addon.emoji ? escHtml(addon.emoji) : '<i class=\"fas fa-cube\"></i>'}</div>`
    }
    <div class="addon-card-badges" style="margin-bottom:12px">
      <span class="badge ${isFree ? 'badge-free' : 'badge-premium'}">${isFree ? '<i class="fas fa-gift"></i> Gratis' : '<i class="fas fa-crown"></i> Premium'}</span>
      ${addon.isNew      ? '<span class="badge badge-new"><i class="fas fa-certificate"></i> Nuevo</span>'     : ''}
      ${addon.isFeatured ? '<span class="badge badge-hot"><i class="fas fa-fire"></i> Destacado</span>' : ''}
      ${addon.category   ? `<span class="badge badge-category">${escHtml(addon.category)}</span>` : ''}
    </div>
    <h2 class="addon-modal-title">${escHtml(addon.name)}</h2>
    <p class="addon-modal-desc">${escHtml(addon.description || 'Sin descripción disponible.')}</p>
    <div class="addon-modal-meta">
      <div class="addon-modal-meta-item"><i class="fas fa-download"></i> ${(addon.downloads||0).toLocaleString()} descargas</div>
      <div class="addon-modal-meta-item"><i class="fas fa-tag"></i> ${escHtml(addon.category || 'General')}</div>
      ${addon.version ? `<div class="addon-modal-meta-item"><i class="fas fa-code-branch"></i> v${escHtml(addon.version)}</div>` : ''}
      ${addon.mcVersion ? `<div class="addon-modal-meta-item"><i class="fas fa-cube"></i> MCPE ${escHtml(addon.mcVersion)}</div>` : ''}
    </div>

    <div class="addon-modal-price-row">
      <span class="addon-modal-price ${isFree ? 'free' : ''}">
        ${isFree ? '<i class="fas fa-gift"></i> Gratis' : `$${parseFloat(addon.price).toFixed(2)} USD`}
      </span>
    </div>

    <div id="addon-action-area" style="margin-top:16px"></div>
  `;

  renderAddonAction(addon, isFree);
  openModal('addon-modal');
}

function renderAddonAction(addon, isFree) {
  const area = document.getElementById('addon-action-area');
  if (!area) return;

  if (isFree) {
    area.innerHTML = `
      <button class="btn btn-success btn-full" onclick="downloadAddon(event,'${addon.id}')">
        <i class="fas fa-download"></i> Descargar Gratis
      </button>`;
    return;
  }

  // Check if already purchased
  if (hasPurchased(addon.id)) {
    area.innerHTML = `
      <div style="margin-bottom:12px;padding:12px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;text-align:center;color:var(--green)">
        <i class="fas fa-check-circle"></i> Ya tienes este add-on
      </div>
      <button class="btn btn-success btn-full" onclick="downloadAddon(event,'${addon.id}')">
        <i class="fas fa-download"></i> Descargar
      </button>`;
    return;
  }

  if (!State.user) {
    area.innerHTML = `
      <p style="text-align:center;color:var(--text-muted);margin-bottom:12px;font-size:.875rem">
        Inicia sesión para comprar
      </p>
      <button class="btn btn-primary btn-full" onclick="closeModal('addon-modal');openAuthModal('login')">
        <i class="fab fa-google"></i> Iniciar Sesión
      </button>`;
    return;
  }

  // PayPal button
  area.innerHTML = `
    <p style="text-align:center;color:var(--text-muted);margin-bottom:8px;font-size:.8rem">
      Pago 100% seguro con PayPal
    </p>
    <div id="paypal-button-container"></div>`;

  renderPayPalButton(addon);
}

/* ============================================================
   DOWNLOAD ADDON
   ============================================================ */
function downloadAddon(event, id) {
  if (event) event.stopPropagation();
  const addon = State.addons.find(a => a.id === id);
  if (!addon) return;

  // Increment download counter
  const addons = DB.get(DB_KEYS.ADDONS);
  const idx    = addons.findIndex(a => a.id === id);
  if (idx !== -1) {
    addons[idx].downloads = (addons[idx].downloads || 0) + 1;
    DB.set(DB_KEYS.ADDONS, addons);
  }

  if (addon.downloadUrl) {
    const link     = document.createElement('a');
    link.href      = addon.downloadUrl;
    link.download  = addon.downloadName || (addon.name + '.mcaddon');
    if (!/^data:/i.test(addon.downloadUrl)) {
      link.target = '_blank';
      link.rel    = 'noopener';
    }
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`Descargando ${addon.name}…`, 'success');
  } else {
    showToast('El enlace de descarga no está disponible aún.', 'warning');
  }

  updateStats();
}

/* ============================================================
   PURCHASES
   ============================================================ */
function loadPurchases() {
  if (!State.user) { State.purchases = []; return; }
  const orders = DB.get(DB_KEYS.ORDERS);
  State.purchases = orders.filter(o => o.userId === State.user.id && o.status === 'completed');
}

function hasPurchased(addonId) {
  return State.purchases.some(p => p.addonId === addonId);
}

function savePurchase(addon, paypalOrder) {
  const orders = DB.get(DB_KEYS.ORDERS);
  orders.push({
    id:        'ord_' + Date.now(),
    userId:    State.user.id,
    addonId:   addon.id,
    addonName: addon.name,
    price:     addon.price,
    currency:  'USD',
    paypalOrderId: paypalOrder.id,
    status:    'completed',
    date:      new Date().toISOString(),
  });
  DB.set(DB_KEYS.ORDERS, orders);
  loadPurchases();
}

function renderPurchases() {
  const list = document.getElementById('purchases-list');
  if (!State.user) {
    list.innerHTML = `<div class="empty-purchases"><i class="fas fa-lock"></i><p>Inicia sesión para ver tus compras</p></div>`;
    return;
  }
  if (State.purchases.length === 0) {
    list.innerHTML = `<div class="empty-purchases"><i class="fas fa-shopping-bag"></i><p>No tienes compras aún</p></div>`;
    return;
  }
  list.innerHTML = State.purchases.map(p => {
    const addon = State.addons.find(a => a.id === p.addonId);
    return `
      <div class="purchase-item">
        <div class="purchase-item-img">${addon?.emoji ? escHtml(addon.emoji) : '<i class="fas fa-cube"></i>'}</div>
        <div class="purchase-item-info">
          <div class="purchase-item-name">${escHtml(p.addonName)}</div>
          <div class="purchase-item-date">${new Date(p.date).toLocaleDateString('es-ES')}</div>
        </div>
        <div class="purchase-item-price">$${parseFloat(p.price).toFixed(2)}</div>
        <button class="btn btn-success btn-sm" onclick="downloadAddon(event,'${p.addonId}')">
          <i class="fas fa-download"></i>
        </button>
      </div>`;
  }).join('');
}

/* ============================================================
   TOAST NOTIFICATIONS
   ============================================================ */
function showToast(message, type = 'info', duration = 4000) {
  const container = document.getElementById('toast-container');
  const icons = { success: 'fa-check-circle', error: 'fa-times-circle', info: 'fa-info-circle', warning: 'fa-exclamation-circle' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="fas ${icons[type]} toast-icon"></i><span>${message}</span>`;
  toast.addEventListener('click', () => removeToast(toast));
  container.appendChild(toast);
  setTimeout(() => removeToast(toast), duration);
}

function removeToast(toast) {
  toast.classList.add('hide');
  setTimeout(() => toast.remove(), 300);
}

/* ============================================================
   UTILITY
   ============================================================ */
function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function generateId() {
  return 'addon_' + Date.now() + '_' + Math.random().toString(36).substr(2,6);
}

/* ============================================================
   V3.0 — Helpers de usuario, planes y marcos
   ============================================================ */
function userDisplayName(u){ return (u && (u.displayName || u.name)) || 'Usuario'; }
function userAvatar(u){ return (u && (u.customAvatar || u.avatar)) || ''; }
function frameClass(frameId){ return frameId && frameId !== 'none' ? ('av-frame av-' + frameId) : ''; }
function platformShort(id){ const p=(window.PLATFORMS||[]).find(x=>x.id===id); return p?p.short:id; }
function typeName(id){ const t=(window.CONTENT_TYPES||[]).find(x=>x.id===id); return t?t.name:id; }
function userPlanId(u){ return (u && u.plan) || 'free'; }
function flagRingHTML(radius, count){
  const list = (window.COUNTRIES || []);
  if (!list.length) return '';
  let html = '';
  for (let i = 0; i < count; i++){
    const c = list[i % list.length];
    const ang = (360 / count) * i;
    html += `<img class="ring-flag" src="${FLAG_URL(c.code)}" alt="" loading="lazy" style="transform:rotate(${ang}deg) translateY(-${radius}px) rotate(${-ang}deg)" />`;
  }
  return html;
}
function todayKey(){ return new Date().toISOString().slice(0,10); }
function countTodayUploads(userId){
  const today = todayKey();
  return DB.get(DB_KEYS.ADDONS).filter(a => a.authorId === userId && (a.createdAt||'').slice(0,10) === today).length;
}
function persistCurrentUser(){
  if (!State.user) return;
  localStorage.setItem('mcpe_current_user', JSON.stringify(State.user));
  const users = DB.get(DB_KEYS.USERS);
  const idx = users.findIndex(u => u.id === State.user.id);
  if (idx === -1) users.push(State.user); else users[idx] = { ...users[idx], ...State.user };
  DB.set(DB_KEYS.USERS, users);
  updateAuthUI(State.user);
}

/* ============================================================
   PLANES
   ============================================================ */
function renderPlans(){
  const grid = document.getElementById('plans-grid');
  if (!grid || !window.PLANS) return;
  const currentPlan = State.user ? userPlanId(State.user) : null;
  grid.innerHTML = window.PLANS.map(p => `
    <div class="plan-card ${p.popular ? 'plan-popular' : ''} ${currentPlan===p.id?'plan-current':''}" style="--plan-color:${p.color}">
      ${p.popular ? '<div class="plan-tag"><i class="fas fa-star"></i> Más popular</div>' : ''}
      ${currentPlan===p.id ? '<div class="plan-current-tag"><i class="fas fa-check"></i> Tu plan</div>' : ''}
      <div class="plan-icon"><i class="fas ${p.icon}"></i></div>
      <h3 class="plan-name">${p.name}</h3>
      <div class="plan-price">${p.price === 0 ? 'Gratis' : '$'+p.price.toFixed(2)}<span>${p.price===0?'':'/mes'}</span></div>
      <div class="plan-uploads"><i class="fas fa-cloud-arrow-up"></i> ${p.dailyUploads} add-ons por día</div>
      <ul class="plan-features">
        ${p.features.map(f => `<li><i class="fas fa-check"></i> ${escHtml(f)}</li>`).join('')}
      </ul>
      <button class="btn ${p.popular?'btn-primary btn-glow':'btn-outline'} btn-full" onclick="selectPlan('${p.id}')">
        ${currentPlan===p.id ? 'Plan actual' : (p.price===0 ? 'Usar Gratis' : 'Elegir '+p.name)}
      </button>
    </div>
  `).join('');
}

function selectPlan(planId){
  if (!State.user){ openAuthModal('login'); showToast('Inicia sesión para elegir un plan.', 'info'); return; }
  const plan = getPlanById(planId);
  if (planId === 'free'){
    State.user.plan = 'free';
    persistCurrentUser();
    renderPlans();
    showToast('Estás en el plan Gratis.', 'info');
    return;
  }
  if (userPlanId(State.user) === planId){
    showToast(`Ya tienes el plan ${plan.name}.`, 'info');
    return;
  }
  openPlanCheckout(plan);
}

function openPlanCheckout(plan){
  const body = document.getElementById('plan-modal-body');
  if (!body) return;
  body.innerHTML = `
    <div class="plan-checkout-head">
      <div class="plan-icon" style="--plan-color:${plan.color};margin:0 auto 10px"><i class="fas ${plan.icon}"></i></div>
      <h2>Plan ${plan.name}</h2>
      <div class="plan-price" style="margin:4px 0">$${plan.price.toFixed(2)}<span>/mes</span></div>
      <div class="plan-uploads" style="margin:8px auto"><i class="fas fa-cloud-arrow-up"></i> ${plan.dailyUploads} add-ons por día</div>
    </div>
    <ul class="plan-features" style="max-width:300px;margin:14px auto 18px">
      ${plan.features.map(f => `<li><i class="fas fa-check"></i> ${escHtml(f)}</li>`).join('')}
    </ul>
    <p style="text-align:center;color:var(--text-muted);font-size:.78rem;margin-bottom:8px">Pago seguro con PayPal · 1 mes</p>
    <div id="plan-paypal-container"></div>
  `;
  openModal('plan-modal');
  if (typeof renderPlanPayPalButton === 'function') renderPlanPayPalButton(plan);
}

function activatePlanAfterPayment(plan, details){
  if (!State.user) return;
  State.user.plan = plan.id;
  State.user.planSince = new Date().toISOString();
  persistCurrentUser();
  // Registrar la orden del plan
  try {
    const orders = DB.get(DB_KEYS.ORDERS);
    orders.push({
      id: 'plan_' + Date.now(),
      userId: State.user.id,
      type: 'plan',
      planId: plan.id,
      addonName: `Plan ${plan.name} (mensual)`,
      price: plan.price,
      currency: 'USD',
      paypalOrderId: details && details.id,
      status: 'completed',
      date: new Date().toISOString()
    });
    DB.set(DB_KEYS.ORDERS, orders);
  } catch(e){ console.error(e); }
  closeModal('plan-modal');
  renderPlans();
  const name = (details && details.payer && details.payer.name && details.payer.name.given_name) || '';
  showToast(`¡Plan ${plan.name} activado${name ? ', '+name : ''}! Ahora puedes subir ${plan.dailyUploads} add-ons al día.`, 'success', 6000);
}

/* ============================================================
   SUBIR ADD-ON (usuarios registrados, con límite diario)
   ============================================================ */
function populateUploadTypes(){
  const sel = document.getElementById('up-type');
  if (!sel || !window.CONTENT_TYPES) return;
  const platform = (document.getElementById('up-platform')||{}).value || 'bedrock';
  const types = window.CONTENT_TYPES.filter(t => t.platform === 'both' || t.platform === platform);
  sel.innerHTML = types.map(t => `<option value="${t.id}">${t.name}</option>`).join('');
}
function onUploadPlatformChange(){ populateUploadTypes(); }

function openUploadModal(){
  document.getElementById('user-dropdown')?.classList.remove('open');
  if (!State.user){ openAuthModal('login'); showToast('Inicia sesión para subir add-ons.', 'info'); return; }
  _upImage=null; _upFile=null; _upFileName=null;
  const f = document.getElementById('user-upload-form'); if (f) f.reset();
  document.getElementById('up-image-name').textContent = 'Ningún archivo';
  document.getElementById('up-file-name').textContent  = 'Ningún archivo';
  document.getElementById('up-image-preview').style.display = 'none';
  populateUploadTypes();
  const limit = getDailyLimit(userPlanId(State.user));
  const used  = countTodayUploads(State.user.id);
  const info  = document.getElementById('upload-limit-info');
  if (info) info.innerHTML = `Plan <strong>${getPlanById(userPlanId(State.user)).name}</strong> &middot; Hoy: <strong>${used}/${limit}</strong> add-ons`;
  openModal('upload-modal');
}

function handleUploadImage(input){
  const file = input.files && input.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')){ showToast('Selecciona una imagen válida.', 'error'); input.value=''; return; }
  document.getElementById('up-image-name').textContent = file.name;
  const reader = new FileReader();
  reader.onload = e => {
    const img = new Image();
    img.onload = () => {
      const MAX=800; let w=img.width, h=img.height;
      if (w>MAX||h>MAX){ if(w>=h){h=Math.round(h*MAX/w);w=MAX;}else{w=Math.round(w*MAX/h);h=MAX;} }
      const c=document.createElement('canvas'); c.width=w; c.height=h;
      c.getContext('2d').drawImage(img,0,0,w,h);
      try{ _upImage=c.toDataURL('image/jpeg',0.85); }catch(err){ _upImage=e.target.result; }
      document.getElementById('up-image-url').value='';
      document.getElementById('up-image-preview-img').src=_upImage;
      document.getElementById('up-image-preview').style.display='block';
    };
    img.src=e.target.result;
  };
  reader.readAsDataURL(file);
}

function handleUploadFile(input){
  const file = input.files && input.files[0];
  if (!file) return;
  const mb = file.size/(1024*1024);
  if (mb>8){ showToast(`El archivo pesa ${mb.toFixed(1)} MB. Máximo 8 MB; usa un enlace para archivos más grandes.`, 'error'); input.value=''; return; }
  document.getElementById('up-file-name').textContent = `${file.name} (${mb.toFixed(2)} MB)`;
  const reader=new FileReader();
  reader.onload=e=>{ _upFile=e.target.result; _upFileName=file.name; document.getElementById('up-download-url').value=''; };
  reader.readAsDataURL(file);
}

function submitUserAddon(e){
  if (e && e.preventDefault) e.preventDefault();
  try {
    if (!State.user){ openAuthModal('login'); return; }
    const limit = getDailyLimit(userPlanId(State.user));
    const used  = countTodayUploads(State.user.id);
    if (used >= limit){
      showToast(`Alcanzaste tu límite de ${limit} add-ons por hoy. Mejora tu plan para subir más.`, 'warning', 7000);
      return;
    }
    const name = document.getElementById('up-name').value.trim();
    const platform = document.getElementById('up-platform').value;
    const contentType = document.getElementById('up-type').value;
    const description = document.getElementById('up-desc').value.trim();
    const price = parseFloat(document.getElementById('up-price').value) || 0;
    const version = document.getElementById('up-version').value.trim();
    const mcVersion = document.getElementById('up-mcversion').value.trim();
    const image = _upImage || document.getElementById('up-image-url').value.trim();
    const downloadUrl = _upFile || document.getElementById('up-download-url').value.trim();
    const downloadName = _upFile ? _upFileName : '';

    if (!name){ showToast('Ponle un nombre a tu add-on.', 'error'); return; }
    const fileInput = document.getElementById('up-file');
    if (fileInput.files.length>0 && !_upFile){ showToast('El archivo aún se procesa, espera un momento.', 'warning'); return; }
    if (!downloadUrl){ showToast('Sube un archivo o pega un enlace de descarga.', 'error'); return; }

    const addons = DB.get(DB_KEYS.ADDONS);
    addons.push({
      id: 'addon_'+Date.now()+'_'+Math.random().toString(36).substr(2,6),
      name, platform, contentType, category: contentType,
      description, price, version, mcVersion,
      image, downloadUrl, downloadName,
      emoji:'', isFeatured:false, isNew:true,
      downloads:0, purchases:0,
      status: 'pending', approved: false,
      authorId: State.user.id, authorName: userDisplayName(State.user), authorAvatar: userAvatar(State.user),
      createdAt: new Date().toISOString()
    });

    Promise.resolve(DB.set(DB_KEYS.ADDONS, addons))
      .then(()=>{
        showToast('¡Add-on enviado! Quedó pendiente de aprobación del administrador.', 'success', 6000);
        closeModal('upload-modal');
        loadAddons(); updateStats();
      })
      .catch(err=>{
        if (err && err.message==='LOCAL_STORAGE_FULL') showToast('El archivo es muy grande. Usa un enlace de descarga.', 'error', 7000);
        else showToast('Publicado localmente, pero la nube falló. Revisa las reglas de Firebase.', 'warning', 8000);
      });
  } catch(err){
    console.error('[Upload] error:', err);
    showToast('Error al publicar: '+(err && err.message ? err.message : err), 'error');
  }
}

/* ============================================================
   PERFIL (ver / editar / marcos / selección)
   ============================================================ */
function openProfileModal(){
  document.getElementById('user-dropdown')?.classList.remove('open');
  if (!State.user){ openAuthModal('login'); showToast('Inicia sesión para ver tu perfil.', 'info'); return; }
  renderProfile(false);
  openModal('profile-modal');
}

function renderProfile(editMode){
  const u = State.user;
  const view = document.getElementById('profile-view');
  if (!u || !view) return;
  const plan = getPlanById(userPlanId(u));
  const myAddons = DB.get(DB_KEYS.ADDONS).filter(a => a.authorId === u.id);
  const totalDl = myAddons.reduce((s,a)=>s+(a.downloads||0),0);
  const country = (window.COUNTRIES||[]).find(c=>c.code===u.country);

  if (!editMode){
    view.innerHTML = `
      <div class="profile-cover"></div>
      <div class="profile-head">
        <div class="profile-avatar-wrap ${frameClass(u.frame)}">
          ${u.frame === 'flags' ? `<div class="flag-ring">${flagRingHTML(52, 16)}</div>` : ''}
          <img class="pf-avatar-img" src="${escHtml(userAvatar(u))}" alt="" onerror="this.style.opacity=0" />
        </div>
        ${country ? `<img class="profile-flag" src="${FLAG_URL(country.code)}" alt="${escHtml(country.name)}" title="${escHtml(country.name)}" />` : ''}
        <h2 class="profile-name">${escHtml(userDisplayName(u))}</h2>
        <span class="profile-plan-badge plan-${plan.id}"><i class="fas ${plan.icon}"></i> ${plan.name}</span>
        <p class="profile-bio ${u.bio?'':'muted'}">${u.bio ? escHtml(u.bio) : 'Sin biografía aún.'}</p>
      </div>
      <div class="profile-stats">
        <div><strong>${myAddons.length}</strong><span>Add-ons</span></div>
        <div><strong>${totalDl.toLocaleString()}</strong><span>Descargas</span></div>
        <div><strong>${plan.dailyUploads}</strong><span>Límite/día</span></div>
      </div>
      <div class="profile-actions">
        <button class="btn btn-primary btn-full" onclick="renderProfile(true)"><i class="fas fa-pen"></i> Editar perfil</button>
        <button class="btn btn-outline btn-full" onclick="closeModal('profile-modal');openUploadModal()"><i class="fas fa-cloud-arrow-up"></i> Subir add-on</button>
      </div>
      <h3 class="profile-section-title"><i class="fas fa-box"></i> Mis Add-ons (${myAddons.length})</h3>
      <div class="profile-addons">
        ${myAddons.length === 0 ? '<p class="muted" style="text-align:center;padding:14px 0">Aún no has subido add-ons.</p>' :
          myAddons.map(a => {
            const st = a.status === 'pending' ? '<span class="st-badge st-pending"><i class="fas fa-clock"></i> Pendiente</span>'
                     : a.status === 'rejected' ? '<span class="st-badge st-rejected"><i class="fas fa-ban"></i> Rechazado</span>'
                     : '<span class="st-badge st-approved"><i class="fas fa-check"></i> Aprobado</span>';
            return `
            <div class="profile-addon-item">
              <div class="profile-addon-ic">${a.image ? `<img src="${escHtml(a.image)}" alt="" onerror="this.outerHTML='&#9638;'"/>` : '<i class="fas fa-cube"></i>'}</div>
              <div class="profile-addon-info"><strong>${escHtml(a.name)}</strong><small>${(a.downloads||0).toLocaleString()} descargas · ${st}</small></div>
              <button class="btn btn-sm btn-danger" onclick="deleteMyAddon('${a.id}')" title="Eliminar"><i class="fas fa-trash"></i></button>
            </div>`; }).join('')}
      </div>
    `;
    return;
  }

  _profAvatar = null; _profFrame = u.frame || 'none';
  const isPremiumPlan = userPlanId(u) !== 'free';
  view.innerHTML = `
    <h2 class="profile-edit-title"><i class="fas fa-pen"></i> Editar perfil</h2>
    <div class="pf-group">
      <label>Nombre para mostrar</label>
      <input type="text" id="pf-name" class="uinput" value="${escHtml(userDisplayName(u))}" maxlength="40" />
    </div>
    <div class="pf-group">
      <label>Foto de perfil</label>
      <div class="file-pick">
        <input type="file" id="pf-avatar-file" accept="image/*" onchange="handleProfileAvatar(this)" hidden />
        <button type="button" class="file-pick-btn" onclick="document.getElementById('pf-avatar-file').click()"><i class="fas fa-image"></i> Subir foto</button>
        <span class="file-pick-name" id="pf-avatar-name">Actual</span>
      </div>
    </div>
    <div class="pf-group">
      <label>Biografía</label>
      <textarea id="pf-bio" class="uinput utextarea" rows="2" maxlength="160" placeholder="Cuéntanos sobre ti...">${escHtml(u.bio||'')}</textarea>
    </div>
    <div class="pf-group">
      <label>Selección (Mundial 2026)</label>
      <select id="pf-country" class="uinput">
        <option value="">Sin selección</option>
        ${(window.COUNTRIES||[]).map(c=>`<option value="${c.code}" ${u.country===c.code?'selected':''}>${escHtml(c.name)}</option>`).join('')}
      </select>
    </div>
    <div class="pf-group">
      <label>Marco del avatar</label>
      <div class="frames-grid" id="frames-grid">
        ${(window.FRAMES||[]).map(fr=>`
          <button type="button" class="frame-pick ${_profFrame===fr.id?'active':''} ${fr.premium && !isPremiumPlan ? 'locked':''}" data-frame="${fr.id}" onclick="pickFrame('${fr.id}', ${fr.premium})">
            <span class="frame-demo av-frame av-${fr.id}">${fr.id==='flags' ? `<span class="flag-ring flag-ring-mini">${flagRingHTML(17,10)}</span><i class="fas fa-user"></i>` : '<i class="fas fa-user"></i>'}</span>
            <small>${fr.name}${fr.premium?' <i class="fas fa-lock"></i>':''}</small>
          </button>`).join('')}
      </div>
    </div>
    <div class="profile-actions">
      <button class="btn btn-secondary btn-full" onclick="renderProfile(false)">Cancelar</button>
      <button class="btn btn-primary btn-full" onclick="saveProfile()"><i class="fas fa-save"></i> Guardar</button>
    </div>
  `;
}

function pickFrame(frameId, premium){
  if (premium && userPlanId(State.user) === 'free'){
    showToast('Este marco es premium. Mejora a Creator o Pro para usarlo.', 'warning');
    return;
  }
  _profFrame = frameId;
  document.querySelectorAll('.frame-pick').forEach(b=>b.classList.toggle('active', b.dataset.frame===frameId));
}

function handleProfileAvatar(input){
  const file = input.files && input.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')){ showToast('Selecciona una imagen.', 'error'); return; }
  document.getElementById('pf-avatar-name').textContent = file.name;
  const reader=new FileReader();
  reader.onload=e=>{
    const img=new Image();
    img.onload=()=>{
      const MAX=400; let w=img.width, h=img.height;
      if(w>MAX||h>MAX){ if(w>=h){h=Math.round(h*MAX/w);w=MAX;}else{w=Math.round(w*MAX/h);h=MAX;} }
      const c=document.createElement('canvas');c.width=w;c.height=h;
      c.getContext('2d').drawImage(img,0,0,w,h);
      try{_profAvatar=c.toDataURL('image/jpeg',0.85);}catch(err){_profAvatar=e.target.result;}
    };
    img.src=e.target.result;
  };
  reader.readAsDataURL(file);
}

function saveProfile(){
  if (!State.user) return;
  const name = document.getElementById('pf-name').value.trim();
  const bio  = document.getElementById('pf-bio').value.trim();
  const country = document.getElementById('pf-country').value;
  State.user.displayName = name || State.user.name;
  State.user.bio = bio;
  State.user.country = country;
  State.user.frame = _profFrame || 'none';
  if (_profAvatar) State.user.customAvatar = _profAvatar;
  persistCurrentUser();
  showToast('Perfil actualizado.', 'success');
  renderProfile(false);
}

function deleteMyAddon(id){
  if (!State.user) return;
  const addons = DB.get(DB_KEYS.ADDONS);
  const target = addons.find(a=>a.id===id);
  if (!target || target.authorId !== State.user.id){ showToast('No puedes eliminar este add-on.', 'error'); return; }
  if (!confirm('¿Eliminar este add-on? No se puede deshacer.')) return;
  DB.set(DB_KEYS.ADDONS, addons.filter(a=>a.id!==id));
  loadAddons(); updateStats(); renderProfile(false);
  showToast('Add-on eliminado.', 'warning');
}

// Vincular el formulario de subida cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
  const upForm = document.getElementById('user-upload-form');
  if (upForm) upForm.addEventListener('submit', submitUserAddon);
});

// Expose globally
window.toggleHamburger    = toggleHamburger;
window.closeHamburger     = closeHamburger;
window.openSheet          = openSheet;
window.closeSheet         = closeSheet;
window.openAuthModal      = openAuthModal;
window.closeModal         = closeModal;
window.openModal          = openModal;
window.toggleUserDropdown = toggleUserDropdown;
window.logout             = logout;
window.setCategory        = setCategory;
window.filterAddons       = filterAddons;
window.openAddonDetail    = openAddonDetail;
window.downloadAddon      = downloadAddon;
window.openPurchasesModal = openPurchasesModal;
window.loadMore           = loadMore;
window.showToast          = showToast;
window.escHtml            = escHtml;
window.generateId         = generateId;
window.State              = State;
window.savePurchase       = savePurchase;
window.renderAddonAction  = renderAddonAction;
window.hasPurchased       = hasPurchased;
window.updateStats        = updateStats;
window.setPlatform        = setPlatform;
window.renderPlans        = renderPlans;
window.selectPlan         = selectPlan;
window.openPlanCheckout   = openPlanCheckout;
window.activatePlanAfterPayment = activatePlanAfterPayment;
window.openUploadModal    = openUploadModal;
window.onUploadPlatformChange = onUploadPlatformChange;
window.handleUploadImage  = handleUploadImage;
window.handleUploadFile   = handleUploadFile;
window.submitUserAddon    = submitUserAddon;
window.openProfileModal   = openProfileModal;
window.renderProfile      = renderProfile;
window.pickFrame          = pickFrame;
window.handleProfileAvatar= handleProfileAvatar;
window.saveProfile        = saveProfile;
window.deleteMyAddon      = deleteMyAddon;
window.populateUploadTypes= populateUploadTypes;
