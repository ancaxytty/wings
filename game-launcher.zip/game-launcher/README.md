# RetroLauncher - Lanzador de juegos para emuladores

Aplicacion de escritorio en **Python (Tkinter)**, sin HTML/CSS, **convertible a
.exe**. Organiza tu biblioteca de juegos y los abre con un clic usando los
emuladores de escritorio que tu instales.

## Lee esto primero (importante y honesto)

**RetroLauncher NO es un emulador y NO emula nada por si mismo.** Es un
"frontend" / lanzador, igual que Playnite o LaunchBox: solo abre tus juegos con
un emulador externo que tu instalas por separado.

- **PS4: NO soportado.** No existe ningun emulador de PS4 funcional en el mundo,
  en ningun lenguaje ni plataforma. Por eso ningun lanzador puede ejecutar PS4.
- **Nintendo Switch:** funciona si instalas **Ryujinx** y configuras tus propias
  claves/firmware (extraidas de tu consola).
- **Wii / GameCube, PS2, PSP, PS3, PS1:** funcionan con sus emuladores de
  escritorio (Dolphin, PCSX2, PPSSPP, RPCS3, DuckStation).

> Usa unicamente juegos, BIOS y claves que poseas legalmente y hayas extraido de
> tu propia consola. Los emuladores son legales; descargar juegos que no posees
> no lo es.

---

## Emuladores incluidos en el catalogo

| Emulador | Plataforma | Extensiones | Web oficial |
|----------|-----------|-------------|-------------|
| Ryujinx | Nintendo Switch | nsp, xci, nca, nsz, xcz | ryujinx.org |
| Dolphin | Wii / GameCube | iso, wbfs, gcm, rvz, wad, gcz | dolphin-emu.org |
| PCSX2 | PlayStation 2 | iso, bin, chd, cso, mdf | pcsx2.net |
| PPSSPP | PSP | iso, cso, pbp | ppsspp.org |
| RPCS3 | PlayStation 3 | bin, iso, pkg | rpcs3.net |
| DuckStation | PlayStation 1 | cue, bin, chd, img, pbp | duckstation.org |

Puedes anadir mas emuladores con "Anadir emulador personalizado".

---

## Como usarlo

Requiere [Python](https://python.org) 3.8 o superior. Tkinter viene incluido con
Python en Windows y macOS (en Linux: `sudo apt install python3-tk`).

1. Inicia la app:
   - Windows: doble clic en `start.bat`
   - Linux/macOS: `./start.sh`  (o `python3 launcher.py`)
2. Pulsa **Emuladores** y define la ruta del ejecutable de cada emulador que
   tengas instalado (por ejemplo, el `.exe` de Ryujinx).
3. Pulsa **Anadir carpeta de juegos** y elige la carpeta donde guardas tus ROMs.
4. Selecciona un juego y pulsa **Jugar** (o doble clic). El lanzador abrira el
   emulador correcto con ese juego.

La configuracion se guarda en `launcher_config.json`, junto al programa.

---

## Convertir a .exe (Windows)

```bat
pip install pyinstaller
build_exe.bat
```

Genera `dist\RetroLauncher.exe`. Colocalo donde quieras; creara su
`launcher_config.json` al lado. (En Linux/macOS usa `build_exe.sh`; PyInstaller
no hace compilacion cruzada, asi que el .exe de Windows debe generarse en Windows.)

---

## Como funciona por dentro

Al pulsar Jugar, el programa ejecuta basicamente:

```
subprocess.Popen([ruta_del_emulador, ruta_del_juego])
```

Es decir, abre el emulador pasandole el archivo del juego. Toda la emulacion la
hace el emulador externo; este programa solo organiza y lanza.

---

## Por que PS4 y Switch no se pueden "programar desde cero"

Un emulador real (como Ryujinx para Switch) tiene cientos de miles de lineas de
C++, recompiladores JIT, emulacion de GPU con Vulkan y anos de ingenieria
inversa. No es algo que se escriba en Python o Node.js. Y para PS4 directamente
no existe ninguna base funcional. Por eso la via realista es **lanzar**
emuladores existentes, que es lo que hace este programa.

---

Licencia del codigo de este lanzador: MIT. Cada emulador externo mantiene su
propia licencia y debe descargarse de su web oficial.
