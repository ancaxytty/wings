#!/usr/bin/env bash
# Genera el binario RetroLauncher usando PyInstaller (Linux/macOS).
set -e

pip install pyinstaller
pyinstaller --onefile --windowed --name RetroLauncher launcher.py

echo ""
echo "Listo. El binario esta en la carpeta dist/"
echo "Para un .exe de Windows, ejecuta build_exe.bat EN Windows (PyInstaller no hace cross-compile)."
