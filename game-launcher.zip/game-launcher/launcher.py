#!/usr/bin/env python3
"""RetroLauncher - Lanzador de juegos para emuladores de escritorio.

IMPORTANTE: Este programa NO es un emulador y NO emula nada por si mismo.
Es un "frontend" / lanzador: organiza tu biblioteca y abre cada juego con un
emulador EXTERNO que tu instalas (Ryujinx, Dolphin, PCSX2, PPSSPP, etc.).

- Nintendo Switch: funciona si instalas Ryujinx y configuras tus claves/firmware.
- Wii / GameCube, PS2, PSP, PS3, PS1: funcionan con sus emuladores de escritorio.
- PS4: NO soportado. No existe ningun emulador de PS4 funcional en el mundo.

Solo requiere Python (la libreria grafica Tkinter viene incluida).
Se puede empaquetar a .exe con PyInstaller.
"""

import json
import os
import subprocess
import sys

try:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
except Exception:  # pragma: no cover
    print("ERROR: Tkinter no esta disponible en esta instalacion de Python.")
    print("En Windows/macOS viene incluido. En Linux instala 'python3-tk'.")
    sys.exit(1)


APP_NAME = "RetroLauncher"

# Carpeta de datos: junto al .exe si esta empaquetado, si no junto al script.
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "launcher_config.json")

# Catalogo de emuladores conocidos (rutas vacias hasta que el usuario las defina).
# extensiones en minusculas, sin punto.
DEFAULT_EMULATORS = [
    {"name": "Ryujinx", "platform": "Nintendo Switch", "path": "", "exts": ["nsp", "xci", "nca", "nsz", "xcz"]},
    {"name": "Dolphin", "platform": "Wii / GameCube", "path": "", "exts": ["iso", "wbfs", "gcm", "rvz", "wad", "gcz"]},
    {"name": "PCSX2", "platform": "PlayStation 2", "path": "", "exts": ["iso", "bin", "chd", "cso", "mdf"]},
    {"name": "PPSSPP", "platform": "PSP", "path": "", "exts": ["iso", "cso", "pbp"]},
    {"name": "RPCS3", "platform": "PlayStation 3", "path": "", "exts": ["bin", "iso", "pkg"]},
    {"name": "DuckStation", "platform": "PlayStation 1", "path": "", "exts": ["cue", "bin", "chd", "img", "pbp"]},
]

# Nota visible: PS4 no se puede emular.
UNSUPPORTED_NOTE = "PS4 no soportado: no existe ningun emulador de PS4 funcional."

DARK = {
    "bg": "#10141c",
    "panel": "#171e29",
    "row": "#1d2533",
    "text": "#e6ecf5",
    "dim": "#8a97ad",
    "accent": "#6c8cff",
    "warn": "#ffb454",
}


def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            cfg.setdefault("emulators", DEFAULT_EMULATORS)
            cfg.setdefault("library_folders", [])
            return cfg
        except Exception:
            pass
    return {"emulators": [dict(e) for e in DEFAULT_EMULATORS], "library_folders": []}


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        messagebox.showerror(APP_NAME, "No se pudo guardar la configuracion:\n%s" % e)


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.games = []  # lista de dicts: {name, path, ext}

        self.title(APP_NAME + " - Lanzador de emuladores")
        self.geometry("860x560")
        self.minsize(720, 480)
        self.configure(bg=DARK["bg"])

        self._build_styles()
        self._build_header()
        self._build_toolbar()
        self._build_table()
        self._build_statusbar()

        self.refresh_games()

    # ---------- estilos ----------
    def _build_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(
            "Treeview",
            background=DARK["row"],
            fieldbackground=DARK["row"],
            foreground=DARK["text"],
            rowheight=30,
            borderwidth=0,
        )
        style.configure(
            "Treeview.Heading",
            background=DARK["panel"],
            foreground=DARK["dim"],
            borderwidth=0,
            font=("Segoe UI", 10, "bold"),
        )
        style.map("Treeview", background=[("selected", DARK["accent"])])

    def _btn(self, parent, text, cmd, primary=False):
        bg = DARK["accent"] if primary else DARK["panel"]
        b = tk.Button(
            parent, text=text, command=cmd,
            bg=bg, fg="#ffffff" if primary else DARK["text"],
            activebackground=DARK["accent"], activeforeground="#fff",
            relief="flat", bd=0, padx=14, pady=8, cursor="hand2",
            font=("Segoe UI", 10, "bold" if primary else "normal"),
        )
        return b

    # ---------- secciones ----------
    def _build_header(self):
        head = tk.Frame(self, bg=DARK["bg"])
        head.pack(fill="x", padx=18, pady=(16, 4))
        tk.Label(head, text=APP_NAME, bg=DARK["bg"], fg=DARK["text"],
                 font=("Segoe UI", 20, "bold")).pack(side="left")
        tk.Label(head, text="  Lanzador (no es un emulador; abre tus juegos con emuladores externos)",
                 bg=DARK["bg"], fg=DARK["dim"], font=("Segoe UI", 10)).pack(side="left", pady=(8, 0))

        warn = tk.Label(self, text=UNSUPPORTED_NOTE, bg=DARK["bg"], fg=DARK["warn"],
                        font=("Segoe UI", 9, "italic"))
        warn.pack(fill="x", padx=18, anchor="w")

    def _build_toolbar(self):
        bar = tk.Frame(self, bg=DARK["bg"])
        bar.pack(fill="x", padx=18, pady=12)
        self._btn(bar, "Jugar", self.launch_selected, primary=True).pack(side="left", padx=(0, 8))
        self._btn(bar, "Anadir carpeta de juegos", self.add_folder).pack(side="left", padx=4)
        self._btn(bar, "Emuladores", self.open_emulators).pack(side="left", padx=4)
        self._btn(bar, "Recargar", self.refresh_games).pack(side="left", padx=4)
        self._btn(bar, "Quitar carpeta", self.remove_folder).pack(side="left", padx=4)

    def _build_table(self):
        wrap = tk.Frame(self, bg=DARK["panel"])
        wrap.pack(fill="both", expand=True, padx=18, pady=(0, 10))
        cols = ("name", "platform", "emulator", "path")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings", selectmode="browse")
        for c, t, w in [
            ("name", "Juego", 240),
            ("platform", "Plataforma", 150),
            ("emulator", "Emulador", 130),
            ("path", "Archivo", 300),
        ]:
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        sb.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.bind("<Double-1>", lambda e: self.launch_selected())

    def _build_statusbar(self):
        self.status = tk.Label(self, text="", bg=DARK["bg"], fg=DARK["dim"],
                               anchor="w", font=("Segoe UI", 9))
        self.status.pack(fill="x", padx=18, pady=(0, 12))

    def set_status(self, msg):
        self.status.configure(text=msg)

    # ---------- logica ----------
    def emulator_for_ext(self, ext):
        """Devuelve la lista de emuladores configurados que manejan esta extension."""
        return [e for e in self.cfg["emulators"] if ext in [x.lower() for x in e.get("exts", [])]]

    def all_known_exts(self):
        exts = set()
        for e in self.cfg["emulators"]:
            for x in e.get("exts", []):
                exts.add(x.lower())
        return exts

    def refresh_games(self):
        self.games = []
        known = self.all_known_exts()
        for folder in self.cfg["library_folders"]:
            if not os.path.isdir(folder):
                continue
            for root, _dirs, files in os.walk(folder):
                for fn in files:
                    ext = os.path.splitext(fn)[1].lstrip(".").lower()
                    if ext in known:
                        self.games.append({
                            "name": os.path.splitext(fn)[0],
                            "path": os.path.join(root, fn),
                            "ext": ext,
                        })
        self.games.sort(key=lambda g: g["name"].lower())

        for item in self.tree.get_children():
            self.tree.delete(item)
        for i, g in enumerate(self.games):
            emus = self.emulator_for_ext(g["ext"])
            emu_name = emus[0]["name"] if emus else "?"
            platform = emus[0]["platform"] if emus else "?"
            tag = "odd" if i % 2 else "even"
            self.tree.insert("", "end", iid=str(i),
                             values=(g["name"], platform, emu_name, g["path"]), tags=(tag,))
        self.tree.tag_configure("odd", background=DARK["row"])
        self.tree.tag_configure("even", background=DARK["panel"])

        n = len(self.games)
        folders = len(self.cfg["library_folders"])
        if folders == 0:
            self.set_status("Anade una carpeta de juegos para empezar.")
        else:
            self.set_status("%d juego(s) en %d carpeta(s)." % (n, folders))

    def add_folder(self):
        folder = filedialog.askdirectory(title="Selecciona una carpeta con tus juegos")
        if folder:
            if folder not in self.cfg["library_folders"]:
                self.cfg["library_folders"].append(folder)
                save_config(self.cfg)
            self.refresh_games()

    def remove_folder(self):
        if not self.cfg["library_folders"]:
            messagebox.showinfo(APP_NAME, "No hay carpetas configuradas.")
            return
        FolderManager(self, self.cfg, self.refresh_games)

    def launch_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, "Selecciona un juego de la lista.")
            return
        game = self.games[int(sel[0])]
        emus = [e for e in self.emulator_for_ext(game["ext"]) if e.get("path")]
        if not emus:
            messagebox.showwarning(
                APP_NAME,
                "No hay un emulador configurado para los archivos .%s\n\n"
                "Abre 'Emuladores' y define la ruta del programa correspondiente." % game["ext"],
            )
            return
        emu = emus[0]
        if len(emus) > 1:
            emu = self._choose_emulator(emus)
            if emu is None:
                return
        self._run(emu, game)

    def _choose_emulator(self, emus):
        dlg = tk.Toplevel(self)
        dlg.title("Elegir emulador")
        dlg.configure(bg=DARK["bg"])
        dlg.transient(self)
        dlg.grab_set()
        tk.Label(dlg, text="Varios emuladores manejan este formato. Elige uno:",
                 bg=DARK["bg"], fg=DARK["text"], font=("Segoe UI", 10)).pack(padx=16, pady=12)
        choice = {"emu": None}
        for e in emus:
            def pick(em=e):
                choice["emu"] = em
                dlg.destroy()
            tk.Button(dlg, text="%s  (%s)" % (e["name"], e["platform"]), command=pick,
                      bg=DARK["panel"], fg=DARK["text"], relief="flat", padx=12, pady=8,
                      cursor="hand2").pack(fill="x", padx=16, pady=4)
        dlg.wait_window()
        return choice["emu"]

    def _run(self, emu, game):
        path = emu.get("path", "")
        if not path or not os.path.exists(path):
            messagebox.showerror(APP_NAME, "La ruta del emulador '%s' no existe:\n%s" % (emu["name"], path))
            return
        try:
            subprocess.Popen([path, game["path"]])
            self.set_status("Lanzando '%s' con %s..." % (game["name"], emu["name"]))
        except Exception as e:
            messagebox.showerror(APP_NAME, "No se pudo iniciar el emulador:\n%s" % e)

    def open_emulators(self):
        EmulatorManager(self, self.cfg, self.refresh_games)


class FolderManager(tk.Toplevel):
    def __init__(self, parent, cfg, on_change):
        super().__init__(parent)
        self.cfg = cfg
        self.on_change = on_change
        self.title("Carpetas de juegos")
        self.configure(bg=DARK["bg"])
        self.geometry("560x320")
        self.transient(parent)
        self.grab_set()

        tk.Label(self, text="Carpetas configuradas", bg=DARK["bg"], fg=DARK["text"],
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(14, 8))
        self.listbox = tk.Listbox(self, bg=DARK["row"], fg=DARK["text"], relief="flat",
                                  selectbackground=DARK["accent"], highlightthickness=0)
        self.listbox.pack(fill="both", expand=True, padx=16)
        self._reload()
        btns = tk.Frame(self, bg=DARK["bg"])
        btns.pack(fill="x", padx=16, pady=12)
        tk.Button(btns, text="Quitar seleccionada", command=self.remove,
                  bg=DARK["panel"], fg=DARK["text"], relief="flat", padx=12, pady=6,
                  cursor="hand2").pack(side="left")
        tk.Button(btns, text="Cerrar", command=self.destroy,
                  bg=DARK["panel"], fg=DARK["text"], relief="flat", padx=12, pady=6,
                  cursor="hand2").pack(side="right")

    def _reload(self):
        self.listbox.delete(0, "end")
        for f in self.cfg["library_folders"]:
            self.listbox.insert("end", f)

    def remove(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        del self.cfg["library_folders"][sel[0]]
        save_config(self.cfg)
        self._reload()
        self.on_change()


class EmulatorManager(tk.Toplevel):
    def __init__(self, parent, cfg, on_change):
        super().__init__(parent)
        self.cfg = cfg
        self.on_change = on_change
        self.title("Emuladores")
        self.configure(bg=DARK["bg"])
        self.geometry("640x440")
        self.transient(parent)
        self.grab_set()

        tk.Label(self, text="Configura la ruta de cada emulador que tengas instalado",
                 bg=DARK["bg"], fg=DARK["text"], font=("Segoe UI", 12, "bold")).pack(
            anchor="w", padx=16, pady=(14, 4))
        tk.Label(self, text="Descarga cada emulador de su web oficial. Aporta tus propias claves/BIOS legales.",
                 bg=DARK["bg"], fg=DARK["dim"], font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(0, 10))

        self.body = tk.Frame(self, bg=DARK["bg"])
        self.body.pack(fill="both", expand=True, padx=16)
        self._reload()

        bottom = tk.Frame(self, bg=DARK["bg"])
        bottom.pack(fill="x", padx=16, pady=12)
        tk.Button(bottom, text="Anadir emulador personalizado", command=self.add_custom,
                  bg=DARK["panel"], fg=DARK["text"], relief="flat", padx=12, pady=6,
                  cursor="hand2").pack(side="left")
        tk.Button(bottom, text="Cerrar", command=self._close,
                  bg=DARK["accent"], fg="#fff", relief="flat", padx=14, pady=6,
                  cursor="hand2").pack(side="right")

    def _reload(self):
        for w in self.body.winfo_children():
            w.destroy()
        head = tk.Frame(self.body, bg=DARK["bg"])
        head.pack(fill="x", pady=(0, 6))
        for txt, w in [("Emulador", 18), ("Plataforma", 18), ("Ruta", 26), ("", 8)]:
            tk.Label(head, text=txt, bg=DARK["bg"], fg=DARK["dim"], width=w, anchor="w",
                     font=("Segoe UI", 9, "bold")).pack(side="left")

        canvas = tk.Canvas(self.body, bg=DARK["bg"], highlightthickness=0)
        canvas.pack(fill="both", expand=True)
        inner = tk.Frame(canvas, bg=DARK["bg"])
        canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        for idx, emu in enumerate(self.cfg["emulators"]):
            row = tk.Frame(inner, bg=DARK["bg"])
            row.pack(fill="x", pady=3)
            tk.Label(row, text=emu["name"], bg=DARK["bg"], fg=DARK["text"], width=18, anchor="w").pack(side="left")
            tk.Label(row, text=emu["platform"], bg=DARK["bg"], fg=DARK["dim"], width=18, anchor="w").pack(side="left")
            path_txt = emu.get("path") or "(sin configurar)"
            lbl = tk.Label(row, text=self._short(path_txt), bg=DARK["bg"],
                           fg=DARK["text"] if emu.get("path") else DARK["dim"], width=26, anchor="w")
            lbl.pack(side="left")
            tk.Button(row, text="...", command=lambda i=idx: self.set_path(i),
                      bg=DARK["panel"], fg=DARK["text"], relief="flat", padx=8, cursor="hand2").pack(side="left")

    def _short(self, p):
        return p if len(p) <= 36 else "..." + p[-33:]

    def set_path(self, idx):
        path = filedialog.askopenfilename(
            title="Selecciona el ejecutable de %s" % self.cfg["emulators"][idx]["name"])
        if path:
            self.cfg["emulators"][idx]["path"] = path
            save_config(self.cfg)
            self._reload()

    def add_custom(self):
        CustomEmulatorDialog(self, self.cfg, self._reload)

    def _close(self):
        save_config(self.cfg)
        self.on_change()
        self.destroy()


class CustomEmulatorDialog(tk.Toplevel):
    def __init__(self, parent, cfg, on_change):
        super().__init__(parent)
        self.cfg = cfg
        self.on_change = on_change
        self.title("Emulador personalizado")
        self.configure(bg=DARK["bg"])
        self.geometry("420x300")
        self.transient(parent)
        self.grab_set()

        self.vars = {}
        for label, key in [("Nombre", "name"), ("Plataforma", "platform"),
                           ("Extensiones (separadas por coma)", "exts")]:
            tk.Label(self, text=label, bg=DARK["bg"], fg=DARK["text"]).pack(anchor="w", padx=16, pady=(10, 2))
            v = tk.StringVar()
            tk.Entry(self, textvariable=v, bg=DARK["row"], fg=DARK["text"], relief="flat",
                     insertbackground=DARK["text"]).pack(fill="x", padx=16)
            self.vars[key] = v

        tk.Button(self, text="Guardar", command=self.save,
                  bg=DARK["accent"], fg="#fff", relief="flat", padx=14, pady=7,
                  cursor="hand2").pack(pady=18)

    def save(self):
        name = self.vars["name"].get().strip()
        if not name:
            messagebox.showinfo(APP_NAME, "Indica un nombre.")
            return
        exts = [e.strip().lstrip(".").lower() for e in self.vars["exts"].get().split(",") if e.strip()]
        self.cfg["emulators"].append({
            "name": name,
            "platform": self.vars["platform"].get().strip() or "Personalizado",
            "path": "",
            "exts": exts,
        })
        save_config(self.cfg)
        self.on_change()
        self.destroy()


def main():
    app = Launcher()
    app.mainloop()


if __name__ == "__main__":
    main()
