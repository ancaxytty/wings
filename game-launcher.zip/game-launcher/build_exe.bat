@echo off
REM Genera RetroLauncher.exe usando PyInstaller (Windows).
echo Instalando PyInstaller si hace falta...
pip install pyinstaller

echo Compilando RetroLauncher.exe ...
pyinstaller --onefile --windowed --name RetroLauncher launcher.py

echo.
echo Listo. El ejecutable esta en la carpeta dist\RetroLauncher.exe
echo Colocalo donde quieras; creara launcher_config.json junto a el.
pause
