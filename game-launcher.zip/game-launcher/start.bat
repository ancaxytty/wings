@echo off
title RetroLauncher
where python >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Python no esta instalado. Descargalo desde https://python.org
  pause
  exit /b 1
)
python launcher.py
