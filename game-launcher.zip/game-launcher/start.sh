#!/usr/bin/env bash
set -e
if ! command -v python3 >/dev/null 2>&1; then
  echo "[ERROR] Python 3 no esta instalado. Instalalo desde https://python.org"
  echo "En Linux, instala tambien Tkinter:  sudo apt install python3-tk"
  exit 1
fi
exec python3 launcher.py
