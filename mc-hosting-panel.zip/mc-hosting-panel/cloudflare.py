"""
CloudflareManager: integracion con Cloudflare Tunnel (cloudflared).

Permite exponer el panel (y opcionalmente un servidor) a internet 24/7 a
traves de un tunel de Cloudflare, sin abrir puertos en el router.

Modos soportados:
  - "panel": tunel rapido (trycloudflare) que publica el panel web por HTTPS.
             Devuelve una URL publica https://....trycloudflare.com
  - "tcp"  : tunel rapido TCP para el puerto del servidor de Minecraft.
             (Los clientes necesitan 'cloudflared access tcp' o Spectrum de pago
             para conectar por el puerto del juego; ver README.)
  - "token": ejecuta un tunel CON NOMBRE usando un token del panel Zero Trust
             de Cloudflare (recomendado para 24/7 con dominio propio).

Requiere el binario 'cloudflared' instalado (o la variable CLOUDFLARED_PATH).
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
from collections import deque
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "cloudflare.json"  # guarda token + autostart (gitignored)

TRYCF_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
INSTALL_HELP = (
    "cloudflared no esta instalado. Instalalo desde "
    "https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/ "
    "o define la variable de entorno CLOUDFLARED_PATH con la ruta al binario."
)


def _run(cmd: list[str]) -> tuple[bool, str]:
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        text = ((out.stdout or "") + (out.stderr or "")).strip()
        return out.returncode == 0, text
    except FileNotFoundError:
        return False, f"Comando no disponible: {cmd[0]}"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


class CloudflareManager:
    def __init__(self):
        self.process: subprocess.Popen | None = None
        self.mode: str | None = None
        self.target: str | None = None
        self.public_url: str | None = None
        self.log: deque[str] = deque(maxlen=300)
        self._lock = threading.Lock()
        # configuracion persistente (token + auto-inicio)
        self.token: str | None = None
        self.autostart: bool = False
        self._load_config()

    # --- configuracion persistente ------------------------------------------
    def _load_config(self):
        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                self.token = data.get("token") or None
                self.autostart = bool(data.get("autostart", False))
            except Exception:  # noqa: BLE001
                pass

    def set_config(self, token: str | None = None, autostart: bool | None = None) -> dict:
        if token is not None:
            self.token = token.strip() or None
        if autostart is not None:
            self.autostart = bool(autostart)
        try:
            CONFIG_FILE.write_text(json.dumps(
                {"token": self.token, "autostart": self.autostart}, indent=2), encoding="utf-8")
            # permisos restrictivos: el token es un secreto
            try:
                os.chmod(CONFIG_FILE, 0o600)
            except Exception:  # noqa: BLE001
                pass
        except Exception:  # noqa: BLE001
            pass
        return {"has_token": bool(self.token), "autostart": self.autostart}

    # --- deteccion -----------------------------------------------------------
    def binary(self) -> str | None:
        env = os.environ.get("CLOUDFLARED_PATH")
        if env and os.path.exists(env):
            return env
        found = shutil.which("cloudflared")
        if found:
            return found
        # ubicaciones comunes
        for p in ("/usr/local/bin/cloudflared", "/usr/bin/cloudflared",
                  os.path.expanduser("~/.local/bin/cloudflared"),
                  os.path.expanduser("~/cloudflared")):
            if os.path.exists(p):
                return p
        return None

    def is_installed(self) -> bool:
        return self.binary() is not None

    @property
    def is_running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    # --- logging -------------------------------------------------------------
    def _log(self, line: str):
        ts = datetime.now().strftime("%H:%M:%S")
        with self._lock:
            self.log.append(f"[{ts}] {line.rstrip()}")

    def _read_output(self):
        assert self.process and self.process.stdout
        for raw in self.process.stdout:
            self._log(raw)
            if not self.public_url:
                m = TRYCF_RE.search(raw)
                if m:
                    self.public_url = m.group(0)
                    self._log(f"*** URL publica detectada: {self.public_url} ***")
        self._log("*** El tunel de Cloudflare se ha detenido ***")
        self.public_url = None

    # --- ciclo de vida -------------------------------------------------------
    def start(self, mode: str, target: str | None = None,
              token: str | None = None) -> tuple[bool, str]:
        if self.is_running:
            return False, "Ya hay un tunel en ejecucion. Detenlo primero."
        cf = self.binary()
        if not cf:
            return False, INSTALL_HELP

        if mode == "token":
            token = token or self.token
            if not token:
                return False, "Falta el token del tunel de Cloudflare."
            # recordar el token para futuros arranques / auto-inicio
            if token != self.token:
                self.set_config(token=token)
            cmd = [cf, "tunnel", "run", "--token", token]
            self.target = "tunel con nombre (token)"
        elif mode == "tcp":
            if not target:
                return False, "Falta el destino TCP (ej: tcp://localhost:25565)."
            cmd = [cf, "tunnel", "--no-autoupdate", "--url", target]
            self.target = target
        else:  # panel (http quick tunnel)
            target = target or "http://localhost:8080"
            cmd = [cf, "tunnel", "--no-autoupdate", "--url", target]
            self.target = target

        try:
            self.process = subprocess.Popen(
                cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, bufsize=1,
            )
        except Exception as exc:  # noqa: BLE001
            return False, f"No se pudo iniciar cloudflared: {exc}"

        self.mode = mode
        self.public_url = None
        self._log(f"*** Iniciando tunel Cloudflare (modo={mode}, destino={self.target}) ***")
        threading.Thread(target=self._read_output, daemon=True).start()
        return True, "Tunel iniciado. La URL publica aparecera en unos segundos."

    def stop(self) -> tuple[bool, str]:
        if not self.is_running:
            return False, "No hay ningun tunel en ejecucion."
        self.process.terminate()
        try:
            self.process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            self.process.kill()
        self.public_url = None
        self.mode = None
        return True, "Tunel detenido."

    # --- servicio 24/7 (cloudflared service install) -------------------------
    def install_service(self, token: str | None = None) -> tuple[bool, str]:
        """Instala cloudflared como servicio del sistema (24/7, auto-arranque).

        Equivale a: sudo cloudflared service install <TOKEN>
        Suele requerir privilegios de administrador.
        """
        cf = self.binary()
        if not cf:
            return False, INSTALL_HELP
        token = (token or self.token or "").strip()
        if not token:
            return False, "Falta el token para instalar el servicio."
        if token != self.token:
            self.set_config(token=token)
        ok, out = _run([cf, "service", "install", token])
        self._log(f"*** service install -> {'OK' if ok else 'ERROR'}: {out[:200]} ***")
        if not ok:
            low = out.lower()
            if "permission" in low or "denied" in low or "root" in low or "administrator" in low:
                return False, ("No se pudo instalar el servicio por permisos. Ejecuta el panel "
                               "con administrador, o lanza manualmente:  sudo cloudflared service "
                               f"install {token}")
            return False, f"No se pudo instalar el servicio: {out or 'error desconocido'}"
        return True, ("Servicio instalado. El tunel se ejecutara 24/7 y arrancara con el sistema. "
                      "Gestionalo con: systemctl status cloudflared")

    def uninstall_service(self) -> tuple[bool, str]:
        cf = self.binary()
        if not cf:
            return False, INSTALL_HELP
        ok, out = _run([cf, "service", "uninstall"])
        self._log(f"*** service uninstall -> {'OK' if ok else 'ERROR'}: {out[:200]} ***")
        if not ok:
            return False, f"No se pudo desinstalar el servicio: {out or 'error'}"
        return True, "Servicio de cloudflared desinstalado."

    def service_status(self) -> str:
        """Estado del servicio del sistema (Linux con systemd)."""
        if not sys.platform.startswith("linux"):
            return "desconocido"
        ok, out = _run(["systemctl", "is-active", "cloudflared"])
        return out.strip() or ("activo" if ok else "inactivo")

    def status(self) -> dict:
        with self._lock:
            recent = list(self.log)[-40:]
        return {
            "installed": self.is_installed(),
            "running": self.is_running,
            "mode": self.mode,
            "target": self.target,
            "public_url": self.public_url,
            "log": recent,
            "install_help": INSTALL_HELP,
            "has_token": bool(self.token),
            "autostart": self.autostart,
            "service": self.service_status(),
        }
