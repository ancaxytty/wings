"""
CloudflareManager: integracion con Cloudflare Tunnel (cloudflared).

Permite exponer el panel (y opcionalmente un servidor) a internet 24/7 a
traves de un tunel de Cloudflare, sin abrir puertos en el router.

Modos soportados:
  - "panel": tunel rapido (trycloudflare) que publica el panel web por HTTPS.
             Devuelve una URL publica https://....trycloudflare.com
  - "tcp"  : tunel rapido TCP para el puerto del servidor de Minecraft.
             (Los clientes necesitan 'cloudflared access tcp' o Spectrum de pago
             para conectar por el puerto del juego; ver README.)
  - "token": ejecuta un tunel CON NOMBRE usando un token del panel Zero Trust
             de Cloudflare (recomendado para 24/7 con dominio propio).

Requiere el binario 'cloudflared' instalado (o la variable CLOUDFLARED_PATH).
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import threading
from collections import deque
from datetime import datetime

TRYCF_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
INSTALL_HELP = (
    "cloudflared no esta instalado. Instalalo desde "
    "https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/ "
    "o define la variable de entorno CLOUDFLARED_PATH con la ruta al binario."
)


class CloudflareManager:
    def __init__(self):
        self.process: subprocess.Popen | None = None
        self.mode: str | None = None
        self.target: str | None = None
        self.public_url: str | None = None
        self.log: deque[str] = deque(maxlen=300)
        self._lock = threading.Lock()

    # --- deteccion -----------------------------------------------------------
    def binary(self) -> str | None:
        env = os.environ.get("CLOUDFLARED_PATH")
        if env and os.path.exists(env):
            return env
        found = shutil.which("cloudflared")
        if found:
            return found
        # ubicaciones comunes
        for p in ("/usr/local/bin/cloudflared", "/usr/bin/cloudflared",
                  os.path.expanduser("~/.local/bin/cloudflared"),
                  os.path.expanduser("~/cloudflared")):
            if os.path.exists(p):
                return p
        return None

    def is_installed(self) -> bool:
        return self.binary() is not None

    @property
    def is_running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    # --- logging -------------------------------------------------------------
    def _log(self, line: str):
        ts = datetime.now().strftime("%H:%M:%S")
        with self._lock:
            self.log.append(f"[{ts}] {line.rstrip()}")

    def _read_output(self):
        assert self.process and self.process.stdout
        for raw in self.process.stdout:
            self._log(raw)
            if not self.public_url:
                m = TRYCF_RE.search(raw)
                if m:
                    self.public_url = m.group(0)
                    self._log(f"*** URL publica detectada: {self.public_url} ***")
        self._log("*** El tunel de Cloudflare se ha detenido ***")
        self.public_url = None

    # --- ciclo de vida -------------------------------------------------------
    def start(self, mode: str, target: str | None = None,
              token: str | None = None) -> tuple[bool, str]:
        if self.is_running:
            return False, "Ya hay un tunel en ejecucion. Detenlo primero."
        cf = self.binary()
        if not cf:
            return False, INSTALL_HELP

        if mode == "token":
            if not token:
                return False, "Falta el token del tunel de Cloudflare."
            cmd = [cf, "tunnel", "--no-autoupdate", "run", "--token", token]
            self.target = "tunel con nombre (token)"
        elif mode == "tcp":
            if not target:
                return False, "Falta el destino TCP (ej: tcp://localhost:25565)."
            cmd = [cf, "tunnel", "--no-autoupdate", "--url", target]
            self.target = target
        else:  # panel (http quick tunnel)
            target = target or "http://localhost:8080"
            cmd = [cf, "tunnel", "--no-autoupdate", "--url", target]
            self.target = target

        try:
            self.process = subprocess.Popen(
                cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, bufsize=1,
            )
        except Exception as exc:  # noqa: BLE001
            return False, f"No se pudo iniciar cloudflared: {exc}"

        self.mode = mode
        self.public_url = None
        self._log(f"*** Iniciando tunel Cloudflare (modo={mode}, destino={self.target}) ***")
        threading.Thread(target=self._read_output, daemon=True).start()
        return True, "Tunel iniciado. La URL publica aparecera en unos segundos."

    def stop(self) -> tuple[bool, str]:
        if not self.is_running:
            return False, "No hay ningun tunel en ejecucion."
        self.process.terminate()
        try:
            self.process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            self.process.kill()
        self.public_url = None
        self.mode = None
        return True, "Tunel detenido."

    def status(self) -> dict:
        with self._lock:
            recent = list(self.log)[-40:]
        return {
            "installed": self.is_installed(),
            "running": self.is_running,
            "mode": self.mode,
            "target": self.target,
            "public_url": self.public_url,
            "log": recent,
            "install_help": INSTALL_HELP,
        }
