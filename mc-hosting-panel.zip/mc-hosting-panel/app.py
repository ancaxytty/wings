"""
Panel de Hosting de Minecraft - Backend Flask.

Sirve la interfaz web y expone una API REST para gestionar servidores
de Minecraft (Paper / Purpur / Vanilla / jar personalizado).

Ejecutar:
    pip install -r requirements.txt
    python app.py

Luego abre http://localhost:8080  (o http://TU_IP:8080)
"""

from __future__ import annotations

import threading

from flask import Flask, jsonify, request, send_from_directory, send_file
from flask_cors import CORS

from server_manager import ServerManager, detect_java_installations

app = Flask(__name__, static_folder="static", static_url_path="")
CORS(app)

manager = ServerManager()

# Estado de descargas en curso: {server_id: {"percent": int, "done": bool, "error": str|None}}
downloads: dict[str, dict] = {}


# ----------------------------------------------------------------------------
# Frontend
# ----------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# ----------------------------------------------------------------------------
# API: servidores
# ----------------------------------------------------------------------------
@app.get("/api/servers")
def list_servers():
    return jsonify(manager.list_servers())


@app.post("/api/servers")
def create_server():
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "El nombre es obligatorio."}), 400
    try:
        server = manager.create_server(
            name=name,
            server_type=data.get("server_type", "paper"),
            version=data.get("version", "latest"),
            port=int(data.get("port", 25565)),
            memory=int(data.get("memory", 2048)),
            world_preset=data.get("world_preset", "normal"),
            jvm_flags=data.get("jvm_flags", "aikar"),
            java_path=data.get("java_path") or None,
        )
    except (ValueError, TypeError) as exc:
        return jsonify({"error": f"Datos invalidos: {exc}"}), 400
    return jsonify(server.to_dict()), 201


@app.get("/api/servers/<server_id>")
def get_server(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    return jsonify(server.to_dict(full=True))


@app.delete("/api/servers/<server_id>")
def delete_server(server_id):
    if manager.delete_server(server_id):
        return jsonify({"ok": True})
    return jsonify({"error": "No encontrado"}), 404


# ----------------------------------------------------------------------------
# API: control de ciclo de vida
# ----------------------------------------------------------------------------
def _action(server_id, fn_name):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    ok, msg = getattr(server, fn_name)()
    return jsonify({"ok": ok, "message": msg}), (200 if ok else 400)


@app.post("/api/servers/<server_id>/start")
def start_server(server_id):
    return _action(server_id, "start")


@app.post("/api/servers/<server_id>/stop")
def stop_server(server_id):
    return _action(server_id, "stop")


@app.post("/api/servers/<server_id>/restart")
def restart_server(server_id):
    return _action(server_id, "restart")


@app.post("/api/servers/<server_id>/command")
def send_command(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    cmd = (request.get_json(force=True).get("command") or "").strip()
    if not cmd:
        return jsonify({"error": "Comando vacio"}), 400
    ok, msg = server.send_command(cmd)
    return jsonify({"ok": ok, "message": msg}), (200 if ok else 400)


# ----------------------------------------------------------------------------
# API: consola
# ----------------------------------------------------------------------------
@app.get("/api/servers/<server_id>/console")
def console(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    since = int(request.args.get("since", 0))
    lines, total = server.get_console(since)
    return jsonify({"lines": lines, "total": total, "running": server.is_running,
                    "players": server.players})


# ----------------------------------------------------------------------------
# API: propiedades
# ----------------------------------------------------------------------------
@app.get("/api/servers/<server_id>/properties")
def get_properties(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    return jsonify(server.read_properties())


@app.put("/api/servers/<server_id>/properties")
def update_properties(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    props = request.get_json(force=True)
    if not isinstance(props, dict):
        return jsonify({"error": "Formato invalido"}), 400
    server.write_properties({str(k): str(v) for k, v in props.items()})
    manager._save()
    return jsonify({"ok": True, "properties": server.read_properties()})


# ----------------------------------------------------------------------------
# API: versiones y descarga de jar
# ----------------------------------------------------------------------------
@app.get("/api/versions")
def versions():
    server_type = request.args.get("type", "paper")
    return jsonify({"versions": manager.available_versions(server_type)})


@app.post("/api/servers/<server_id>/download")
def download(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    if downloads.get(server_id, {}).get("running"):
        return jsonify({"error": "Ya hay una descarga en curso."}), 409

    downloads[server_id] = {"running": True, "percent": 0, "done": False, "error": None}

    def progress(done, total):
        downloads[server_id]["percent"] = int(done * 100 / total)

    def worker():
        ok, msg = manager.download_jar(server_id, progress)
        downloads[server_id].update({"running": False, "done": ok,
                                      "error": None if ok else msg,
                                      "percent": 100 if ok else downloads[server_id]["percent"],
                                      "message": msg})

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"ok": True, "message": "Descarga iniciada."})


@app.get("/api/servers/<server_id>/download/status")
def download_status(server_id):
    return jsonify(downloads.get(server_id, {"running": False, "percent": 0, "done": False, "error": None}))


# ----------------------------------------------------------------------------
# API: subir jar personalizado
# ----------------------------------------------------------------------------
@app.post("/api/servers/<server_id>/upload")
def upload_jar(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    if "file" not in request.files:
        return jsonify({"error": "No se envio ningun archivo."}), 400
    file = request.files["file"]
    if not file.filename.endswith(".jar"):
        return jsonify({"error": "El archivo debe ser un .jar"}), 400
    server.directory.mkdir(parents=True, exist_ok=True)
    file.save(str(server.jar_path))
    return jsonify({"ok": True, "message": "Jar subido correctamente."})


# ----------------------------------------------------------------------------
# API: gestor de archivos
# ----------------------------------------------------------------------------
def _fm_server(server_id):
    server = manager.get(server_id)
    if not server:
        return None, (jsonify({"error": "No encontrado"}), 404)
    return server, None


@app.get("/api/servers/<server_id>/files")
def fm_list(server_id):
    server, err = _fm_server(server_id)
    if err:
        return err
    try:
        return jsonify(server.list_dir(request.args.get("path", "")))
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.get("/api/servers/<server_id>/files/content")
def fm_read(server_id):
    server, err = _fm_server(server_id)
    if err:
        return err
    try:
        return jsonify({"content": server.read_text_file(request.args.get("path", ""))})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.put("/api/servers/<server_id>/files/content")
def fm_write(server_id):
    server, err = _fm_server(server_id)
    if err:
        return err
    data = request.get_json(force=True)
    path = data.get("path", "")
    if not path:
        return jsonify({"error": "Falta la ruta."}), 400
    try:
        server.write_text_file(path, data.get("content", ""))
        return jsonify({"ok": True, "message": "Archivo guardado."})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/servers/<server_id>/files/folder")
def fm_mkdir(server_id):
    server, err = _fm_server(server_id)
    if err:
        return err
    path = request.get_json(force=True).get("path", "")
    if not path:
        return jsonify({"error": "Falta la ruta."}), 400
    try:
        server.make_dir(path)
        return jsonify({"ok": True, "message": "Carpeta creada."})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.delete("/api/servers/<server_id>/files")
def fm_delete(server_id):
    server, err = _fm_server(server_id)
    if err:
        return err
    try:
        server.delete_path(request.args.get("path", ""))
        return jsonify({"ok": True, "message": "Eliminado."})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/servers/<server_id>/files/upload")
def fm_upload(server_id):
    server, err = _fm_server(server_id)
    if err:
        return err
    if "file" not in request.files:
        return jsonify({"error": "No se envio ningun archivo."}), 400
    file = request.files["file"]
    rel_dir = request.form.get("path", "")
    try:
        dest = server.upload_destination(rel_dir, file.filename)
        file.save(str(dest))
        return jsonify({"ok": True, "message": "Archivo subido."})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.get("/api/servers/<server_id>/files/download")
def fm_download(server_id):
    server, err = _fm_server(server_id)
    if err:
        return err
    try:
        path = server.download_path(request.args.get("path", ""))
        return send_file(str(path), as_attachment=True, download_name=path.name)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


# ----------------------------------------------------------------------------
# API: Java disponible y override por servidor
# ----------------------------------------------------------------------------
@app.get("/api/java")
def java_list():
    return jsonify({"installations": detect_java_installations(refresh=request.args.get("refresh") == "1")})


@app.put("/api/servers/<server_id>/java")
def set_java(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    path = (request.get_json(force=True).get("java_path") or "").strip() or None
    server.java_path = path
    manager._save()
    return jsonify({"ok": True, "java_path": server.java_path})


# ----------------------------------------------------------------------------
# API: metricas en vivo (CPU, RAM, uptime, TPS)
# ----------------------------------------------------------------------------
@app.get("/api/servers/<server_id>/metrics")
def metrics(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    return jsonify(server.get_metrics())


# ----------------------------------------------------------------------------
# API: backups
# ----------------------------------------------------------------------------
@app.get("/api/servers/<server_id>/backups")
def backups_list(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    return jsonify({"backups": server.list_backups()})


@app.post("/api/servers/<server_id>/backups")
def backups_create(server_id):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    try:
        info = server.create_backup()
        return jsonify({"ok": True, "backup": info, "message": "Backup creado."})
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": f"Error al crear backup: {exc}"}), 400


@app.delete("/api/servers/<server_id>/backups/<name>")
def backups_delete(server_id, name):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    try:
        server.delete_backup(name)
        return jsonify({"ok": True, "message": "Backup eliminado."})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/servers/<server_id>/backups/<name>/restore")
def backups_restore(server_id, name):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    try:
        server.restore_backup(name)
        return jsonify({"ok": True, "message": "Backup restaurado."})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.get("/api/servers/<server_id>/backups/<name>/download")
def backups_download(server_id, name):
    server = manager.get(server_id)
    if not server:
        return jsonify({"error": "No encontrado"}), 404
    try:
        path = server.download_backup(name)
        return send_file(str(path), as_attachment=True, download_name=path.name)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


if __name__ == "__main__":
    print("=" * 60)
    print("  Panel de Hosting de Minecraft")
    print("  Abre:  http://localhost:8080")
    print("  LAN :  http://<TU_IP_LOCAL>:8080")
    print("=" * 60)
    app.run(host="0.0.0.0", port=8080, threaded=True, debug=False)
