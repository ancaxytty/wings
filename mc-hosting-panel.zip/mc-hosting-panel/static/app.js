// ===========================================================================
//  NEBULA HOST · frontend
// ===========================================================================
const API = "/api";

let currentId = null;
let currentSection = "dashboard";
let consoleSince = 0;
let pollTimer = null;     // consola
let metricTimer = null;   // metricas
let listTimer = null;     // lista servidores
let downloadTimer = null;
let fmPath = "";
let editorPath = null;

// iconos SVG (sin emojis)
const ICON_DIR = '<svg viewBox="0 0 24 24" width="15" height="15" style="vertical-align:-2px" fill="none" stroke="#34e7ff" stroke-width="1.8"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';
const ICON_FILE = '<svg viewBox="0 0 24 24" width="15" height="15" style="vertical-align:-2px" fill="none" stroke="#8b99c4" stroke-width="1.8"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></svg>';

// buffers del grafico
const CHART_POINTS = 60;
let cpuData = new Array(CHART_POINTS).fill(0);
let ramData = new Array(CHART_POINTS).fill(0);

// --- helpers ---------------------------------------------------------------
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

async function api(path, options = {}) {
  const res = await fetch(API + path, { headers: { "Content-Type": "application/json" }, ...options });
  let data = null;
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error((data && (data.error || data.message)) || res.statusText);
  return data;
}

function toast(msg, type = "") {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast " + type;
  setTimeout(() => t.classList.add("hidden"), 3400);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function fmtSize(b) {
  if (b < 1024) return b + " B";
  if (b < 1048576) return (b / 1024).toFixed(1) + " KB";
  if (b < 1073741824) return (b / 1048576).toFixed(1) + " MB";
  return (b / 1073741824).toFixed(2) + " GB";
}

function fmtUptime(s) {
  if (!s) return "--";
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${sec}s`;
  return `${sec}s`;
}

// --- lista de servidores ----------------------------------------------------
async function loadServers() {
  let servers = [];
  try { servers = await api("/servers"); } catch (e) { return; }

  const sel = $("#server-select");
  const prev = currentId;
  sel.innerHTML = "";
  if (!servers.length) {
    sel.innerHTML = '<option value="">(sin servidores)</option>';
  }
  servers.forEach((s) => {
    const o = document.createElement("option");
    o.value = s.id;
    o.textContent = `${s.running ? "\u25CF" : "\u25CB"} ${s.name}`;
    sel.appendChild(o);
  });

  if (servers.length && !currentId) {
    selectServer(servers[0].id);
  } else if (currentId) {
    sel.value = currentId;
    const s = servers.find((x) => x.id === currentId);
    if (s) updateHeader(s);
  }
}

// --- seleccionar servidor ---------------------------------------------------
async function selectServer(id) {
  if (!id) return;
  currentId = id;
  consoleSince = 0;
  fmPath = "";
  cpuData = new Array(CHART_POINTS).fill(0);
  ramData = new Array(CHART_POINTS).fill(0);
  $("#console").textContent = "";
  $("#empty-state").classList.add("hidden");
  $("#sections").classList.remove("hidden");
  $("#server-select").value = id;

  let s;
  try { s = await api(`/servers/${id}`); } catch (e) { return; }
  updateHeader(s);
  updateInfoCard(s);
  renderProperties(s.properties || {});
  loadJavaForServer(s);

  startPolling();
  if (currentSection === "files") loadFiles("");
  if (currentSection === "backups") loadBackups();
}

function updateHeader(s) {
  $("#d-name").textContent = s.name;
  const tags = [
    `<span class="tag">${escapeHtml(s.server_type)}</span>`,
    `<span class="tag">${escapeHtml(s.version)}</span>`,
    `<span class="tag">${s.memory}MB</span>`,
    `<span class="tag">${escapeHtml(s.world_preset || "normal")}</span>`,
    s.jvm_flags === "aikar" ? `<span class="tag green">Optimizado</span>` : "",
    s.has_jar ? "" : `<span class="tag">sin jar</span>`,
  ];
  $("#d-tags").innerHTML = tags.join("");
  $("#btn-start").disabled = s.running || !s.has_jar;
  $("#btn-stop").disabled = !s.running;
  $("#btn-restart").disabled = !s.has_jar;
  $("#btn-download").disabled = s.server_type === "custom";
  $("#btn-delete").disabled = false;
}

function updateInfoCard(s) {
  $("#info-type").textContent = s.server_type;
  $("#info-version").textContent = s.version;
  $("#info-port").textContent = s.port;
  $("#info-mem").textContent = s.memory + " MB";
  $("#info-world").textContent = s.world_preset || "normal";
  $("#info-java").textContent = s.java_label || (s.java_path ? "manual" : "automatico");
  $("#info-origin").textContent = s.imported ? "importado (externo)" : "local";
  $("#ip-local").textContent = `localhost:${s.port}`;
  $("#ip-lan").textContent = `${location.hostname}:${s.port}`;
  setOnline(s.running);
}

function setOnline(running) {
  $("#info-dot").className = "info-dot " + (running ? "online" : "offline");
  $("#info-state").textContent = running ? "ONLINE" : "OFFLINE";
}

// --- navegacion de secciones ------------------------------------------------
function setupNav() {
  $$(".nav-item").forEach((b) => {
    b.onclick = () => {
      $$(".nav-item").forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
      currentSection = b.dataset.section;
      $$(".section").forEach((s) => s.classList.remove("active"));
      $(`#sec-${currentSection}`).classList.add("active");
      if (currentSection === "files") loadFiles("");
      if (currentSection === "backups") loadBackups();
      if (currentSection === "network") loadCloudflare();
      if (currentSection === "memory") loadMemory();
      if (currentSection === "plugins") loadInstalledPlugins();
    };
  });
}

// --- polling consola + metricas --------------------------------------------
function startPolling() {
  stopPolling();
  pollConsole();
  pollMetrics();
  pollTimer = setInterval(pollConsole, 1200);
  metricTimer = setInterval(pollMetrics, 2000);
}
function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  if (metricTimer) clearInterval(metricTimer);
  pollTimer = metricTimer = null;
}

async function pollConsole() {
  if (!currentId) return;
  let data;
  try { data = await api(`/servers/${currentId}/console?since=${consoleSince}`); } catch (e) { return; }
  if (data.lines && data.lines.length) {
    const box = $("#console");
    const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
    box.textContent += (box.textContent ? "\n" : "") + data.lines.join("\n");
    consoleSince = data.total;
    if (atBottom) box.scrollTop = box.scrollHeight;
  }
}

async function pollMetrics() {
  if (!currentId) return;
  let m;
  try { m = await api(`/servers/${currentId}/metrics`); } catch (e) { return; }

  setOnline(m.running);
  $("#btn-stop").disabled = !m.running;

  // push al grafico
  cpuData.push(m.running ? m.cpu : 0); cpuData.shift();
  ramData.push(m.running ? m.ram_pct : 0); ramData.shift();
  drawChart();

  $("#ro-cpu").textContent = m.cpu + "%";
  $("#ro-ram").textContent = m.ram_mb + " MB";
  $("#ro-ram-pct").textContent = m.running ? `(${m.ram_pct}% de ${m.ram_max_mb}MB)` : "";
  $("#w-players").textContent = m.players;
  $("#w-uptime").textContent = fmtUptime(m.uptime);
  $("#w-tps").textContent = m.tps != null ? m.tps.toFixed(1) : "--";
  $("#info-players").textContent = m.players;
  if (m.java) $("#info-java").textContent = m.java;

  pollSystem();
}

// --- metricas del host (CPU/RAM/Disco) -------------------------------------
async function pollSystem() {
  let s;
  try { s = await api("/system"); } catch (e) { return; }
  $("#sys-cpu-val").textContent = s.cpu_percent + "%";
  $("#sys-cpu-fill").style.width = s.cpu_percent + "%";
  $("#sys-cpu-sub").textContent = `${s.cpu_cores} nucleos`;
  $("#sys-ram-val").textContent = s.ram_percent + "%";
  $("#sys-ram-fill").style.width = s.ram_percent + "%";
  $("#sys-ram-sub").textContent = `${s.ram_used_mb} / ${s.ram_total_mb} MB`;
  $("#sys-disk-val").textContent = s.disk_percent + "%";
  $("#sys-disk-fill").style.width = s.disk_percent + "%";
  $("#sys-disk-sub").textContent = `${s.disk_used_gb} / ${s.disk_total_gb} GB`;
  if (s.load_avg) $("#sys-load").textContent = "carga " + s.load_avg.join(" / ");
}

// --- grafico canvas (CPU verde, RAM azul) -----------------------------------
function drawChart() {
  const cv = $("#chart");
  const dpr = window.devicePixelRatio || 1;
  const w = cv.clientWidth, h = cv.height;
  if (cv.width !== w * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
  const ctx = cv.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  // grid tenue
  ctx.strokeStyle = "rgba(120,140,220,0.12)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = (h / 4) * i;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }
  for (let i = 0; i <= 6; i++) {
    const x = (w / 6) * i;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }

  const line = (data, color, glow) => {
    ctx.beginPath();
    data.forEach((v, i) => {
      const x = (w / (CHART_POINTS - 1)) * i;
      const y = h - (Math.max(0, Math.min(100, v)) / 100) * (h - 8) - 4;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = glow; ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;
    // area
    ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath();
    ctx.fillStyle = glow.replace(/[\d.]+\)$/, "0.08)");
    ctx.fill();
  };
  line(ramData, "#2fa8ff", "rgba(47,168,255,0.6)");
  line(cpuData, "#00ff66", "rgba(0,255,102,0.6)");
}

// --- acciones ciclo de vida -------------------------------------------------
async function action(name) {
  try {
    const r = await api(`/servers/${currentId}/${name}`, { method: "POST" });
    toast(r.message || "Hecho", r.ok ? "ok" : "err");
    loadServers();
    setTimeout(() => { if (currentId) selectServer(currentId); }, 400);
  } catch (e) { toast(e.message, "err"); }
}

async function sendCommand(e) {
  e.preventDefault();
  const input = $("#cmd-input");
  const cmd = input.value.trim();
  if (!cmd) return;
  try {
    await api(`/servers/${currentId}/command`, { method: "POST", body: JSON.stringify({ command: cmd }) });
    input.value = "";
    setTimeout(pollConsole, 200);
  } catch (e) { toast(e.message, "err"); }
}

// --- descarga / subida jar --------------------------------------------------
async function downloadJar() {
  try { await api(`/servers/${currentId}/download`, { method: "POST" }); }
  catch (e) { toast(e.message, "err"); return; }
  $("#download-bar").classList.remove("hidden");
  $("#download-fill").style.width = "0%";
  if (downloadTimer) clearInterval(downloadTimer);
  downloadTimer = setInterval(checkDownload, 800);
}
async function checkDownload() {
  let st;
  try { st = await api(`/servers/${currentId}/download/status`); } catch (e) { return; }
  $("#download-fill").style.width = (st.percent || 0) + "%";
  $("#download-text").textContent = st.running ? `Descargando... ${st.percent}%` : (st.done ? "Completado" : "Error");
  if (!st.running) {
    clearInterval(downloadTimer);
    if (st.done) { toast("Jar descargado.", "ok"); setTimeout(() => $("#download-bar").classList.add("hidden"), 1400); selectServer(currentId); }
    else toast(st.error || st.message || "Error al descargar.", "err");
  }
}
async function uploadJar(e) {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData(); fd.append("file", file);
  try {
    const res = await fetch(`${API}/servers/${currentId}/upload`, { method: "POST", body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Error");
    toast("Jar subido.", "ok"); selectServer(currentId);
  } catch (err) { toast(err.message, "err"); }
  e.target.value = "";
}

async function deleteServer() {
  if (!confirm("Eliminar este servidor y todos sus archivos?")) return;
  try {
    await api(`/servers/${currentId}`, { method: "DELETE" });
    toast("Servidor eliminado.", "ok");
    currentId = null; stopPolling();
    $("#sections").classList.add("hidden");
    $("#empty-state").classList.remove("hidden");
    loadServers();
  } catch (e) { toast(e.message, "err"); }
}

// --- propiedades ------------------------------------------------------------
function renderProperties(props) {
  const grid = $("#props-grid");
  grid.innerHTML = "";
  const keys = Object.keys(props).sort();
  if (!keys.length) { grid.innerHTML = '<p class="hint">Inicia el servidor una vez para generar las propiedades.</p>'; return; }
  keys.forEach((k) => {
    const item = document.createElement("div");
    item.className = "prop-item";
    item.innerHTML = `<label>${escapeHtml(k)}</label><input data-key="${escapeHtml(k)}" value="${escapeHtml(props[k])}" />`;
    grid.appendChild(item);
  });
}
async function saveProperties() {
  const props = {};
  $$("#props-grid input").forEach((i) => { props[i.dataset.key] = i.value; });
  try {
    await api(`/servers/${currentId}/properties`, { method: "PUT", body: JSON.stringify(props) });
    toast("Propiedades guardadas. Reinicia para aplicar.", "ok");
  } catch (e) { toast(e.message, "err"); }
}

// --- gestor de archivos -----------------------------------------------------
async function loadFiles(path = "") {
  if (!currentId) return;
  let data;
  try { data = await api(`/servers/${currentId}/files?path=${encodeURIComponent(path)}`); }
  catch (e) { toast(e.message, "err"); return; }
  fmPath = data.path || "";
  $("#fm-path").textContent = "/" + fmPath;
  $("#fm-up").disabled = !fmPath;
  const body = $("#fm-body"); body.innerHTML = "";
  $("#fm-empty").classList.toggle("hidden", data.entries.length > 0);
  data.entries.forEach((e) => {
    const tr = document.createElement("tr");
    const icon = e.is_dir ? ICON_DIR : ICON_FILE;
    tr.innerHTML = `
      <td><span class="fm-name ${e.is_dir ? "dir" : ""}">${icon} ${escapeHtml(e.name)}</span></td>
      <td class="fm-size">${e.is_dir ? "" : fmtSize(e.size)}</td>
      <td class="fm-mod">${escapeHtml(e.modified)}</td>
      <td><div class="row-actions">
        ${e.editable ? '<button class="edit">Editar</button>' : ""}
        ${e.is_dir ? "" : '<button class="dl">Bajar</button>'}
        <button class="del">Borrar</button>
      </div></td>`;
    const nameEl = tr.querySelector(".fm-name");
    if (e.is_dir) nameEl.onclick = () => loadFiles(e.path);
    else if (e.editable) nameEl.onclick = () => openEditor(e.path, e.name);
    const ed = tr.querySelector(".edit"); if (ed) ed.onclick = () => openEditor(e.path, e.name);
    const dl = tr.querySelector(".dl"); if (dl) dl.onclick = () => window.open(`${API}/servers/${currentId}/files/download?path=${encodeURIComponent(e.path)}`, "_blank");
    tr.querySelector(".del").onclick = () => deleteFile(e.path, e.name);
    body.appendChild(tr);
  });
}
async function openEditor(path, name) {
  let data;
  try { data = await api(`/servers/${currentId}/files/content?path=${encodeURIComponent(path)}`); }
  catch (e) { toast(e.message, "err"); return; }
  editorPath = path;
  $("#editor-title").textContent = "Editar: " + name;
  $("#editor-area").value = data.content;
  $("#editor-modal").classList.remove("hidden");
}
async function saveEditor() {
  try {
    await api(`/servers/${currentId}/files/content`, { method: "PUT", body: JSON.stringify({ path: editorPath, content: $("#editor-area").value }) });
    toast("Archivo guardado.", "ok");
    $("#editor-modal").classList.add("hidden");
  } catch (e) { toast(e.message, "err"); }
}
async function deleteFile(path, name) {
  if (!confirm(`Borrar "${name}"?`)) return;
  try { await api(`/servers/${currentId}/files?path=${encodeURIComponent(path)}`, { method: "DELETE" }); loadFiles(fmPath); }
  catch (e) { toast(e.message, "err"); }
}
async function newFolder() {
  const name = prompt("Nombre de la carpeta:");
  if (!name) return;
  try { await api(`/servers/${currentId}/files/folder`, { method: "POST", body: JSON.stringify({ path: (fmPath ? fmPath + "/" : "") + name }) }); loadFiles(fmPath); }
  catch (e) { toast(e.message, "err"); }
}
async function uploadFile(e) {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData(); fd.append("file", file); fd.append("path", fmPath);
  try {
    const res = await fetch(`${API}/servers/${currentId}/files/upload`, { method: "POST", body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Error");
    toast("Archivo subido.", "ok"); loadFiles(fmPath);
  } catch (err) { toast(err.message, "err"); }
  e.target.value = "";
}

// --- backups ----------------------------------------------------------------
async function loadBackups() {
  if (!currentId) return;
  let data;
  try { data = await api(`/servers/${currentId}/backups`); } catch (e) { return; }
  const body = $("#bk-body"); body.innerHTML = "";
  $("#bk-empty").classList.toggle("hidden", data.backups.length > 0);
  data.backups.forEach((b) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(b.name)}</td>
      <td class="fm-size">${fmtSize(b.size)}</td>
      <td class="fm-mod">${escapeHtml(b.created)}</td>
      <td><div class="row-actions">
        <button class="dl">Bajar</button>
        <button class="restore">Restaurar</button>
        <button class="del">Borrar</button>
      </div></td>`;
    tr.querySelector(".dl").onclick = () => window.open(`${API}/servers/${currentId}/backups/${encodeURIComponent(b.name)}/download`, "_blank");
    tr.querySelector(".restore").onclick = () => restoreBackup(b.name);
    tr.querySelector(".del").onclick = () => deleteBackup(b.name);
    body.appendChild(tr);
  });
}
async function createBackup() {
  toast("Creando backup...", "");
  try { await api(`/servers/${currentId}/backups`, { method: "POST" }); toast("Backup creado.", "ok"); loadBackups(); }
  catch (e) { toast(e.message, "err"); }
}
async function restoreBackup(name) {
  if (!confirm("Restaurar este backup? Sobrescribira el mundo actual (servidor detenido).")) return;
  try { const r = await api(`/servers/${currentId}/backups/${encodeURIComponent(name)}/restore`, { method: "POST" }); toast(r.message, "ok"); }
  catch (e) { toast(e.message, "err"); }
}
async function deleteBackup(name) {
  if (!confirm("Borrar este backup?")) return;
  try { await api(`/servers/${currentId}/backups/${encodeURIComponent(name)}`, { method: "DELETE" }); loadBackups(); }
  catch (e) { toast(e.message, "err"); }
}

// --- Cloudflare Tunnel ------------------------------------------------------
let cfTimer = null;
async function loadCloudflare() {
  let st;
  try { st = await api("/cloudflare"); } catch (e) { return; }
  renderCloudflare(st);
  if (cfTimer) clearInterval(cfTimer);
  cfTimer = setInterval(async () => {
    if (currentSection !== "network") { clearInterval(cfTimer); cfTimer = null; return; }
    try { renderCloudflare(await api("/cloudflare")); } catch (e) {}
  }, 2500);
}
function renderCloudflare(st) {
  $("#cf-install").classList.toggle("hidden", st.installed);
  $("#cf-state").textContent = st.running ? "Activo" : "Detenido";
  $("#cf-state").className = "tag" + (st.running ? " green" : "");
  $("#cf-log").textContent = (st.log || []).join("\n");
  $("#cf-log").scrollTop = $("#cf-log").scrollHeight;
  // reflejar token guardado y auto-inicio (sin volver a pintar mientras el usuario escribe)
  if (st.has_token && !$("#cf-token").value && document.activeElement !== $("#cf-token")) {
    $("#cf-token").placeholder = "Token guardado (dejar vacio para conservarlo)";
  }
  if (document.activeElement !== $("#cf-autostart")) $("#cf-autostart").checked = !!st.autostart;
  $("#cf-service-state").textContent = "Servicio del sistema: " + (st.service || "desconocido");
  const box = $("#cf-url-box");
  if (st.public_url) {
    box.classList.remove("hidden");
    const a = $("#cf-url"); a.textContent = st.public_url; a.href = st.public_url;
    $("#ip-cf").textContent = st.public_url;
  } else {
    box.classList.add("hidden");
  }
}
async function cfStart() {
  const mode = $("#cf-mode").value;
  const body = { mode };
  const tok = $("#cf-token").value.trim();
  if (mode === "token" && tok) body.token = tok;
  if (mode === "tcp") body.server_id = currentId;
  try {
    const r = await api("/cloudflare/start", { method: "POST", body: JSON.stringify(body) });
    toast(r.message, r.ok ? "ok" : "err");
    if (r.status) renderCloudflare(r.status);
    loadCloudflare();
  } catch (e) { toast(e.message, "err"); }
}
async function cfStop() {
  try { const r = await api("/cloudflare/stop", { method: "POST" }); toast(r.message, r.ok ? "ok" : "err"); loadCloudflare(); }
  catch (e) { toast(e.message, "err"); }
}
async function cfSave() {
  const body = { autostart: $("#cf-autostart").checked };
  const tok = $("#cf-token").value.trim();
  if (tok) body.token = tok;
  try {
    const r = await api("/cloudflare/config", { method: "POST", body: JSON.stringify(body) });
    toast(r.message, "ok");
    $("#cf-token").value = "";
    loadCloudflare();
  } catch (e) { toast(e.message, "err"); }
}
async function cfServiceInstall() {
  const body = {};
  const tok = $("#cf-token").value.trim();
  if (tok) body.token = tok;
  toast("Instalando servicio 24/7...", "");
  try {
    const r = await api("/cloudflare/service/install", { method: "POST", body: JSON.stringify(body) });
    toast(r.message, r.ok ? "ok" : "err");
    if (r.status) renderCloudflare(r.status);
  } catch (e) { toast(e.message, "err"); }
}
async function cfServiceUninstall() {
  if (!confirm("Quitar el servicio 24/7 de cloudflared?")) return;
  try {
    const r = await api("/cloudflare/service/uninstall", { method: "POST" });
    toast(r.message, r.ok ? "ok" : "err");
    if (r.status) renderCloudflare(r.status);
  } catch (e) { toast(e.message, "err"); }
}

// --- memoria virtual (swap) -------------------------------------------------
let memTimer = null;
async function loadMemory() {
  let info;
  try { info = await api("/memory"); } catch (e) { return; }
  renderMemory(info);
  if (memTimer) clearInterval(memTimer);
  memTimer = setInterval(async () => {
    if (currentSection !== "memory") { clearInterval(memTimer); memTimer = null; return; }
    try { renderMemory(await api("/memory")); } catch (e) {}
  }, 3000);
}
function renderMemory(info) {
  $("#mem-virtual").textContent = `${info.virtual_total_mb} MB totales`;
  $("#mem-unsupported").classList.toggle("hidden", info.supported);
  const ramPct = info.ram_total_mb ? (info.ram_used_mb / info.ram_total_mb * 100) : 0;
  const swapPct = info.swap_total_mb ? (info.swap_used_mb / info.swap_total_mb * 100) : 0;
  $("#mem-ram-fill").style.width = ramPct + "%";
  $("#mem-swap-fill").style.width = swapPct + "%";
  $("#mem-ram-val").textContent = `${info.ram_used_mb} / ${info.ram_total_mb} MB`;
  $("#mem-swap-val").textContent = `${info.swap_used_mb} / ${info.swap_total_mb} MB`;
  const body = $("#mem-body"); body.innerHTML = "";
  const files = info.swapfiles || [];
  $("#mem-empty").classList.toggle("hidden", files.length > 0);
  files.forEach((f) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(f.name)}</td>
      <td class="fm-size">${f.size_mb} MB</td>
      <td class="fm-mod">${escapeHtml(f.created)}</td>
      <td><div class="row-actions"><button class="del">Eliminar</button></div></td>`;
    tr.querySelector(".del").onclick = () => deleteSwap(f.name);
    body.appendChild(tr);
  });
}
async function createSwap() {
  const size = parseInt($("#mem-size").value, 10);
  toast("Creando memoria virtual...", "");
  try {
    const r = await api("/memory/swap", { method: "POST", body: JSON.stringify({ size_mb: size }) });
    toast(r.message, r.ok ? "ok" : "err");
    if (r.info) renderMemory(r.info);
  } catch (e) { toast(e.message, "err"); }
}
async function deleteSwap(name) {
  if (!confirm(`Eliminar la memoria virtual "${name}"?`)) return;
  try { const r = await api(`/memory/swap/${encodeURIComponent(name)}`, { method: "DELETE" }); toast(r.message, r.ok ? "ok" : "err"); if (r.info) renderMemory(r.info); }
  catch (e) { toast(e.message, "err"); }
}

// --- plugins (Modrinth) -----------------------------------------------------
async function searchPlugins() {
  const q = $("#pl-query").value.trim();
  const loader = $("#pl-loader").value;
  const version = $("#pl-version").value.trim();
  const box = $("#pl-results");
  box.innerHTML = "";
  $("#pl-hint").textContent = "Buscando...";
  let data;
  try {
    const params = new URLSearchParams({ q, loader });
    if (version) params.set("version", version);
    data = await api(`/plugins/search?${params.toString()}`);
  } catch (e) { $("#pl-hint").textContent = "Error: " + e.message; return; }
  const results = data.results || [];
  $("#pl-hint").textContent = results.length ? "" : "Sin resultados.";
  results.forEach((p) => {
    const card = document.createElement("div");
    card.className = "pl-card";
    const icon = p.icon_url ? `<img class="pl-icon" src="${escapeHtml(p.icon_url)}" alt="" />` : '<div class="pl-icon"></div>';
    card.innerHTML = `
      ${icon}
      <div class="pl-info">
        <div class="pl-title">${escapeHtml(p.title || "")}</div>
        <div class="pl-author">por ${escapeHtml(p.author || "?")}</div>
        <div class="pl-desc">${escapeHtml(p.description || "")}</div>
        <div class="pl-meta">
          <span class="pl-dl">${(p.downloads || 0).toLocaleString()} descargas</span>
          <button class="chip chip-accent pl-install">Instalar</button>
        </div>
      </div>`;
    card.querySelector(".pl-install").onclick = () => installPlugin(p.project_id, p.title);
    box.appendChild(card);
  });
}
async function installPlugin(projectId, title) {
  if (!currentId) { toast("Selecciona un servidor primero.", "err"); return; }
  toast(`Instalando ${title}...`, "");
  try {
    const r = await api(`/servers/${currentId}/plugins/install`, {
      method: "POST",
      body: JSON.stringify({ project_id: projectId, loader: $("#pl-loader").value }),
    });
    toast(r.message, r.ok ? "ok" : "err");
    loadInstalledPlugins();
  } catch (e) { toast(e.message, "err"); }
}
async function loadInstalledPlugins() {
  if (!currentId) return;
  let data;
  try { data = await api(`/servers/${currentId}/plugins`); } catch (e) { return; }
  const body = $("#pl-installed"); body.innerHTML = "";
  const plugins = data.plugins || [];
  $("#pl-installed-empty").classList.toggle("hidden", plugins.length > 0);
  plugins.forEach((p) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(p.name)}</td>
      <td class="fm-size">${fmtSize(p.size)}</td>
      <td><div class="row-actions"><button class="del">Borrar</button></div></td>`;
    tr.querySelector(".del").onclick = () => deletePlugin(p.name);
    body.appendChild(tr);
  });
}
async function deletePlugin(name) {
  if (!confirm(`Borrar el plugin "${name}"?`)) return;
  try { const r = await api(`/servers/${currentId}/plugins/${encodeURIComponent(name)}`, { method: "DELETE" }); toast(r.message, "ok"); loadInstalledPlugins(); }
  catch (e) { toast(e.message, "err"); }
}

// --- importar servidor existente -------------------------------------------
function openImport() { $("#import-modal").classList.remove("hidden"); }
function closeImport() { $("#import-modal").classList.add("hidden"); }
async function importServer(e) {
  e.preventDefault();
  const body = {
    name: $("#i-name").value.trim(),
    data_dir: $("#i-path").value.trim(),
    jar: $("#i-jar").value.trim() || "server.jar",
    memory: parseInt($("#i-memory").value, 10),
    server_type: $("#i-type").value,
    version: $("#i-version").value.trim() || "latest",
  };
  try {
    const s = await api("/servers/import", { method: "POST", body: JSON.stringify(body) });
    closeImport(); $("#import-form").reset();
    toast("Servidor importado.", "ok");
    await loadServers();
    selectServer(s.id);
  } catch (err) { toast(err.message, "err"); }
}

// --- Java -------------------------------------------------------------------
let javaInstalls = [];
async function loadJavaList() {
  try { const d = await api("/java"); javaInstalls = d.installations || []; } catch (e) { javaInstalls = []; }
  // rellenar selects (crear + runtime)
  const opts = '<option value="">Automatico (recomendado)</option>' +
    javaInstalls.map((j) => `<option value="${escapeHtml(j.path)}">Java ${j.major} (${escapeHtml(j.version)})</option>`).join("");
  $("#f-java").innerHTML = opts;
  $("#java-select").innerHTML = opts;
}
function loadJavaForServer(s) {
  $("#java-select").value = s.java_path || "";
}
async function saveJava() {
  try {
    await api(`/servers/${currentId}/java`, { method: "PUT", body: JSON.stringify({ java_path: $("#java-select").value }) });
    toast("Java actualizado. Reinicia para aplicar.", "ok");
    selectServer(currentId);
  } catch (e) { toast(e.message, "err"); }
}

// --- crear servidor ---------------------------------------------------------
function openModal() { $("#modal").classList.remove("hidden"); loadVersions(); }
function closeModal() { $("#modal").classList.add("hidden"); }

async function loadVersions() {
  const type = $("#f-type").value;
  const sel = $("#f-version");
  if (type === "custom") { sel.innerHTML = '<option value="custom">(subiras el jar)</option>'; return; }
  sel.innerHTML = '<option value="latest">latest (cargando...)</option>';
  try {
    const d = await api(`/versions?type=${type}`);
    sel.innerHTML = '<option value="latest">latest</option>' + (d.versions || []).map((v) => `<option value="${v}">${v}</option>`).join("");
  } catch (e) { sel.innerHTML = '<option value="latest">latest</option>'; }
}

async function createServer(e) {
  e.preventDefault();
  const body = {
    name: $("#f-name").value.trim(),
    server_type: $("#f-type").value,
    version: $("#f-version").value,
    port: parseInt($("#f-port").value, 10),
    memory: parseInt($("#f-memory").value, 10),
    world_preset: $("#f-world").value,
    jvm_flags: $("#f-flags").value,
    java_path: $("#f-java").value || null,
    allow_overcommit: $("#f-overcommit").checked,
  };
  try {
    const s = await api("/servers", { method: "POST", body: JSON.stringify(body) });
    closeModal(); $("#create-form").reset();
    toast("Servidor creado. Descarga o sube el jar.", "ok");
    await loadServers();
    selectServer(s.id);
  } catch (err) { toast(err.message, "err"); }
}

// --- init -------------------------------------------------------------------
window.addEventListener("DOMContentLoaded", () => {
  setupNav();
  $("#server-select").onchange = (e) => selectServer(e.target.value);
  $("#btn-new").onclick = openModal;
  $("#btn-cancel").onclick = closeModal;
  $("#f-type").onchange = loadVersions;
  $("#create-form").onsubmit = createServer;
  $("#btn-start").onclick = () => action("start");
  $("#btn-stop").onclick = () => action("stop");
  $("#btn-restart").onclick = () => action("restart");
  $("#btn-download").onclick = downloadJar;
  $("#btn-delete").onclick = deleteServer;
  $("#file-jar").onchange = uploadJar;
  $("#cmd-form").onsubmit = sendCommand;
  $("#btn-save-props").onclick = saveProperties;

  $("#fm-up").onclick = () => { const p = fmPath.split("/").filter(Boolean); p.pop(); loadFiles(p.join("/")); };
  $("#fm-refresh").onclick = () => loadFiles(fmPath);
  $("#fm-newfolder").onclick = newFolder;
  $("#fm-file").onchange = uploadFile;
  $("#editor-save").onclick = saveEditor;
  $("#editor-cancel").onclick = () => $("#editor-modal").classList.add("hidden");

  $("#bk-create").onclick = createBackup;
  $("#java-save").onclick = saveJava;

  // cloudflare
  $("#cf-start").onclick = cfStart;
  $("#cf-stop").onclick = cfStop;
  $("#cf-save").onclick = cfSave;
  $("#cf-service-install").onclick = cfServiceInstall;
  $("#cf-service-uninstall").onclick = cfServiceUninstall;

  // importar
  $("#btn-import").onclick = openImport;
  $("#import-cancel").onclick = closeImport;
  $("#import-form").onsubmit = importServer;

  // memoria virtual
  $("#mem-create").onclick = createSwap;

  // plugins
  $("#pl-search").onclick = searchPlugins;
  $("#pl-query").addEventListener("keydown", (e) => { if (e.key === "Enter") searchPlugins(); });

  loadJavaList();
  loadServers();
  listTimer = setInterval(loadServers, 5000);
  window.addEventListener("resize", drawChart);
});
