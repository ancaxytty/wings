// ===========================================================================
//  MC Hosting Panel - logica del frontend
// ===========================================================================
const API = "/api";

let currentId = null;        // servidor seleccionado
let consoleSince = 0;        // indice de la ultima linea de consola recibida
let pollTimer = null;        // intervalo de refresco de consola/estado
let listTimer = null;        // intervalo de refresco de la lista
let downloadTimer = null;    // intervalo de progreso de descarga

// --- helpers ---------------------------------------------------------------
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

async function api(path, options = {}) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  let data = null;
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error((data && (data.error || data.message)) || res.statusText);
  return data;
}

function toast(msg, type = "") {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast " + type;
  setTimeout(() => t.classList.add("hidden"), 3200);
}

// --- lista de servidores ---------------------------------------------------
async function loadServers() {
  let servers = [];
  try { servers = await api("/servers"); } catch (e) { return; }

  $("#server-count").textContent = `${servers.length} servidor${servers.length === 1 ? "" : "es"}`;
  $("#empty-hint").classList.toggle("hidden", servers.length > 0);

  const list = $("#server-list");
  list.innerHTML = "";
  servers.forEach((s) => {
    const card = document.createElement("div");
    card.className = "server-card" + (s.id === currentId ? " active" : "");
    card.onclick = () => selectServer(s.id);
    card.innerHTML = `
      <span class="sc-status ${s.running ? "online" : "offline"}"></span>
      <div class="sc-name">${escapeHtml(s.name)}</div>
      <div class="sc-meta">${s.server_type} ${s.version} · puerto ${s.port} · ${s.memory}MB</div>
    `;
    list.appendChild(card);
  });

  // refrescar cabecera del detalle si esta abierto
  if (currentId) {
    const s = servers.find((x) => x.id === currentId);
    if (s) updateHeader(s);
  }
}

// --- seleccionar servidor ---------------------------------------------------
async function selectServer(id) {
  currentId = id;
  consoleSince = 0;
  $("#console").textContent = "";
  $("#detail-empty").classList.add("hidden");
  $("#detail-content").classList.remove("hidden");

  await loadServers();
  let s;
  try { s = await api(`/servers/${id}`); } catch (e) { return; }
  updateHeader(s);
  renderProperties(s.properties || {});
  updateConnect(s);

  startPolling();
}

function updateHeader(s) {
  $("#d-name").textContent = s.name;
  const flagTag = s.jvm_flags === "aikar" ? '<span class="perf-tag">Optimizado</span>' : "";
  const worldTag = s.world_preset ? `<span class="perf-tag">${s.world_preset}</span>` : "";
  $("#d-meta").innerHTML = `${escapeHtml(s.server_type)} · ${escapeHtml(s.version)} · puerto ${s.port} · ${s.memory}MB · ${s.has_jar ? "jar listo" : "sin jar"} ${worldTag}${flagTag}`;
  const dot = $("#d-status");
  dot.className = "status-dot " + (s.running ? "online" : "offline");
  $("#d-status-text").textContent = s.running ? "En linea" : "Detenido";
  $("#btn-start").disabled = s.running || !s.has_jar;
  $("#btn-stop").disabled = !s.running;
  $("#btn-restart").disabled = !s.has_jar;
}

function updateConnect(s) {
  $("#ip-local").textContent = `localhost:${s.port}`;
  $("#ip-lan").textContent = `${location.hostname}:${s.port}`;
}

// --- consola + estado (polling) --------------------------------------------
function startPolling() {
  stopPolling();
  pollConsole();
  pollTimer = setInterval(pollConsole, 1200);
}
function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

async function pollConsole() {
  if (!currentId) return;
  let data;
  try { data = await api(`/servers/${currentId}/console?since=${consoleSince}`); }
  catch (e) { return; }

  if (data.lines && data.lines.length) {
    const box = $("#console");
    const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
    box.textContent += (box.textContent ? "\n" : "") + data.lines.join("\n");
    consoleSince = data.total;
    if (atBottom) box.scrollTop = box.scrollHeight;
  }

  // estado en vivo
  const dot = $("#d-status");
  dot.className = "status-dot " + (data.running ? "online" : "offline");
  $("#d-status-text").textContent = data.running ? "En linea" : "Detenido";
  $("#btn-stop").disabled = !data.running;

  renderPlayers(data.players || []);
}

function renderPlayers(players) {
  const ul = $("#player-list");
  ul.innerHTML = "";
  players.forEach((p) => {
    const li = document.createElement("li");
    li.textContent = p;
    ul.appendChild(li);
  });
  $("#player-empty").classList.toggle("hidden", players.length > 0);
}

// --- propiedades ------------------------------------------------------------
function renderProperties(props) {
  const grid = $("#props-grid");
  grid.innerHTML = "";
  const keys = Object.keys(props).sort();
  if (!keys.length) { grid.innerHTML = '<p class="hint">No hay propiedades aun. Inicia el servidor una vez para generarlas.</p>'; return; }
  keys.forEach((k) => {
    const item = document.createElement("div");
    item.className = "prop-item";
    item.innerHTML = `<label>${escapeHtml(k)}</label><input data-key="${escapeHtml(k)}" value="${escapeHtml(props[k])}" />`;
    grid.appendChild(item);
  });
}

async function saveProperties() {
  const props = {};
  $$("#props-grid input").forEach((inp) => { props[inp.dataset.key] = inp.value; });
  try {
    await api(`/servers/${currentId}/properties`, { method: "PUT", body: JSON.stringify(props) });
    toast("Propiedades guardadas. Reinicia el servidor para aplicarlas.", "ok");
  } catch (e) { toast(e.message, "err"); }
}

// --- acciones de ciclo de vida ---------------------------------------------
async function action(name) {
  try {
    const r = await api(`/servers/${currentId}/${name}`, { method: "POST" });
    toast(r.message || "Hecho", "ok");
    loadServers();
  } catch (e) { toast(e.message, "err"); }
}

async function sendCommand(e) {
  e.preventDefault();
  const input = $("#cmd-input");
  const cmd = input.value.trim();
  if (!cmd) return;
  try {
    await api(`/servers/${currentId}/command`, { method: "POST", body: JSON.stringify({ command: cmd }) });
    input.value = "";
    setTimeout(pollConsole, 200);
  } catch (e) { toast(e.message, "err"); }
}

// --- descarga de jar --------------------------------------------------------
async function downloadJar() {
  try {
    await api(`/servers/${currentId}/download`, { method: "POST" });
  } catch (e) { toast(e.message, "err"); return; }
  $("#download-bar").classList.remove("hidden");
  $("#download-fill").style.width = "0%";
  $("#download-text").textContent = "Descargando...";
  if (downloadTimer) clearInterval(downloadTimer);
  downloadTimer = setInterval(checkDownload, 800);
}

async function checkDownload() {
  let st;
  try { st = await api(`/servers/${currentId}/download/status`); } catch (e) { return; }
  $("#download-fill").style.width = (st.percent || 0) + "%";
  if (!st.running) {
    clearInterval(downloadTimer);
    if (st.done) {
      $("#download-text").textContent = "Completado";
      toast("Jar descargado correctamente.", "ok");
      setTimeout(() => $("#download-bar").classList.add("hidden"), 1500);
      selectServer(currentId);
    } else {
      $("#download-text").textContent = "Error";
      toast(st.error || st.message || "Error al descargar.", "err");
    }
  } else {
    $("#download-text").textContent = `Descargando... ${st.percent}%`;
  }
}

// --- subir jar --------------------------------------------------------------
async function uploadJar(e) {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  try {
    const res = await fetch(`${API}/servers/${currentId}/upload`, { method: "POST", body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Error");
    toast("Jar subido correctamente.", "ok");
    selectServer(currentId);
  } catch (err) { toast(err.message, "err"); }
  e.target.value = "";
}

// --- eliminar ---------------------------------------------------------------
async function deleteServer() {
  if (!confirm("Eliminar este servidor y todos sus archivos? Esta accion no se puede deshacer.")) return;
  try {
    await api(`/servers/${currentId}`, { method: "DELETE" });
    toast("Servidor eliminado.", "ok");
    currentId = null;
    stopPolling();
    $("#detail-content").classList.add("hidden");
    $("#detail-empty").classList.remove("hidden");
    loadServers();
  } catch (e) { toast(e.message, "err"); }
}

// --- crear servidor (modal) -------------------------------------------------
function openModal() {
  $("#modal").classList.remove("hidden");
  loadVersions();
}
function closeModal() { $("#modal").classList.add("hidden"); }

async function loadVersions() {
  const type = $("#f-type").value;
  const sel = $("#f-version");
  sel.innerHTML = '<option value="latest">latest (cargando...)</option>';
  if (type === "custom") { sel.innerHTML = '<option value="custom">(subiras el jar manualmente)</option>'; return; }
  try {
    const data = await api(`/versions?type=${type}`);
    sel.innerHTML = '<option value="latest">latest</option>';
    (data.versions || []).forEach((v) => {
      const o = document.createElement("option");
      o.value = v; o.textContent = v; sel.appendChild(o);
    });
  } catch (e) {
    sel.innerHTML = '<option value="latest">latest</option>';
  }
}

async function createServer(e) {
  e.preventDefault();
  const body = {
    name: $("#f-name").value.trim(),
    server_type: $("#f-type").value,
    version: $("#f-version").value,
    port: parseInt($("#f-port").value, 10),
    memory: parseInt($("#f-memory").value, 10),
    world_preset: $("#f-world").value,
    jvm_flags: $("#f-flags").value,
  };
  try {
    const s = await api("/servers", { method: "POST", body: JSON.stringify(body) });
    closeModal();
    $("#create-form").reset();
    toast("Servidor creado. Ahora descarga o sube el jar.", "ok");
    await loadServers();
    selectServer(s.id);
  } catch (err) { toast(err.message, "err"); }
}

// --- gestor de archivos -----------------------------------------------------
let fmPath = "";
let editorPath = null;

async function loadFiles(path = "") {
  if (!currentId) return;
  fmPath = path;
  let data;
  try { data = await api(`/servers/${currentId}/files?path=${encodeURIComponent(path)}`); }
  catch (e) { toast(e.message, "err"); return; }
  fmPath = data.path || "";
  $("#fm-path").textContent = "/" + fmPath;
  $("#fm-up").disabled = !fmPath;
  renderFiles(data.entries || []);
}

function renderFiles(entries) {
  const body = $("#fm-body");
  body.innerHTML = "";
  $("#fm-empty").classList.toggle("hidden", entries.length > 0);
  entries.forEach((e) => {
    const tr = document.createElement("tr");
    const icon = e.is_dir ? "&#128193;" : "&#128196;";
    const size = e.is_dir ? "" : formatSize(e.size);
    const editBtn = e.editable ? `<button class="edit">Editar</button>` : "";
    const dlBtn = e.is_dir ? "" : `<button class="dl">Bajar</button>`;
    tr.innerHTML = `
      <td><span class="fm-name ${e.is_dir ? "dir" : ""}"><span class="fm-icon">${icon}</span>${escapeHtml(e.name)}</span></td>
      <td class="fm-size">${size}</td>
      <td class="fm-mod">${escapeHtml(e.modified)}</td>
      <td><div class="fm-actions">${editBtn}${dlBtn}<button class="del">Borrar</button></div></td>
    `;
    const nameEl = tr.querySelector(".fm-name");
    if (e.is_dir) nameEl.onclick = () => loadFiles(e.path);
    else if (e.editable) nameEl.onclick = () => openEditor(e.path, e.name);
    const editEl = tr.querySelector(".edit");
    if (editEl) editEl.onclick = () => openEditor(e.path, e.name);
    const dlEl = tr.querySelector(".dl");
    if (dlEl) dlEl.onclick = () => downloadFile(e.path);
    tr.querySelector(".del").onclick = () => deleteFile(e.path, e.name);
    body.appendChild(tr);
  });
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}

async function openEditor(path, name) {
  let data;
  try { data = await api(`/servers/${currentId}/files/content?path=${encodeURIComponent(path)}`); }
  catch (e) { toast(e.message, "err"); return; }
  editorPath = path;
  $("#editor-title").textContent = "Editar: " + name;
  $("#editor-area").value = data.content;
  $("#editor-modal").classList.remove("hidden");
}

async function saveEditor() {
  try {
    await api(`/servers/${currentId}/files/content`, {
      method: "PUT",
      body: JSON.stringify({ path: editorPath, content: $("#editor-area").value }),
    });
    toast("Archivo guardado.", "ok");
    $("#editor-modal").classList.add("hidden");
  } catch (e) { toast(e.message, "err"); }
}

function downloadFile(path) {
  window.open(`${API}/servers/${currentId}/files/download?path=${encodeURIComponent(path)}`, "_blank");
}

async function deleteFile(path, name) {
  if (!confirm(`Borrar "${name}"?`)) return;
  try {
    await api(`/servers/${currentId}/files?path=${encodeURIComponent(path)}`, { method: "DELETE" });
    toast("Eliminado.", "ok");
    loadFiles(fmPath);
  } catch (e) { toast(e.message, "err"); }
}

async function newFolder() {
  const name = prompt("Nombre de la nueva carpeta:");
  if (!name) return;
  const path = (fmPath ? fmPath + "/" : "") + name;
  try {
    await api(`/servers/${currentId}/files/folder`, { method: "POST", body: JSON.stringify({ path }) });
    loadFiles(fmPath);
  } catch (e) { toast(e.message, "err"); }
}

async function uploadFile(e) {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  fd.append("path", fmPath);
  try {
    const res = await fetch(`${API}/servers/${currentId}/files/upload`, { method: "POST", body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Error");
    toast("Archivo subido.", "ok");
    loadFiles(fmPath);
  } catch (err) { toast(err.message, "err"); }
  e.target.value = "";
}

// --- tabs -------------------------------------------------------------------
function setupTabs() {
  $$(".tab").forEach((tab) => {
    tab.onclick = () => {
      $$(".tab").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      $$(".tab-panel").forEach((p) => p.classList.add("hidden"));
      $(`#tab-${tab.dataset.tab}`).classList.remove("hidden");
      if (tab.dataset.tab === "files") loadFiles("");
    };
  });
}

// --- utils ------------------------------------------------------------------
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// --- init -------------------------------------------------------------------
window.addEventListener("DOMContentLoaded", () => {
  setupTabs();
  $("#btn-new").onclick = openModal;
  $("#btn-cancel").onclick = closeModal;
  $("#f-type").onchange = loadVersions;
  $("#create-form").onsubmit = createServer;
  $("#btn-start").onclick = () => action("start");
  $("#btn-stop").onclick = () => action("stop");
  $("#btn-restart").onclick = () => action("restart");
  $("#btn-download").onclick = downloadJar;
  $("#btn-delete").onclick = deleteServer;
  $("#btn-save-props").onclick = saveProperties;
  $("#cmd-form").onsubmit = sendCommand;
  $("#file-jar").onchange = uploadJar;

  // file manager
  $("#fm-up").onclick = () => {
    const parts = fmPath.split("/").filter(Boolean);
    parts.pop();
    loadFiles(parts.join("/"));
  };
  $("#fm-refresh").onclick = () => loadFiles(fmPath);
  $("#fm-newfolder").onclick = newFolder;
  $("#fm-file").onchange = uploadFile;
  $("#editor-save").onclick = saveEditor;
  $("#editor-cancel").onclick = () => $("#editor-modal").classList.add("hidden");

  loadServers();
  listTimer = setInterval(loadServers, 4000);
});
