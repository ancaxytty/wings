"""
MemoryManager: gestion de memoria virtual (swap) respaldada en disco.

IMPORTANTE (honestidad tecnica): la memoria "infinita" no existe. Lo que existe
es la *memoria de intercambio* (swap en Linux, pagefile en Windows): memoria
respaldada en DISCO que extiende la RAM fisica. Como el disco suele ser mucho mas
grande que la RAM, un servidor puede usar mucha mas memoria de la que hay en RAM,
pero esta limitada por el espacio en disco y es bastante mas lenta cuando se usa.

Este modulo permite, en Linux:
  - Consultar RAM y swap totales/disponibles.
  - Crear un archivo swap (swapfile) en disco y activarlo (requiere root/sudo).
  - Desactivar y borrar swapfiles creados por el panel.

En Windows el archivo de paginacion lo gestiona el propio sistema operativo.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

try:
    import psutil  # type: ignore
except Exception:  # noqa: BLE001
    psutil = None

BASE_DIR = Path(__file__).resolve().parent
SWAP_DIR = BASE_DIR / "swap"
SWAP_REGISTRY = BASE_DIR / "swapfiles.json"

SWAP_DIR.mkdir(exist_ok=True)


def _run(cmd: list[str]) -> tuple[bool, str]:
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if out.returncode != 0:
            return False, (out.stderr or out.stdout or "").strip()
        return True, (out.stdout or "").strip()
    except FileNotFoundError:
        return False, f"Comando no disponible: {cmd[0]}"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


class MemoryManager:
    def __init__(self):
        self.files: list[dict] = self._load()

    # --- registro ------------------------------------------------------------
    def _load(self) -> list[dict]:
        if SWAP_REGISTRY.exists():
            try:
                return json.loads(SWAP_REGISTRY.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                return []
        return []

    def _save(self):
        SWAP_REGISTRY.write_text(json.dumps(self.files, indent=2), encoding="utf-8")

    # --- informacion de memoria ---------------------------------------------
    def info(self) -> dict:
        ram_total = ram_avail = swap_total = swap_free = 0
        if psutil is not None:
            try:
                vm = psutil.virtual_memory()
                sm = psutil.swap_memory()
                ram_total, ram_avail = vm.total, vm.available
                swap_total, swap_free = sm.total, sm.free
            except Exception:  # noqa: BLE001
                pass
        elif sys.platform.startswith("linux"):
            data = {}
            try:
                for line in Path("/proc/meminfo").read_text().splitlines():
                    key, _, rest = line.partition(":")
                    data[key.strip()] = int(rest.strip().split()[0]) * 1024  # kB -> bytes
            except Exception:  # noqa: BLE001
                pass
            ram_total = data.get("MemTotal", 0)
            ram_avail = data.get("MemAvailable", 0)
            swap_total = data.get("SwapTotal", 0)
            swap_free = data.get("SwapFree", 0)

        mb = 1024 * 1024
        return {
            "platform": sys.platform,
            "supported": sys.platform.startswith("linux"),
            "ram_total_mb": round(ram_total / mb),
            "ram_available_mb": round(ram_avail / mb),
            "ram_used_mb": round((ram_total - ram_avail) / mb),
            "swap_total_mb": round(swap_total / mb),
            "swap_free_mb": round(swap_free / mb),
            "swap_used_mb": round((swap_total - swap_free) / mb),
            "virtual_total_mb": round((ram_total + swap_total) / mb),
            "swapfiles": self.files,
        }

    # --- swapfiles -----------------------------------------------------------
    def list_swapfiles(self) -> list[dict]:
        return self.files

    def create_swapfile(self, size_mb: int) -> tuple[bool, str]:
        if not sys.platform.startswith("linux"):
            return False, ("La creacion de swap solo esta soportada en Linux. En Windows, "
                           "la memoria virtual (pagefile) la gestiona el sistema operativo "
                           "automaticamente; ajustala en Configuracion > Sistema > Memoria virtual.")
        try:
            size_mb = int(size_mb)
        except (TypeError, ValueError):
            return False, "Tamano invalido."
        if size_mb < 64:
            return False, "El tamano minimo del swapfile es 64 MB."

        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = SWAP_DIR / f"swapfile-{ts}.swap"

        # 1) reservar espacio en disco
        ok, msg = _run(["fallocate", "-l", f"{size_mb}M", str(path)])
        if not ok:
            # alternativa portable con dd
            ok, msg = _run(["dd", "if=/dev/zero", f"of={path}", "bs=1M", f"count={size_mb}"])
            if not ok:
                self._cleanup(path)
                return False, f"No se pudo reservar el espacio en disco: {msg}"

        # 2) permisos seguros
        try:
            os.chmod(path, 0o600)
        except Exception as exc:  # noqa: BLE001
            self._cleanup(path)
            return False, f"No se pudieron ajustar permisos: {exc}"

        # 3) formatear como swap
        ok, msg = _run(["mkswap", str(path)])
        if not ok:
            self._cleanup(path)
            return False, f"mkswap fallo: {msg}"

        # 4) activar (requiere privilegios de administrador)
        ok, msg = _run(["swapon", str(path)])
        if not ok:
            self._cleanup(path)
            return False, ("No se pudo activar el swap (swapon). Normalmente requiere "
                           "permisos de administrador: ejecuta el panel con 'sudo'. "
                           f"Detalle: {msg}")

        entry = {"name": path.name, "path": str(path), "size_mb": size_mb,
                 "created": datetime.now().strftime("%Y-%m-%d %H:%M")}
        self.files.append(entry)
        self._save()
        return True, f"Swap de {size_mb} MB creado y activado. RAM virtual ampliada."

    def remove_swapfile(self, name: str) -> tuple[bool, str]:
        entry = next((f for f in self.files if f["name"] == name), None)
        if not entry:
            return False, "Swapfile no encontrado."
        path = Path(entry["path"])
        if sys.platform.startswith("linux"):
            _run(["swapoff", str(path)])  # puede requerir sudo; intentamos igual
        self._cleanup(path)
        self.files = [f for f in self.files if f["name"] != name]
        self._save()
        return True, "Swapfile desactivado y eliminado."

    @staticmethod
    def _cleanup(path: Path):
        try:
            if path.exists():
                path.unlink()
        except Exception:  # noqa: BLE001
            pass
