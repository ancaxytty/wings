"""
ServerManager: nucleo del panel de hosting de Minecraft.

Gestiona multiples instancias de servidor de Minecraft:
  - Descarga de jars (Paper, Purpur, Vanilla) desde APIs oficiales.
  - Creacion de instancias (carpeta, eula.txt, server.properties).
  - Arranque / parada / reinicio de procesos Java.
  - Captura de consola en vivo y envio de comandos por stdin.
  - Lectura y escritura de server.properties.

No requiere dependencias externas mas alla de `requests`.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import signal
import subprocess
import threading
import time
import uuid
from collections import deque
from datetime import datetime
from pathlib import Path

import requests

# ----------------------------------------------------------------------------
# Rutas base
# ----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
SERVERS_DIR = BASE_DIR / "servers"
DATA_FILE = BASE_DIR / "servers.json"
MAX_CONSOLE_LINES = 1000

SERVERS_DIR.mkdir(exist_ok=True)


# ----------------------------------------------------------------------------
# APIs de descarga
# ----------------------------------------------------------------------------
PAPER_API = "https://api.papermc.io/v2/projects/paper"
PURPUR_API = "https://api.purpurmc.org/v2/purpur"
MOJANG_MANIFEST = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json"

HTTP_TIMEOUT = 30


def build_aikar_flags(memory_mb: int) -> list[str]:
    """Flags JVM de Aikar (G1GC optimizado) para mantener TPS estables.

    Documentado publicamente en https://docs.papermc.io/paper/aikars-flags
    Reduce los tirones del recolector de basura y mejora el rendimiento.
    """
    flags = [
        f"-Xms{memory_mb}M",
        f"-Xmx{memory_mb}M",
        "-XX:+UseG1GC",
        "-XX:+ParallelRefProcEnabled",
        "-XX:MaxGCPauseMillis=200",
        "-XX:+UnlockExperimentalVMOptions",
        "-XX:+DisableExplicitGC",
        "-XX:+AlwaysPreTouch",
        "-XX:G1HeapWastePercent=5",
        "-XX:G1MixedGCCountTarget=4",
        "-XX:G1MixedGCLiveThresholdPercent=90",
        "-XX:G1RSetUpdatingPauseTimePercent=5",
        "-XX:SurvivorRatio=32",
        "-XX:+PerfDisableSharedMem",
        "-XX:MaxTenuringThreshold=1",
        "-Dusing.aikars.flags=https://mcflags.emc.gs",
        "-Daikars.new.flags=true",
    ]
    # Ajuste de regiones segun memoria (recomendacion de Aikar)
    if memory_mb >= 12000:
        flags += [
            "-XX:G1NewSizePercent=40",
            "-XX:G1MaxNewSizePercent=50",
            "-XX:G1HeapRegionSize=16M",
            "-XX:G1ReservePercent=15",
            "-XX:InitiatingHeapOccupancyPercent=20",
        ]
    else:
        flags += [
            "-XX:G1NewSizePercent=30",
            "-XX:G1MaxNewSizePercent=40",
            "-XX:G1HeapRegionSize=8M",
            "-XX:G1ReservePercent=20",
            "-XX:InitiatingHeapOccupancyPercent=15",
        ]
    return flags


class MinecraftServer:
    """Representa una unica instancia de servidor de Minecraft."""

    def __init__(self, data: dict):
        self.id = data["id"]
        self.name = data["name"]
        self.server_type = data.get("server_type", "paper")  # paper|purpur|vanilla|custom
        self.version = data.get("version", "latest")
        self.port = int(data.get("port", 25565))
        self.memory = int(data.get("memory", 2048))  # MB
        self.jar = data.get("jar", "server.jar")
        # rendimiento y mundo
        self.jvm_flags = data.get("jvm_flags", "aikar")  # aikar|basic
        self.world_preset = data.get("world_preset", "normal")  # normal|flat|void

        # estado en tiempo de ejecucion
        self.process: subprocess.Popen | None = None
        self.console = deque(maxlen=MAX_CONSOLE_LINES)
        self._reader_thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self.players: list[str] = []

    # --- helpers de ruta -----------------------------------------------------
    @property
    def directory(self) -> Path:
        return SERVERS_DIR / self.id

    @property
    def jar_path(self) -> Path:
        return self.directory / self.jar

    @property
    def is_running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    # --- consola -------------------------------------------------------------
    def _log(self, line: str):
        ts = datetime.now().strftime("%H:%M:%S")
        with self._lock:
            self.console.append(f"[{ts}] {line.rstrip()}")
        self._track_players(line)

    def _track_players(self, line: str):
        # Detecta joins / quits para mantener una lista de jugadores aproximada
        join = re.search(r"(\w{3,16}) joined the game", line)
        quit_ = re.search(r"(\w{3,16}) left the game", line)
        if join:
            name = join.group(1)
            if name not in self.players:
                self.players.append(name)
        if quit_:
            name = quit_.group(1)
            if name in self.players:
                self.players.remove(name)

    def get_console(self, since: int = 0):
        with self._lock:
            lines = list(self.console)
        return lines[since:], len(lines)

    # --- ciclo de vida -------------------------------------------------------
    def _build_java_command(self, java: str) -> list[str]:
        """Construye el comando de arranque con flags de rendimiento."""
        if self.jvm_flags == "aikar":
            flags = build_aikar_flags(self.memory)
        else:
            flags = [f"-Xms{self.memory}M", f"-Xmx{self.memory}M"]
        return [java, *flags, "-jar", self.jar, "nogui"]

    def _read_output(self):
        assert self.process and self.process.stdout
        for raw in self.process.stdout:
            self._log(raw)
        self._log("*** El proceso del servidor ha finalizado ***")
        self.players = []

    def start(self) -> tuple[bool, str]:
        if self.is_running:
            return False, "El servidor ya esta en ejecucion."
        if not self.jar_path.exists():
            return False, f"No se encuentra el jar: {self.jar}. Descargalo primero."

        # asegurar eula
        eula = self.directory / "eula.txt"
        eula.write_text("eula=true\n", encoding="utf-8")

        java = shutil.which("java")
        if not java:
            return False, "Java no esta instalado o no esta en el PATH."

        cmd = self._build_java_command(java)

        try:
            self.process = subprocess.Popen(
                cmd,
                cwd=str(self.directory),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except Exception as exc:  # noqa: BLE001
            return False, f"No se pudo iniciar Java: {exc}"

        self._log(f"*** Iniciando {self.name} ({self.server_type} {self.version}) en el puerto {self.port} ***")
        self._reader_thread = threading.Thread(target=self._read_output, daemon=True)
        self._reader_thread.start()
        return True, "Servidor iniciado."

    def send_command(self, command: str) -> tuple[bool, str]:
        if not self.is_running or not self.process or not self.process.stdin:
            return False, "El servidor no esta en ejecucion."
        try:
            self.process.stdin.write(command + "\n")
            self.process.stdin.flush()
            self._log(f"> {command}")
            return True, "Comando enviado."
        except Exception as exc:  # noqa: BLE001
            return False, f"Error enviando comando: {exc}"

    def stop(self) -> tuple[bool, str]:
        if not self.is_running:
            return False, "El servidor no esta en ejecucion."
        self.send_command("stop")
        # esperar apagado limpio
        for _ in range(20):
            if not self.is_running:
                break
            time.sleep(0.5)
        if self.is_running and self.process:
            self._log("*** Forzando cierre del servidor ***")
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
        self.players = []
        return True, "Servidor detenido."

    def restart(self) -> tuple[bool, str]:
        if self.is_running:
            self.stop()
        return self.start()

    # --- propiedades ---------------------------------------------------------
    def read_properties(self) -> dict:
        path = self.directory / "server.properties"
        props: dict[str, str] = {}
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                props[key.strip()] = value.strip()
        return props

    def write_properties(self, props: dict):
        path = self.directory / "server.properties"
        lines = ["# Editado desde el panel de hosting", f"# {datetime.now().isoformat()}"]
        for key, value in props.items():
            lines.append(f"{key}={value}")
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        # mantener el puerto sincronizado
        if "server-port" in props:
            try:
                self.port = int(props["server-port"])
            except ValueError:
                pass

    # --- gestor de archivos --------------------------------------------------
    TEXT_EXTENSIONS = {
        ".txt", ".properties", ".yml", ".yaml", ".json", ".json5", ".cfg", ".conf",
        ".toml", ".ini", ".log", ".md", ".sh", ".bat", ".mcmeta", ".csv", ".xml",
        ".html", ".css", ".js", ".lang", ".env", ".gitignore",
    }
    MAX_EDIT_SIZE = 2 * 1024 * 1024  # 2 MB para edicion de texto

    def _safe_path(self, rel: str) -> Path:
        """Resuelve una ruta relativa dentro del directorio del servidor.

        Lanza ValueError si intenta salirse (proteccion contra path traversal).
        """
        rel = (rel or "").strip().lstrip("/\\")
        base = self.directory.resolve()
        target = (base / rel).resolve()
        if target != base and base not in target.parents:
            raise ValueError("Ruta fuera del directorio del servidor.")
        return target

    def is_text_file(self, path: Path) -> bool:
        return path.suffix.lower() in self.TEXT_EXTENSIONS or path.name in {
            "eula.txt", "server.properties", "ops.json", "whitelist.json",
        }

    def list_dir(self, rel: str = "") -> dict:
        target = self._safe_path(rel)
        if not target.exists():
            raise ValueError("La ruta no existe.")
        if not target.is_dir():
            raise ValueError("No es un directorio.")
        base = self.directory.resolve()
        entries = []
        for item in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
            try:
                stat = item.stat()
                entries.append({
                    "name": item.name,
                    "path": str(item.relative_to(base)),
                    "is_dir": item.is_dir(),
                    "size": stat.st_size if item.is_file() else 0,
                    "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                    "editable": item.is_file() and self.is_text_file(item),
                })
            except OSError:
                continue
        rel_path = "" if target == base else str(target.relative_to(base))
        return {"path": rel_path, "entries": entries}

    def read_text_file(self, rel: str) -> str:
        target = self._safe_path(rel)
        if not target.is_file():
            raise ValueError("El archivo no existe.")
        if target.stat().st_size > self.MAX_EDIT_SIZE:
            raise ValueError("El archivo es demasiado grande para editar (>2MB).")
        return target.read_text(encoding="utf-8", errors="replace")

    def write_text_file(self, rel: str, content: str):
        target = self._safe_path(rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    def delete_path(self, rel: str):
        target = self._safe_path(rel)
        if target == self.directory.resolve():
            raise ValueError("No se puede borrar la raiz del servidor.")
        if not target.exists():
            raise ValueError("La ruta no existe.")
        if target.is_dir():
            shutil.rmtree(target, ignore_errors=True)
        else:
            target.unlink()

    def make_dir(self, rel: str):
        target = self._safe_path(rel)
        target.mkdir(parents=True, exist_ok=True)

    def upload_destination(self, rel_dir: str, filename: str) -> Path:
        safe_name = os.path.basename(filename)
        dest = self._safe_path(os.path.join(rel_dir or "", safe_name))
        dest.parent.mkdir(parents=True, exist_ok=True)
        return dest

    def download_path(self, rel: str) -> Path:
        target = self._safe_path(rel)
        if not target.is_file():
            raise ValueError("El archivo no existe.")
        return target

    # --- serializacion -------------------------------------------------------
    def to_dict(self, full: bool = False) -> dict:
        data = {
            "id": self.id,
            "name": self.name,
            "server_type": self.server_type,
            "version": self.version,
            "port": self.port,
            "memory": self.memory,
            "jar": self.jar,
            "jvm_flags": self.jvm_flags,
            "world_preset": self.world_preset,
            "running": self.is_running,
            "has_jar": self.jar_path.exists(),
            "players": self.players,
        }
        if full:
            data["properties"] = self.read_properties()
        return data

    def persist_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "server_type": self.server_type,
            "version": self.version,
            "port": self.port,
            "memory": self.memory,
            "jar": self.jar,
            "jvm_flags": self.jvm_flags,
            "world_preset": self.world_preset,
        }


class ServerManager:
    """Gestiona la coleccion de servidores y la descarga de jars."""

    def __init__(self):
        self.servers: dict[str, MinecraftServer] = {}
        self._load()

    # --- persistencia --------------------------------------------------------
    def _load(self):
        if DATA_FILE.exists():
            try:
                raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
                for item in raw:
                    self.servers[item["id"]] = MinecraftServer(item)
            except Exception:  # noqa: BLE001
                pass

    def _save(self):
        data = [s.persist_dict() for s in self.servers.values()]
        DATA_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # --- CRUD ----------------------------------------------------------------
    def list_servers(self) -> list[dict]:
        return [s.to_dict() for s in self.servers.values()]

    def get(self, server_id: str) -> MinecraftServer | None:
        return self.servers.get(server_id)

    def create_server(self, name: str, server_type: str, version: str,
                      port: int, memory: int, world_preset: str = "normal",
                      jvm_flags: str = "aikar") -> MinecraftServer:
        server_id = uuid.uuid4().hex[:8]
        server = MinecraftServer({
            "id": server_id,
            "name": name,
            "server_type": server_type,
            "version": version,
            "port": port,
            "memory": memory,
            "jar": "server.jar",
            "jvm_flags": jvm_flags,
            "world_preset": world_preset,
        })
        server.directory.mkdir(parents=True, exist_ok=True)
        # eula + propiedades por defecto
        (server.directory / "eula.txt").write_text("eula=true\n", encoding="utf-8")

        props = {
            "server-port": str(port),
            "motd": f"{name} - powered by Python Hosting Panel",
            "max-players": "20",
            "online-mode": "true",
            "difficulty": "normal",
            "gamemode": "survival",
            "pvp": "true",
            # --- ajustes de arranque/generacion rapida ---
            "spawn-protection": "0",
            "view-distance": "6",
            "simulation-distance": "6",
            "sync-chunk-writes": "false",
            "max-world-size": "29999984",
        }
        props.update(self._world_preset_props(world_preset))
        server.write_properties(props)

        self.servers[server_id] = server
        self._save()
        return server

    @staticmethod
    def _world_preset_props(preset: str) -> dict:
        """Propiedades para una generacion de mundo extremadamente rapida."""
        if preset == "flat":
            return {
                "level-type": "flat",
                "generate-structures": "false",
            }
        if preset == "void":
            # Superflat sin capas = mundo vacio (void). Genera casi al instante.
            return {
                "level-type": "flat",
                "generate-structures": "false",
                "generator-settings": '{"layers":[],"biome":"minecraft:the_void"}',
            }
        # normal
        return {
            "level-type": "minecraft:normal",
            "generate-structures": "true",
        }

    def delete_server(self, server_id: str) -> bool:
        server = self.servers.get(server_id)
        if not server:
            return False
        if server.is_running:
            server.stop()
        shutil.rmtree(server.directory, ignore_errors=True)
        del self.servers[server_id]
        self._save()
        return True

    # --- descarga de jars ----------------------------------------------------
    def download_jar(self, server_id: str, progress=None) -> tuple[bool, str]:
        server = self.servers.get(server_id)
        if not server:
            return False, "Servidor no encontrado."
        try:
            if server.server_type == "paper":
                url = self._paper_url(server.version)
            elif server.server_type == "purpur":
                url = self._purpur_url(server.version)
            elif server.server_type == "vanilla":
                url = self._vanilla_url(server.version)
            else:
                return False, "Para servidores 'custom' sube el jar manualmente."
        except Exception as exc:  # noqa: BLE001
            return False, f"No se pudo resolver la descarga: {exc}"

        try:
            self._download_file(url, server.jar_path, progress)
        except Exception as exc:  # noqa: BLE001
            return False, f"Error de descarga: {exc}"
        self._save()
        return True, f"Jar descargado correctamente ({server.jar_path.name})."

    def _download_file(self, url: str, dest: Path, progress=None):
        with requests.get(url, stream=True, timeout=HTTP_TIMEOUT) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            done = 0
            with open(dest, "wb") as f:
                for chunk in r.iter_content(chunk_size=1 << 16):
                    f.write(chunk)
                    done += len(chunk)
                    if progress and total:
                        progress(done, total)

    def _resolve_version(self, version: str, versions: list[str]) -> str:
        if version and version != "latest":
            return version
        return versions[-1]

    def _paper_url(self, version: str) -> str:
        versions = requests.get(PAPER_API, timeout=HTTP_TIMEOUT).json()["versions"]
        version = self._resolve_version(version, versions)
        builds = requests.get(f"{PAPER_API}/versions/{version}", timeout=HTTP_TIMEOUT).json()["builds"]
        build = builds[-1]
        info = requests.get(f"{PAPER_API}/versions/{version}/builds/{build}", timeout=HTTP_TIMEOUT).json()
        jar = info["downloads"]["application"]["name"]
        return f"{PAPER_API}/versions/{version}/builds/{build}/downloads/{jar}"

    def _purpur_url(self, version: str) -> str:
        versions = requests.get(PURPUR_API, timeout=HTTP_TIMEOUT).json()["versions"]
        version = self._resolve_version(version, versions)
        return f"{PURPUR_API}/{version}/latest/download"

    def _vanilla_url(self, version: str) -> str:
        manifest = requests.get(MOJANG_MANIFEST, timeout=HTTP_TIMEOUT).json()
        if not version or version == "latest":
            version = manifest["latest"]["release"]
        entry = next((v for v in manifest["versions"] if v["id"] == version), None)
        if not entry:
            raise ValueError(f"Version vanilla desconocida: {version}")
        meta = requests.get(entry["url"], timeout=HTTP_TIMEOUT).json()
        return meta["downloads"]["server"]["url"]

    # --- versiones disponibles ----------------------------------------------
    def available_versions(self, server_type: str) -> list[str]:
        try:
            if server_type == "paper":
                return list(reversed(requests.get(PAPER_API, timeout=HTTP_TIMEOUT).json()["versions"]))
            if server_type == "purpur":
                return list(reversed(requests.get(PURPUR_API, timeout=HTTP_TIMEOUT).json()["versions"]))
            if server_type == "vanilla":
                manifest = requests.get(MOJANG_MANIFEST, timeout=HTTP_TIMEOUT).json()
                return [v["id"] for v in manifest["versions"] if v["type"] == "release"][:40]
        except Exception:  # noqa: BLE001
            return []
        return []
