#!/usr/bin/env bash
# Script de arranque del panel de hosting de Minecraft
set -e

cd "$(dirname "$0")"

# Crear entorno virtual si no existe
if [ ! -d ".venv" ]; then
  echo "==> Creando entorno virtual..."
  python3 -m venv .venv
fi

# Activar e instalar dependencias
source .venv/bin/activate
echo "==> Instalando dependencias..."
pip install -q -r requirements.txt

# Comprobar Java
if ! command -v java >/dev/null 2>&1; then
  echo "AVISO: Java no esta instalado. Necesitas Java 17+ para ejecutar servidores de Minecraft."
  echo "       El panel arrancara igualmente, pero no podras iniciar servidores hasta instalar Java."
fi

echo "==> Iniciando panel en http://localhost:8080"
python app.py
