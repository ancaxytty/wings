"""
PluginManager: busqueda y descarga de plugins desde Modrinth.

Modrinth (https://modrinth.com) es un repositorio abierto y gratuito, sin login,
con descargas directas. Filtramos por project_type=plugin y por el loader
(paper, spigot, bukkit, purpur, folia...) y la version de Minecraft.

API: https://docs.modrinth.com/api/  (no requiere clave).
"""

from __future__ import annotations

import json
from pathlib import Path

import requests

MODRINTH = "https://api.modrinth.com/v2"
# Modrinth pide un User-Agent identificativo del proyecto.
HEADERS = {"User-Agent": "NebulaHost/1.0 (minecraft hosting panel)"}
TIMEOUT = 30

# loaders validos para plugins de servidor
PLUGIN_LOADERS = {"paper", "spigot", "bukkit", "purpur", "folia", "velocity", "waterfall", "bungeecord"}


def _facets(loader: str | None, game_version: str | None) -> str:
    facets = [["project_type:plugin"]]
    if loader and loader in PLUGIN_LOADERS:
        facets.append([f"categories:{loader}"])
    if game_version and game_version != "latest":
        facets.append([f"versions:{game_version}"])
    return json.dumps(facets)


def search(query: str, loader: str | None = None, game_version: str | None = None,
           limit: int = 20) -> list[dict]:
    params = {
        "query": query or "",
        "facets": _facets(loader, game_version),
        "limit": max(1, min(50, limit)),
        "index": "relevance",
    }
    r = requests.get(f"{MODRINTH}/search", params=params, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    hits = r.json().get("hits", [])
    out = []
    for h in hits:
        out.append({
            "project_id": h.get("project_id") or h.get("slug"),
            "slug": h.get("slug"),
            "title": h.get("title"),
            "description": h.get("description"),
            "author": h.get("author"),
            "downloads": h.get("downloads", 0),
            "icon_url": h.get("icon_url"),
            "categories": h.get("categories", []),
            "versions": h.get("versions", []),
        })
    return out


def project_versions(project_id: str, loader: str | None = None,
                     game_version: str | None = None) -> list[dict]:
    params = {}
    if loader and loader in PLUGIN_LOADERS:
        params["loaders"] = json.dumps([loader])
    if game_version and game_version != "latest":
        params["game_versions"] = json.dumps([game_version])
    r = requests.get(f"{MODRINTH}/project/{project_id}/version",
                     params=params, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def resolve_download(project_id: str, version_id: str | None = None,
                     loader: str | None = None, game_version: str | None = None) -> tuple[str, str]:
    """Devuelve (url, filename) del .jar a descargar."""
    versions = project_versions(project_id, loader, game_version)
    if not versions:
        raise ValueError("No hay versiones compatibles para ese loader/version de Minecraft.")
    chosen = None
    if version_id:
        chosen = next((v for v in versions if v.get("id") == version_id), None)
    if chosen is None:
        chosen = versions[0]  # la mas reciente
    files = chosen.get("files", [])
    primary = next((f for f in files if f.get("primary")), files[0] if files else None)
    if not primary:
        raise ValueError("La version seleccionada no tiene archivos descargables.")
    return primary["url"], primary["filename"]


def download_to(dest_dir: Path, url: str, filename: str) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = Path(filename).name
    dest = dest_dir / safe
    with requests.get(url, stream=True, headers=HEADERS, timeout=TIMEOUT) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=1 << 16):
                f.write(chunk)
    return dest


def install(dest_dir: Path, project_id: str, version_id: str | None = None,
            loader: str | None = None, game_version: str | None = None) -> dict:
    url, filename = resolve_download(project_id, version_id, loader, game_version)
    dest = download_to(dest_dir, url, filename)
    return {"filename": dest.name, "size": dest.stat().st_size}
