# MC Hosting Panel

Panel web para **hostear servidores de Minecraft** (Paper, Purpur, Vanilla o tu propio jar)
con backend en **Python (Flask)** e interfaz en **HTML + CSS + JavaScript**.
Funciona en `localhost` o por tu **IP de red local**.

> Paper es compatible con plugins de **Spigot/Bukkit**, así que con la opción "Paper"
> puedes usar tus plugins de Spigot sin problema.

## Características

- Crear, iniciar, detener, reiniciar y eliminar múltiples servidores.
- Descarga automática del `.jar` desde las APIs oficiales (PaperMC, PurpurMC, Mojang).
- Subida de un `.jar` propio (modo *custom*, ideal para Spigot/Forge/Fabric).
- **Consola en vivo** con envío de comandos (`say`, `op`, `time set day`, etc.).
- Lista de jugadores conectados en tiempo real.
- Editor visual de `server.properties`.
- Pestaña de **conexión** con la IP/puerto para entrar desde Minecraft.
- Aceptación automática del EULA al crear el servidor.

## Requisitos

- **Python 3.10+**
- **Java 17+** (Java 21 recomendado para versiones modernas de Minecraft) en el `PATH`.
- Conexión a internet (solo para descargar los `.jar`).

## Instalación y uso

### Opción rápida (Linux / macOS)

```bash
chmod +x run.sh
./run.sh
```

### Manual (cualquier sistema)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Luego abre en el navegador:

- Local: **http://localhost:8080**
- Desde otro equipo de tu red: **http://TU_IP_LOCAL:8080**

## Cómo crear tu primer servidor

1. Pulsa **"+ Nuevo servidor"**.
2. Elige nombre, tipo (Paper recomendado), versión, puerto (`25565` por defecto) y memoria.
3. Pulsa **Descargar jar** (o **Subir jar** si usas uno propio).
4. Pulsa **▶ Iniciar**. Mira el arranque en la consola.
5. En Minecraft (Java Edition) → Multijugador → Añadir servidor → `localhost:25565`.

## Jugar desde fuera de tu red (IP pública)

Para que tus amigos entren por tu IP pública debes abrir el puerto del servidor
(por defecto `25565/TCP`) en tu router (*port forwarding*) apuntando a este equipo.
Alternativamente puedes usar un túnel como `playit.gg` o `ngrok`.

## Estructura del proyecto

```
.
├── app.py              # API REST + servidor web (Flask)
├── server_manager.py   # Lógica: descarga jars, procesos, consola, propiedades
├── requirements.txt
├── run.sh              # Script de arranque
├── servers.json        # Metadatos de los servidores (se crea solo)
├── servers/            # Carpeta de cada instancia de servidor (se crea sola)
└── static/             # Frontend
    ├── index.html
    ├── style.css
    └── app.js
```

## Notas

- Cada servidor se guarda en `servers/<id>/` con sus mundos, plugins y configuración.
- El panel debe seguir ejecutándose para mantener los servidores vivos.
- Para plugins de Spigot/Bukkit, copia los `.jar` de plugin en `servers/<id>/plugins/`.
