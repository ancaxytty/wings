# MC Hosting Panel

Panel web para **hostear servidores de Minecraft** (Paper, Purpur, Vanilla o tu propio jar)
con backend en **Python (Flask)** e interfaz en **HTML + CSS + JavaScript**.
Funciona en `localhost` o por tu **IP de red local**.

> Paper es compatible con plugins de **Spigot/Bukkit**, así que con la opción "Paper"
> puedes usar tus plugins de Spigot sin problema.

## Características

- Crear, iniciar, detener, reiniciar y eliminar múltiples servidores.
- Descarga automática del `.jar` desde las APIs oficiales (PaperMC, PurpurMC, Mojang).
- Subida de un `.jar` propio (modo *custom*, ideal para Spigot/Forge/Fabric).
- **Consola en vivo** con envío de comandos (`say`, `op`, `time set day`, etc.).
- **Gestor de archivos web**: navegar carpetas, **editar** archivos de texto en el navegador,
  subir, descargar, crear carpetas y borrar (con protección contra *path traversal*).
- **Optimización de rendimiento** con los *flags de Aikar* (G1GC ajustado según la RAM)
  para mantener los **20 TPS** estables sin tirones del recolector de basura.
- **Presets de mundo de generación ultrarrápida**:
  - **Void** (vacío infinito): se genera casi al instante.
  - **Flat** (superplano): muy rápido, sin estructuras.
  - **Normal**: mundo completo.
  - Además fija `view-distance`/`simulation-distance` bajos, `spawn-protection=0` y
    `sync-chunk-writes=false` para un arranque lo más veloz posible.
- Lista de jugadores conectados en tiempo real.
- Editor visual de `server.properties`.
- Pestaña de **conexión** con la IP/puerto para entrar desde Minecraft.
- Aceptación automática del EULA al crear el servidor.

> **Nota sobre "FPS":** un servidor de Minecraft no corre a FPS, corre a **20 TPS**
> (ticks por segundo) — ese es su indicador de rendimiento. Los FPS los genera tu
> cliente del juego. Los flags de Aikar + un mundo void/flat hacen que el servidor
> rinda al máximo y arranque/genere el mundo casi al instante.

## Selección automática de Java (arregla `UnsupportedClassVersionError`)

El error `class file version 65.0 ... up to 61.0` significa que el `.jar` necesita
**Java 21** pero se estaba usando **Java 17**. El panel ahora:

- **Detecta todas las instalaciones de Java** del sistema (PATH, `JAVA_HOME`, mise,
  SDKMAN, `/usr/lib/jvm`, Adoptium, etc.).
- **Elige automáticamente** la versión adecuada según la versión de Minecraft
  (1.20.5+ → Java 21, 1.18–1.20.4 → Java 17, etc.).
- Permite **forzar una versión de Java** por servidor desde el panel (tarjeta "Java Runtime").

## Panel "Dark Cyber-Glass" con métricas y backups

- Interfaz rediseñada (fondo nebulosa, paneles glass con glow, cubo 3D).
- **Gráfico en tiempo real** de CPU (verde) y RAM (azul).
- Widgets rápidos: **Jugadores, Uptime y TPS**.
- Tarjeta **Server Information** con estado ONLINE/OFFLINE, IP, puerto, Java, etc.
- **Backups**: crear, listar, restaurar, descargar y borrar copias del mundo (`.zip`).

> Las métricas de CPU/RAM usan `psutil` si está instalado (multiplataforma); si no,
> en Linux se leen directamente de `/proc` sin dependencias extra.

## Requisitos

- **Python 3.10+**
- **Java 17+** (Java 21 recomendado para versiones modernas de Minecraft) en el `PATH`.
- Conexión a internet (solo para descargar los `.jar`).

## Instalación y uso

### Opción rápida (Linux / macOS)

```bash
chmod +x run.sh
./run.sh
```

### Manual (cualquier sistema)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Luego abre en el navegador:

- Local: **http://localhost:8080**
- Desde otro equipo de tu red: **http://TU_IP_LOCAL:8080**

## Cómo crear tu primer servidor

1. Pulsa **"+ Nuevo servidor"**.
2. Elige nombre, tipo (Paper recomendado), versión, puerto (`25565` por defecto) y memoria.
3. Pulsa **Descargar jar** (o **Subir jar** si usas uno propio).
4. Pulsa **▶ Iniciar**. Mira el arranque en la consola.
5. En Minecraft (Java Edition) → Multijugador → Añadir servidor → `localhost:25565`.

## Jugar desde fuera de tu red (IP pública)

Para que tus amigos entren por tu IP pública debes abrir el puerto del servidor
(por defecto `25565/TCP`) en tu router (*port forwarding*) apuntando a este equipo.
Alternativamente puedes usar un túnel como `playit.gg` o `ngrok`.

## Estructura del proyecto

```
.
├── app.py              # API REST + servidor web (Flask)
├── server_manager.py   # Lógica: descarga jars, procesos, consola, propiedades
├── requirements.txt
├── run.sh              # Script de arranque
├── servers.json        # Metadatos de los servidores (se crea solo)
├── servers/            # Carpeta de cada instancia de servidor (se crea sola)
└── static/             # Frontend
    ├── index.html
    ├── style.css
    └── app.js
```

## Notas

- Cada servidor se guarda en `servers/<id>/` con sus mundos, plugins y configuración.
- El panel debe seguir ejecutándose para mantener los servidores vivos.
- Para plugins de Spigot/Bukkit, copia los `.jar` de plugin en `servers/<id>/plugins/`.
