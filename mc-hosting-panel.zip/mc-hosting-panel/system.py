"""
SystemMonitor: metricas del HOST (la maquina que ejecuta el panel).

Devuelve uso de CPU, RAM y disco del sistema completo (no de un servidor
concreto). Usa psutil si esta disponible; en su defecto, en Linux lee /proc
y os.statvfs, sin dependencias externas.
"""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

try:
    import psutil  # type: ignore
except Exception:  # noqa: BLE001
    psutil = None

BASE_DIR = Path(__file__).resolve().parent
_MB = 1024 * 1024
_prev_cpu: tuple[int, int] | None = None  # (idle, total) para el calculo por /proc


def _cpu_percent_proc() -> float:
    """Uso de CPU del host a partir de /proc/stat (delta entre llamadas)."""
    global _prev_cpu
    try:
        with open("/proc/stat") as f:
            fields = f.readline().split()[1:]
        nums = [int(x) for x in fields]
        idle = nums[3] + (nums[4] if len(nums) > 4 else 0)  # idle + iowait
        total = sum(nums)
        pct = 0.0
        if _prev_cpu is not None:
            d_idle = idle - _prev_cpu[0]
            d_total = total - _prev_cpu[1]
            if d_total > 0:
                pct = round((1 - d_idle / d_total) * 100, 1)
        _prev_cpu = (idle, total)
        return max(0.0, min(100.0, pct))
    except Exception:  # noqa: BLE001
        return 0.0


def _ram_proc() -> tuple[int, int]:
    """(total, disponible) en bytes desde /proc/meminfo."""
    data = {}
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, _, rest = line.partition(":")
            data[key.strip()] = int(rest.strip().split()[0]) * 1024
    except Exception:  # noqa: BLE001
        pass
    return data.get("MemTotal", 0), data.get("MemAvailable", 0)


def metrics(disk_path: str | None = None) -> dict:
    path = disk_path or str(BASE_DIR)

    # CPU + RAM
    if psutil is not None:
        cpu = psutil.cpu_percent(interval=None)
        vm = psutil.virtual_memory()
        ram_total, ram_avail, ram_pct = vm.total, vm.available, vm.percent
        cores = psutil.cpu_count(logical=True) or 1
    else:
        cpu = _cpu_percent_proc()
        ram_total, ram_avail = _ram_proc()
        ram_pct = round((ram_total - ram_avail) / ram_total * 100, 1) if ram_total else 0.0
        cores = os.cpu_count() or 1

    # Disco
    try:
        du = shutil.disk_usage(path)
        disk_total, disk_used, disk_free = du.total, du.used, du.free
        disk_pct = round(disk_used / disk_total * 100, 1) if disk_total else 0.0
    except Exception:  # noqa: BLE001
        disk_total = disk_used = disk_free = 0
        disk_pct = 0.0

    # Carga media (Unix)
    try:
        load = [round(x, 2) for x in os.getloadavg()]
    except (OSError, AttributeError):
        load = [0.0, 0.0, 0.0]

    return {
        "platform": sys.platform,
        "cpu_percent": round(cpu, 1),
        "cpu_cores": cores,
        "load_avg": load,
        "ram_total_mb": round(ram_total / _MB),
        "ram_used_mb": round((ram_total - ram_avail) / _MB),
        "ram_percent": round(ram_pct, 1),
        "disk_total_gb": round(disk_total / (1024 ** 3), 1),
        "disk_used_gb": round(disk_used / (1024 ** 3), 1),
        "disk_free_gb": round(disk_free / (1024 ** 3), 1),
        "disk_percent": disk_pct,
    }
