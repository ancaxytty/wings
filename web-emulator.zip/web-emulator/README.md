# 🎮 RetroDeck — Emulador web multi-consola

Emulador retro con **interfaz profesional** que corre en el navegador usando los
núcleos WebAssembly de [EmulatorJS](https://emulatorjs.org), con un backend en
**Node.js sin dependencias**. Pensado para ejecutarse **24/7 en tu red** o
empaquetarse como **`.exe`** de Windows.

> ⚖️ Usa únicamente ROMs y BIOS de juegos/sistemas que poseas legalmente.
> Este proyecto no incluye ni descarga juegos.

---

## ✨ Características

- 🖥️ **Interfaz profesional**: barra lateral por plataforma, búsqueda, favoritos,
  jugados recientemente, carátulas y modal de detalle.
- 🎮 **Durante el juego**: guardar/cargar estado, captura de pantalla, reinicio,
  pantalla completa y salida rápida. Soporte de mandos USB/Bluetooth.
- 💾 **Guardado** de partidas y *save states* en el navegador.
- 🕹️ **BIOS de PS1** opcional para máxima compatibilidad.
- 🌐 **24/7 en red**: el servidor se expone en tu LAN; otros dispositivos juegan
  desde su navegador.
- 📦 **Empaquetable a `.exe`**, Docker o servicio con PM2.

---

## ✅ Consolas soportadas

| Plataforma | Sistemas | Extensiones |
|------------|----------|-------------|
| Nintendo   | NES, SNES, N64, Game Boy / Color / Advance, DS | `.nes` `.fds` `.sfc` `.smc` `.n64` `.z64` `.v64` `.gb` `.gbc` `.gba` `.nds` |
| Sony       | **PlayStation 1** | `.bin` `.cue` `.pbp` `.chd` `.img` `.iso` |
| Sega       | Mega Drive/Genesis, Master System, Game Gear, Saturn | `.md` `.gen` `.smd` `.sms` `.gg` `.sat` |
| Atari      | Atari 2600 | `.a26` |
| Arcade     | MAME / FBNeo | `.zip` |

### ⚠️ PS2, PSP y consolas modernas
**No es viable** emularlas en un navegador (requieren demasiada potencia y
emulación de hardware compleja). Para ellas se usan emuladores de escritorio
dedicados (**PCSX2** para PS2, **PPSSPP** para PSP).

---

## 🚀 Inicio rápido (modo más sencillo)

Necesitas [Node.js](https://nodejs.org) 18+. **No requiere instalar dependencias.**

- **Windows:** doble clic en **`start.bat`** (abre el navegador solo).
- **Linux/macOS:** `./start.sh`
- **Manual (cualquier sistema):**
  ```bash
  node server.js
  ```

Abre **http://localhost:3000**. Para añadir juegos: botón **⬆️ Subir ROM** o copia
archivos a la carpeta `roms/` y pulsa 🔄.

---

## 🌐 Ejecutar 24/7 en tu red local

Al arrancar, el servidor muestra las direcciones de tu red, por ejemplo:

```
Local:    http://localhost:3000
Red/LAN:  http://192.168.1.50:3000
```

Cualquier dispositivo (móvil, tablet, otra PC) en la **misma red** puede entrar
con esa IP y jugar. Para cambiar el puerto: `PORT=8080 node server.js`.

### Mantenerlo siempre encendido

**Opción A — Docker (recomendado para servidores):**
```bash
docker compose up -d
```
Se reinicia solo si falla o si reinicias la máquina. Las carpetas
`roms/`, `saves/` y `bios/` se montan como volúmenes.

**Opción B — PM2 (Windows/Linux/macOS):**
```bash
npm i -g pm2
pm2 start ecosystem.config.cjs
pm2 save && pm2 startup     # arranque automático al encender
```

---

## 📦 Generar un `.exe` de Windows

Empaqueta el servidor en un único ejecutable (no necesita Node instalado en el
equipo destino):

```bash
npm install            # instala la herramienta 'pkg' (solo para construir)
npm run build:exe      # genera dist/RetroDeck.exe
# multiplataforma (win + linux + mac):
npm run build:all
```

Coloca `RetroDeck.exe` donde quieras y haz doble clic. Creará junto a él las
carpetas `roms/`, `saves/` y `bios/`. La interfaz (`public/`) va **embebida**
dentro del ejecutable.

> 💡 Alternativa "app de escritorio con ventana propia": se puede envolver con
> Electron, pero `pkg` es mucho más ligero (~40 MB) para servir la web.

---

## 🕹️ PlayStation 1: BIOS (opcional)

PS1 funciona sin BIOS (modo HLE), pero algunos juegos van mejor con la BIOS real.
Súbela desde **⚙️ Ajustes → Subir BIOS** o copia el `.bin` a la carpeta `bios/`.

Para juegos en `.bin` + `.cue`: sube **ambos** archivos e inicia desde el `.cue`
(o usa un único `.chd` / `.pbp`).

---

## 🖼️ Carátulas

Coloca una imagen con el **mismo nombre** que la ROM junto al archivo y aparecerá
como portada. Ej.: `Chrono Trigger.sfc` + `Chrono Trigger.png`.

---

## 🎮 Controles por defecto

| Acción | Teclado |
|--------|---------|
| Direcciones | Flechas |
| Botones | Z / X / A / S |
| Start / Select | Enter / Shift |
| Menú del emulador | Barra inferior del juego |

También funcionan mandos USB/Bluetooth (Gamepad API). Desde el menú del emulador
puedes **remapear** los controles.

---

## 🗂️ Estructura del proyecto

```
web-emulator/
├── server.js              # Servidor Node (CommonJS, 0 dependencias)
├── package.json           # scripts: start, build:exe, build:all
├── Dockerfile             # imagen 24/7
├── docker-compose.yml
├── ecosystem.config.cjs   # PM2
├── start.bat / start.sh   # lanzadores
├── roms/                  # tus ROMs (+ carátulas opcionales)
├── saves/                 # guardados
├── bios/                  # BIOS opcional (PS1)
└── public/
    ├── index.html         # biblioteca (UI profesional)
    ├── play.html          # reproductor con controles
    ├── css/style.css
    └── js/app.js
```

## 🔌 ¿Sin internet?
EmulatorJS descarga sus núcleos desde su CDN la primera vez. Para uso 100% offline,
descarga el paquete `data` de EmulatorJS a `public/emulatorjs/` y cambia
`EJS_pathtodata` en `public/play.html` a `/emulatorjs/`.

---

Núcleos de emulación por [EmulatorJS](https://emulatorjs.org) (cada core mantiene
su propia licencia). Código de este proyecto bajo licencia MIT.
