# RetroDeck - Emulador web multi-consola

Emulador retro con interfaz profesional que corre en el navegador usando los
nucleos WebAssembly de [EmulatorJS](https://emulatorjs.org). Incluye backend en
Node.js y backend en Python (ambos sin dependencias externas). Pensado para
ejecutarse 24/7 en tu red o empaquetarse como `.exe` de Windows.

> Usa unicamente ROMs y BIOS de juegos/sistemas que poseas legalmente.
> Este proyecto no incluye ni descarga juegos.

---

## Importante: consolas que NO son posibles en navegador

No es viable emular estas consolas en un navegador, y EmulatorJS no tiene
nucleos para ellas:

- PS4: no existe ningun emulador funcional, ni siquiera en PC de escritorio.
- Nintendo Switch: los emuladores necesitan hardware potente; no hay version web.
- Wii / GameCube: Dolphin no tiene version WebAssembly viable.
- PS2 / PSP: requieren emuladores de escritorio (PCSX2, PPSSPP).

Para esas plataformas se usan programas de escritorio dedicados. Este proyecto se
centra en las consolas que SI funcionan bien en navegador.

---

## Consolas soportadas

| Plataforma | Sistemas | Extensiones |
|------------|----------|-------------|
| Nintendo   | NES, SNES, N64, Game Boy / Color / Advance, DS | `.nes` `.fds` `.sfc` `.smc` `.n64` `.z64` `.v64` `.gb` `.gbc` `.gba` `.nds` |
| Sony       | PlayStation 1 | `.bin` `.cue` `.pbp` `.chd` `.img` `.iso` |
| Sega       | Mega Drive/Genesis, Master System, Game Gear, Saturn | `.md` `.gen` `.smd` `.sms` `.gg` `.sat` |
| Atari      | Atari 2600 | `.a26` |
| Arcade     | MAME / FBNeo | `.zip` |

---

## Caracteristicas

- Interfaz profesional: barra lateral por plataforma, busqueda, favoritos,
  jugados recientemente, caratulas y modal de detalle.
- Editor visual de controles: teclado, mouse y mando dibujados para reasignar
  los botones (pagina Controles).
- Ajustes ampliados: pantalla completa, suavizado, rebobinado, volumen,
  velocidad de avance rapido, filtro de video (shaders CRT, scanlines, etc.),
  ranura de guardado y color de acento.
- Guardado de partidas y save states en el navegador.
- BIOS de PS1 opcional para mayor compatibilidad.
- 24/7 en red local; empaquetable a `.exe` (Node o Python).

---

## Inicio rapido

Tienes dos backends equivalentes. Usa el que prefieras.

### Con Node.js (18+)
- Windows: doble clic en `start.bat`
- Linux/macOS: `./start.sh`
- Manual: `node server.js`

### Con Python (3.8+)
- Windows: doble clic en `start_py.bat`
- Linux/macOS: `./start_py.sh`
- Manual: `python server.py`

Ninguno requiere instalar dependencias. Abre http://localhost:3000.
Para anadir juegos: boton "Subir ROM" o copia archivos a la carpeta `roms/` y
pulsa recargar.

---

## Editor de controles

Entra en la pagina "Controles" (menu lateral o desde Ajustes). Pulsa el recuadro
de un boton de la consola y luego la tecla que quieras asignarle; el teclado
dibujado resalta las teclas en uso. Guarda y el mapeo se aplicara al jugar.

Tambien puedes conectar un mando USB/Bluetooth (se detecta solo), y dentro del
juego el menu del propio emulador permite remapear con todo detalle.

---

## Ejecutar 24/7 en tu red local

Al arrancar, el servidor muestra las direcciones de tu red, por ejemplo:

```
Local:    http://localhost:3000
Red/LAN:  http://192.168.1.50:3000
```

Cualquier dispositivo en la misma red puede entrar con esa IP. Cambiar puerto:
`PORT=8080 node server.js` (o `PORT=8080 python server.py`).

### Mantenerlo siempre encendido
- Docker: `docker compose up -d`
- PM2 (Node): `pm2 start ecosystem.config.cjs && pm2 save && pm2 startup`

---

## Generar un .exe de Windows

### Opcion Node (pkg)
```bash
npm install
npm run build:exe      # genera dist/RetroDeck.exe
```

### Opcion Python (PyInstaller)
```bash
pip install pyinstaller
# Windows:
pyinstaller --onefile --name RetroDeck --add-data "public;public" server.py
# Linux/macOS (separador ":"):
./build_exe_py.sh
```

En ambos casos el ejecutable queda en `dist/`. Al ejecutarlo crea junto a el las
carpetas `roms/`, `saves/` y `bios/`. La interfaz va embebida en el binario.

---

## PlayStation 1: BIOS (opcional)

PS1 funciona sin BIOS (modo HLE), pero algunos juegos van mejor con la BIOS real.
Subela desde Ajustes -> Subir BIOS o copia el `.bin` a la carpeta `bios/`.
Para juegos en `.bin` + `.cue`: sube ambos e inicia desde el `.cue`.

---

## Caratulas

Coloca una imagen con el mismo nombre que la ROM junto al archivo. Ej.:
`Chrono Trigger.sfc` + `Chrono Trigger.png`.

---

## Estructura del proyecto

```
web-emulator/
  server.js              Backend Node (CommonJS, 0 dependencias)
  server.py              Backend Python (stdlib, 0 dependencias)
  package.json           scripts Node: start, build:exe, build:all
  build_exe_py.sh        build .exe con PyInstaller
  Dockerfile             imagen 24/7
  docker-compose.yml
  ecosystem.config.cjs   PM2
  start.bat / start.sh           lanzadores Node
  start_py.bat / start_py.sh     lanzadores Python
  roms/  saves/  bios/   datos del usuario
  public/
    index.html           biblioteca
    play.html            reproductor
    controls.html        editor de controles
    css/style.css
    js/app.js
    js/controls.js
```

## Sin internet

EmulatorJS descarga sus nucleos desde su CDN la primera vez. Para uso 100%
offline, descarga el paquete `data` de EmulatorJS a `public/emulatorjs/` y cambia
`EJS_pathtodata` en `public/play.html` a `/emulatorjs/`.

---

Nucleos de emulacion por [EmulatorJS](https://emulatorjs.org) (cada core mantiene
su propia licencia). Codigo de este proyecto bajo licencia MIT.
