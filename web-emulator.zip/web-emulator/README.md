# 🎮 RetroDeck — Emulador web multi-consola

Emulador retro que corre **en el navegador** usando los núcleos WebAssembly de
[EmulatorJS](https://emulatorjs.org) con un backend en **Node.js / Express** que
gestiona tu biblioteca de ROMs.

> ⚖️ Usa únicamente ROMs de juegos que poseas legalmente. Este proyecto no
> incluye ni descarga juegos.

---

## ✅ Consolas soportadas

| Plataforma | Sistemas | Extensiones |
|------------|----------|-------------|
| Nintendo   | NES, SNES, N64, Game Boy / Color / Advance, DS | `.nes` `.fds` `.sfc` `.smc` `.n64` `.z64` `.v64` `.gb` `.gbc` `.gba` `.nds` |
| Sony       | **PlayStation 1** | `.bin` `.cue` `.pbp` `.chd` `.img` `.iso` |
| Sega       | Mega Drive/Genesis, Master System, Game Gear, Saturn | `.md` `.gen` `.smd` `.sms` `.gg` `.sat` |
| Atari      | Atari 2600 | `.a26` |
| Arcade     | MAME / FBNeo | `.zip` |

### ⚠️ Sobre PS2, PSP y consolas modernas
**No es posible** emular PS2 ni PSP de forma fiable en el navegador: requieren
demasiada potencia y emulación de hardware compleja. Para esas consolas se usan
emuladores de escritorio dedicados (**PCSX2** para PS2, **PPSSPP** para PSP).
Por eso este proyecto se centra en consolas que **sí funcionan bien** en web.

---

## 🚀 Cómo usarlo

Necesitas [Node.js](https://nodejs.org) 18 o superior. **No requiere instalar dependencias.**

```bash
# Arrancar el servidor (no hace falta npm install)
npm start
# o directamente:
node server.js
```

Abre **http://localhost:3000** en tu navegador.

### Añadir juegos
- **Opción A:** Pulsa **⬆️ Subir ROM** en la web y selecciona tus archivos.
- **Opción B:** Copia los archivos a la carpeta `roms/` y pulsa **🔄 Recargar**.

### PlayStation 1 (`.bin` + `.cue`)
Sube **ambos** archivos (`.cue` y `.bin`) y luego inicia el juego desde el `.cue`.
También puedes usar un único archivo `.chd` o `.pbp`.

---

## 🕹️ Controles por defecto

| Acción | Teclado |
|--------|---------|
| Direcciones | Flechas |
| Botones | Z / X / A / S |
| Start / Select | Enter / Shift |
| Menú del emulador | Click en el ícono inferior |

También funcionan los **mandos USB/Bluetooth** (Gamepad API). Guardado de
partidas y *save states* se almacenan en el navegador (IndexedDB).

---

## 🗂️ Estructura del proyecto

```
web-emulator/
├── server.js          # Servidor Express + API de la biblioteca
├── package.json
├── roms/              # Tus ROMs (no se versionan)
├── saves/             # Reservado para guardados del servidor
└── public/
    ├── index.html     # Biblioteca de juegos
    ├── play.html      # Reproductor (EmulatorJS)
    ├── css/style.css
    └── js/app.js
```

## 🔌 ¿Sin internet?
EmulatorJS descarga sus núcleos desde su CDN la primera vez. Para uso 100% offline,
descarga el paquete `data` de EmulatorJS, colócalo en `public/emulatorjs/` y cambia
`EJS_pathtodata` en `public/play.html` a `/emulatorjs/`.

---

Núcleos de emulación por [EmulatorJS](https://emulatorjs.org) (licencia GPL/propia de cada core). Código de este proyecto bajo licencia MIT.
