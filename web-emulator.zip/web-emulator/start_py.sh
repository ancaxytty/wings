#!/usr/bin/env bash
set -e

echo ""
echo "  ======================================"
echo "    RetroDeck - iniciando (Python)..."
echo "  ======================================"
echo ""

if ! command -v python3 >/dev/null 2>&1; then
  echo "  [ERROR] Python 3 no esta instalado. Instalalo desde https://python.org"
  exit 1
fi

( sleep 2; (xdg-open http://localhost:3000 || open http://localhost:3000) >/dev/null 2>&1 ) &

exec python3 server.py
