#!/usr/bin/env bash
set -e

echo ""
echo "  ======================================"
echo "    RetroDeck - iniciando servidor..."
echo "  ======================================"
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "  [ERROR] Node.js no esta instalado. Instalalo desde https://nodejs.org"
  exit 1
fi

# Abre el navegador (Linux/macOS) tras un breve retardo, sin bloquear
( sleep 2; (xdg-open http://localhost:3000 || open http://localhost:3000) >/dev/null 2>&1 ) &

exec node server.js
