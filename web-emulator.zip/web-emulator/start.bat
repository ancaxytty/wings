@echo off
title RetroDeck - Emulador Web
echo.
echo   ======================================
echo     RetroDeck - iniciando servidor...
echo   ======================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo  [ERROR] Node.js no esta instalado.
  echo  Descargalo desde https://nodejs.org y vuelve a ejecutar este archivo.
  echo.
  pause
  exit /b 1
)

REM Abre el navegador tras un breve retardo
start "" cmd /c "timeout /t 2 >nul & start http://localhost:3000"

node server.js
pause
