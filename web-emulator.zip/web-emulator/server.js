import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const ROMS_DIR = path.join(__dirname, "roms");
const SAVES_DIR = path.join(__dirname, "saves");
const PUBLIC_DIR = path.join(__dirname, "public");

for (const dir of [ROMS_DIR, SAVES_DIR]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

/**
 * Mapa de extensiones -> info de consola.
 * "core" es el identificador del nucleo de EmulatorJS.
 * Doc: https://emulatorjs.org/docs/systems
 */
const SYSTEMS = {
  // Nintendo
  nes: { core: "nes", label: "NES", platform: "Nintendo" },
  fds: { core: "nes", label: "Famicom Disk", platform: "Nintendo" },
  sfc: { core: "snes", label: "SNES", platform: "Nintendo" },
  smc: { core: "snes", label: "SNES", platform: "Nintendo" },
  n64: { core: "n64", label: "Nintendo 64", platform: "Nintendo" },
  z64: { core: "n64", label: "Nintendo 64", platform: "Nintendo" },
  v64: { core: "n64", label: "Nintendo 64", platform: "Nintendo" },
  gb: { core: "gb", label: "Game Boy", platform: "Nintendo" },
  gbc: { core: "gb", label: "Game Boy Color", platform: "Nintendo" },
  gba: { core: "gba", label: "Game Boy Advance", platform: "Nintendo" },
  nds: { core: "nds", label: "Nintendo DS", platform: "Nintendo" },

  // Sony
  bin: { core: "psx", label: "PlayStation", platform: "Sony" },
  cue: { core: "psx", label: "PlayStation", platform: "Sony" },
  pbp: { core: "psx", label: "PlayStation", platform: "Sony" },
  chd: { core: "psx", label: "PlayStation", platform: "Sony" },
  img: { core: "psx", label: "PlayStation", platform: "Sony" },
  iso: { core: "psx", label: "PlayStation", platform: "Sony" },

  // Sega
  md: { core: "segaMD", label: "Mega Drive / Genesis", platform: "Sega" },
  gen: { core: "segaMD", label: "Mega Drive / Genesis", platform: "Sega" },
  smd: { core: "segaMD", label: "Mega Drive / Genesis", platform: "Sega" },
  sms: { core: "segaMS", label: "Master System", platform: "Sega" },
  gg: { core: "segaGG", label: "Game Gear", platform: "Sega" },
  sat: { core: "segaSaturn", label: "Sega Saturn", platform: "Sega" },

  // Atari / Arcade
  a26: { core: "atari2600", label: "Atari 2600", platform: "Atari" },
  zip: { core: "arcade", label: "Arcade (MAME/FBNeo)", platform: "Arcade" },
};

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

function getSystemForFile(filename) {
  const ext = path.extname(filename).slice(1).toLowerCase();
  return SYSTEMS[ext] || null;
}

function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(body);
}

// Evita path traversal: solo el nombre base, dentro de ROMS_DIR
function safeRomPath(name) {
  const base = path.basename(decodeURIComponent(name));
  return path.join(ROMS_DIR, base);
}

// ---- Handlers ----

function listRoms(res) {
  let entries;
  try {
    entries = fs.readdirSync(ROMS_DIR, { withFileTypes: true });
  } catch {
    return sendJSON(res, 500, { error: "No se pudo leer la carpeta roms" });
  }
  const roms = entries
    .filter((e) => e.isFile() && !e.name.startsWith("."))
    .map((e) => {
      const sys = getSystemForFile(e.name);
      if (!sys) return null;
      const stat = fs.statSync(path.join(ROMS_DIR, e.name));
      return {
        file: e.name,
        name: path.basename(e.name, path.extname(e.name)),
        core: sys.core,
        label: sys.label,
        platform: sys.platform,
        sizeMB: +(stat.size / (1024 * 1024)).toFixed(2),
        url: `/roms/${encodeURIComponent(e.name)}`,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.name.localeCompare(b.name));
  sendJSON(res, 200, { count: roms.length, roms });
}

// Subida: el cliente envia los bytes crudos del archivo en el body,
// y el nombre en ?name=. Se transmite directo a disco (soporta archivos grandes).
function uploadRom(req, res, query) {
  const name = query.get("name");
  if (!name) return sendJSON(res, 400, { error: "Falta el parametro name" });
  const sys = getSystemForFile(name);
  if (!sys) return sendJSON(res, 415, { error: "Extension no soportada" });

  const target = safeRomPath(name);
  const ws = fs.createWriteStream(target);
  req.pipe(ws);
  ws.on("finish", () => sendJSON(res, 200, { ok: true, file: path.basename(target), ...sys }));
  ws.on("error", () => sendJSON(res, 500, { error: "Error al guardar el archivo" }));
  req.on("error", () => {
    ws.destroy();
    sendJSON(res, 500, { error: "Error durante la subida" });
  });
}

function deleteRom(res, fileParam) {
  const target = safeRomPath(fileParam);
  if (!fs.existsSync(target)) return sendJSON(res, 404, { error: "No existe" });
  try {
    fs.unlinkSync(target);
    sendJSON(res, 200, { ok: true });
  } catch {
    sendJSON(res, 500, { error: "No se pudo eliminar" });
  }
}

// Sirve un archivo con soporte de Range (necesario para discos grandes / seeking)
function serveFile(req, res, filePath) {
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("404 No encontrado");
    }
    const type = MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream";
    const range = req.headers.range;

    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      let start = m && m[1] ? parseInt(m[1], 10) : 0;
      let end = m && m[2] ? parseInt(m[2], 10) : stat.size - 1;
      if (isNaN(start) || start < 0) start = 0;
      if (isNaN(end) || end >= stat.size) end = stat.size - 1;
      if (start > end) {
        res.writeHead(416, { "Content-Range": `bytes */${stat.size}` });
        return res.end();
      }
      res.writeHead(206, {
        "Content-Range": `bytes ${start}-${end}/${stat.size}`,
        "Accept-Ranges": "bytes",
        "Content-Length": end - start + 1,
        "Content-Type": type,
      });
      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        "Content-Length": stat.size,
        "Content-Type": type,
        "Accept-Ranges": "bytes",
      });
      fs.createReadStream(filePath).pipe(res);
    }
  });
}

// ---- Router ----

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = decodeURIComponent(url.pathname);

  // API
  if (pathname === "/api/roms" && req.method === "GET") return listRoms(res);
  if (pathname === "/api/upload" && req.method === "POST")
    return uploadRom(req, res, url.searchParams);
  if (pathname.startsWith("/api/roms/") && req.method === "DELETE")
    return deleteRom(res, pathname.slice("/api/roms/".length));

  // ROMs
  if (pathname.startsWith("/roms/") && req.method === "GET") {
    return serveFile(req, res, safeRomPath(pathname.slice("/roms/".length)));
  }

  // Frontend estatico (solo GET)
  if (req.method === "GET") {
    let rel = pathname === "/" ? "/index.html" : pathname;
    const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
    if (!filePath.startsWith(PUBLIC_DIR)) {
      res.writeHead(403);
      return res.end("Prohibido");
    }
    return serveFile(req, res, filePath);
  }

  res.writeHead(404);
  res.end("404");
});

server.listen(PORT, () => {
  console.log(`\n  🎮  Emulador web corriendo en  http://localhost:${PORT}`);
  console.log(`  📁  Coloca tus ROMs en:        ${ROMS_DIR}\n`);
});
