"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || "0.0.0.0";

// Cuando se empaqueta con `pkg`, los assets estan dentro del binario (__dirname)
// pero los datos del usuario (roms/saves/bios) deben vivir JUNTO al .exe.
const IS_PKG = typeof process.pkg !== "undefined";
const ASSET_DIR = __dirname; // public/ va embebido en el binario
const DATA_DIR = IS_PKG ? path.dirname(process.execPath) : __dirname;

const PUBLIC_DIR = path.join(ASSET_DIR, "public");
const ROMS_DIR = path.join(DATA_DIR, "roms");
const SAVES_DIR = path.join(DATA_DIR, "saves");
const BIOS_DIR = path.join(DATA_DIR, "bios");

for (const dir of [ROMS_DIR, SAVES_DIR, BIOS_DIR]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

/**
 * Mapa de extensiones -> info de consola.
 * "core" es el identificador del nucleo de EmulatorJS.
 * Doc: https://emulatorjs.org/docs/systems
 */
const SYSTEMS = {
  nes: { core: "nes", label: "NES", platform: "Nintendo" },
  fds: { core: "nes", label: "Famicom Disk", platform: "Nintendo" },
  sfc: { core: "snes", label: "SNES", platform: "Nintendo" },
  smc: { core: "snes", label: "SNES", platform: "Nintendo" },
  n64: { core: "n64", label: "Nintendo 64", platform: "Nintendo" },
  z64: { core: "n64", label: "Nintendo 64", platform: "Nintendo" },
  v64: { core: "n64", label: "Nintendo 64", platform: "Nintendo" },
  gb: { core: "gb", label: "Game Boy", platform: "Nintendo" },
  gbc: { core: "gb", label: "Game Boy Color", platform: "Nintendo" },
  gba: { core: "gba", label: "Game Boy Advance", platform: "Nintendo" },
  nds: { core: "nds", label: "Nintendo DS", platform: "Nintendo" },

  bin: { core: "psx", label: "PlayStation", platform: "Sony" },
  cue: { core: "psx", label: "PlayStation", platform: "Sony" },
  pbp: { core: "psx", label: "PlayStation", platform: "Sony" },
  chd: { core: "psx", label: "PlayStation", platform: "Sony" },
  img: { core: "psx", label: "PlayStation", platform: "Sony" },
  iso: { core: "psx", label: "PlayStation", platform: "Sony" },

  md: { core: "segaMD", label: "Mega Drive / Genesis", platform: "Sega" },
  gen: { core: "segaMD", label: "Mega Drive / Genesis", platform: "Sega" },
  smd: { core: "segaMD", label: "Mega Drive / Genesis", platform: "Sega" },
  sms: { core: "segaMS", label: "Master System", platform: "Sega" },
  gg: { core: "segaGG", label: "Game Gear", platform: "Sega" },
  sat: { core: "segaSaturn", label: "Sega Saturn", platform: "Sega" },

  a26: { core: "atari2600", label: "Atari 2600", platform: "Atari" },
  zip: { core: "arcade", label: "Arcade (MAME/FBNeo)", platform: "Arcade" },
};

const IMG_EXT = new Set([".png", ".jpg", ".jpeg", ".webp", ".gif"]);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

function getSystemForFile(filename) {
  const ext = path.extname(filename).slice(1).toLowerCase();
  return SYSTEMS[ext] || null;
}

function sendJSON(res, status, obj) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

function safePath(dir, name) {
  const base = path.basename(decodeURIComponent(name));
  return path.join(dir, base);
}

// Busca una caratula junto a la ROM (mismo nombre, extension de imagen)
function findCover(romFile) {
  const baseNoExt = path.basename(romFile, path.extname(romFile));
  for (const ext of IMG_EXT) {
    const candidate = path.join(ROMS_DIR, baseNoExt + ext);
    if (fs.existsSync(candidate)) {
      return `/roms/${encodeURIComponent(baseNoExt + ext)}`;
    }
  }
  return null;
}

// ---------- Handlers ----------

function listRoms(res) {
  let entries;
  try {
    entries = fs.readdirSync(ROMS_DIR, { withFileTypes: true });
  } catch {
    return sendJSON(res, 500, { error: "No se pudo leer la carpeta roms" });
  }
  const roms = entries
    .filter((e) => e.isFile() && !e.name.startsWith("."))
    .map((e) => {
      const sys = getSystemForFile(e.name);
      if (!sys) return null;
      const stat = fs.statSync(path.join(ROMS_DIR, e.name));
      return {
        file: e.name,
        name: path.basename(e.name, path.extname(e.name)),
        core: sys.core,
        label: sys.label,
        platform: sys.platform,
        sizeMB: +(stat.size / (1024 * 1024)).toFixed(2),
        added: stat.mtimeMs,
        cover: findCover(e.name),
        url: `/roms/${encodeURIComponent(e.name)}`,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.name.localeCompare(b.name));
  sendJSON(res, 200, { count: roms.length, roms });
}

// Subida por body crudo (?name=archivo). Se transmite directo a disco.
function uploadTo(targetDir, req, res, query, validate) {
  const name = query.get("name");
  if (!name) return sendJSON(res, 400, { error: "Falta el parametro name" });
  if (validate && !validate(name)) {
    return sendJSON(res, 415, { error: "Tipo de archivo no soportado" });
  }
  const target = safePath(targetDir, name);
  const ws = fs.createWriteStream(target);
  req.pipe(ws);
  ws.on("finish", () => sendJSON(res, 200, { ok: true, file: path.basename(target) }));
  ws.on("error", () => sendJSON(res, 500, { error: "Error al guardar" }));
  req.on("error", () => {
    ws.destroy();
    sendJSON(res, 500, { error: "Error durante la subida" });
  });
}

function deleteRom(res, fileParam) {
  const target = safePath(ROMS_DIR, fileParam);
  if (!fs.existsSync(target)) return sendJSON(res, 404, { error: "No existe" });
  try {
    fs.unlinkSync(target);
    sendJSON(res, 200, { ok: true });
  } catch {
    sendJSON(res, 500, { error: "No se pudo eliminar" });
  }
}

function listBios(res) {
  let files = [];
  try {
    files = fs.readdirSync(BIOS_DIR).filter((f) => !f.startsWith("."));
  } catch {}
  sendJSON(res, 200, { bios: files });
}

function serveFile(req, res, filePath) {
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("404 No encontrado");
    }
    const type = MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream";
    const range = req.headers.range;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      let start = m && m[1] ? parseInt(m[1], 10) : 0;
      let end = m && m[2] ? parseInt(m[2], 10) : stat.size - 1;
      if (isNaN(start) || start < 0) start = 0;
      if (isNaN(end) || end >= stat.size) end = stat.size - 1;
      if (start > end) {
        res.writeHead(416, { "Content-Range": `bytes */${stat.size}` });
        return res.end();
      }
      res.writeHead(206, {
        "Content-Range": `bytes ${start}-${end}/${stat.size}`,
        "Accept-Ranges": "bytes",
        "Content-Length": end - start + 1,
        "Content-Type": type,
      });
      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        "Content-Length": stat.size,
        "Content-Type": type,
        "Accept-Ranges": "bytes",
      });
      fs.createReadStream(filePath).pipe(res);
    }
  });
}

// ---------- Router ----------

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = decodeURIComponent(url.pathname);
  const q = url.searchParams;

  if (pathname === "/api/health" && req.method === "GET")
    return sendJSON(res, 200, { ok: true, uptime: process.uptime(), packaged: IS_PKG });
  if (pathname === "/api/roms" && req.method === "GET") return listRoms(res);
  if (pathname === "/api/upload" && req.method === "POST")
    return uploadTo(ROMS_DIR, req, res, q, (n) => !!getSystemForFile(n));
  if (pathname.startsWith("/api/roms/") && req.method === "DELETE")
    return deleteRom(res, pathname.slice("/api/roms/".length));
  if (pathname === "/api/bios" && req.method === "GET") return listBios(res);
  if (pathname === "/api/bios" && req.method === "POST")
    return uploadTo(BIOS_DIR, req, res, q);

  if (pathname.startsWith("/roms/") && req.method === "GET")
    return serveFile(req, res, safePath(ROMS_DIR, pathname.slice("/roms/".length)));
  if (pathname.startsWith("/bios/") && req.method === "GET")
    return serveFile(req, res, safePath(BIOS_DIR, pathname.slice("/bios/".length)));

  if (req.method === "GET") {
    const rel = pathname === "/" ? "/index.html" : pathname;
    const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
    if (!filePath.startsWith(PUBLIC_DIR)) {
      res.writeHead(403);
      return res.end("Prohibido");
    }
    return serveFile(req, res, filePath);
  }

  res.writeHead(404);
  res.end("404");
});

function lanAddresses() {
  const nets = os.networkInterfaces();
  const out = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === "IPv4" && !net.internal) out.push(net.address);
    }
  }
  return out;
}

server.listen(PORT, HOST, () => {
  console.log("\n  \x1b[35m🎮  RetroDeck — Emulador web\x1b[0m");
  console.log("  ──────────────────────────────────────────");
  console.log(`  Local:    http://localhost:${PORT}`);
  for (const ip of lanAddresses()) {
    console.log(`  Red/LAN:  http://${ip}:${PORT}`);
  }
  console.log("  ──────────────────────────────────────────");
  console.log(`  📁 ROMs:  ${ROMS_DIR}`);
  console.log(`  💾 Saves: ${SAVES_DIR}`);
  console.log(`  🔧 BIOS:  ${BIOS_DIR}`);
  console.log("\n  Pulsa Ctrl+C para detener.\n");
});
