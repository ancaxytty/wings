// Configuracion de PM2 para mantener RetroDeck activo 24/7.
// Uso:
//   npm i -g pm2
//   pm2 start ecosystem.config.cjs
//   pm2 save && pm2 startup   (arranque automatico al encender el equipo)
module.exports = {
  apps: [
    {
      name: "retrodeck",
      script: "server.js",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "300M",
      env: {
        PORT: 3000,
        HOST: "0.0.0.0",
      },
    },
  ],
};
