// Iconos por plataforma para las tarjetas
const PLATFORM_ICON = {
  Nintendo: "🍄",
  Sony: "🎯",
  Sega: "🦔",
  Atari: "👾",
  Arcade: "🕹️",
};

let allRoms = [];
let activeFilter = "Todos";
let activeSearch = "";

const grid = document.getElementById("grid");
const statusEl = document.getElementById("status");
const filtersEl = document.getElementById("filters");
const searchEl = document.getElementById("search");

async function loadRoms() {
  statusEl.textContent = "Cargando biblioteca...";
  try {
    const res = await fetch("/api/roms");
    const data = await res.json();
    allRoms = data.roms || [];
    renderFilters();
    render();
  } catch (err) {
    statusEl.textContent = "❌ No se pudo conectar con el servidor.";
  }
}

function renderFilters() {
  const platforms = ["Todos", ...new Set(allRoms.map((r) => r.platform))];
  filtersEl.innerHTML = "";
  platforms.forEach((p) => {
    const chip = document.createElement("button");
    chip.className = "chip" + (p === activeFilter ? " active" : "");
    chip.textContent = p;
    chip.onclick = () => {
      activeFilter = p;
      renderFilters();
      render();
    };
    filtersEl.appendChild(chip);
  });
}

function render() {
  const filtered = allRoms.filter((r) => {
    const okPlatform = activeFilter === "Todos" || r.platform === activeFilter;
    const okSearch = r.name.toLowerCase().includes(activeSearch.toLowerCase());
    return okPlatform && okSearch;
  });

  if (allRoms.length === 0) {
    grid.innerHTML = "";
    statusEl.innerHTML = "";
    grid.innerHTML = `
      <div class="empty" style="grid-column: 1 / -1;">
        <h2>📂 Tu biblioteca está vacía</h2>
        <p>Sube una ROM con el botón <strong>⬆️ Subir ROM</strong> o coloca tus archivos en la carpeta <code>roms/</code> y pulsa <strong>🔄 Recargar</strong>.</p>
        <p style="margin-top:14px">Formatos: <code>.nes .sfc .n64 .gb .gbc .gba .nds .bin/.cue (PS1) .md .sms .gg .a26 .zip</code></p>
      </div>`;
    return;
  }

  statusEl.textContent = `${filtered.length} juego(s)`;
  grid.innerHTML = "";

  filtered.forEach((rom) => {
    const card = document.createElement("div");
    card.className = "card";
    card.onclick = () => launch(rom);
    card.innerHTML = `
      <button class="del" title="Eliminar">🗑️</button>
      <div class="thumb">${PLATFORM_ICON[rom.platform] || "🎮"}</div>
      <div class="meta">
        <div class="title" title="${rom.name}">${rom.name}</div>
        <div class="sub">
          <span class="badge">${rom.label}</span>
          <span>${rom.sizeMB} MB</span>
        </div>
      </div>`;
    card.querySelector(".del").onclick = (e) => {
      e.stopPropagation();
      deleteRom(rom);
    };
    grid.appendChild(card);
  });
}

function launch(rom) {
  const params = new URLSearchParams({
    core: rom.core,
    rom: rom.url,
    name: rom.name,
  });
  window.location.href = `/play.html?${params.toString()}`;
}

async function deleteRom(rom) {
  if (!confirm(`¿Eliminar "${rom.name}"? Esto borra el archivo de la carpeta roms/.`)) return;
  try {
    const res = await fetch(`/api/roms/${encodeURIComponent(rom.file)}`, { method: "DELETE" });
    if (!res.ok) throw new Error();
    toast(`Eliminado: ${rom.name}`);
    loadRoms();
  } catch {
    toast("No se pudo eliminar", true);
  }
}

async function uploadFiles(files) {
  for (const file of files) {
    toast(`Subiendo ${file.name}...`);
    try {
      const res = await fetch(`/api/upload?name=${encodeURIComponent(file.name)}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: file,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error");
      toast(`✅ ${file.name} añadido (${data.label})`);
    } catch (err) {
      toast(`❌ ${file.name}: ${err.message}`, true);
    }
  }
  loadRoms();
}

let toastTimer;
function toast(msg, isError = false) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast"), 3200);
}

// Eventos
document.getElementById("reloadBtn").onclick = loadRoms;
document.getElementById("fileInput").onchange = (e) => uploadFiles([...e.target.files]);
searchEl.oninput = (e) => {
  activeSearch = e.target.value;
  render();
};

loadRoms();
