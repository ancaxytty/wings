"use strict";

// Monograma corto por plataforma (sin emojis)
const PLATFORM_MONO = {
  Nintendo: "NIN",
  Sony: "PS",
  Sega: "SEGA",
  Atari: "ATARI",
  Arcade: "ARC",
};

// Iconos SVG reutilizables
const ICON = {
  play: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg>',
  gamepad:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="11" x2="10" y2="11"/><line x1="8" y1="9" x2="8" y2="13"/><line x1="15" y1="12" x2="15.01" y2="12"/><line x1="18" y1="10" x2="18.01" y2="10"/><rect x="2" y="6" width="20" height="12" rx="2"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  bullet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
  folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
  warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
};

const HELP_ITEMS = [
  "Anadir juegos: boton Subir ROM, o copia archivos a la carpeta roms/ y pulsa recargar.",
  "PlayStation 1: sube el .cue y el .bin juntos (o un .chd). Para mejor compatibilidad, sube la BIOS en Ajustes.",
  "Caratulas: pon una imagen con el mismo nombre que la ROM (ej. Zelda.png) junto al archivo.",
  "Controles: teclado o mando USB/Bluetooth. El menu inferior del emulador permite guardar estados y remapear.",
  "PS2 y PSP no son viables en navegador; usa PCSX2 o PPSSPP de escritorio.",
];

// ---------- Estado ----------
const store = {
  get favorites() { return JSON.parse(localStorage.getItem("rd_favorites") || "[]"); },
  set favorites(v) { localStorage.setItem("rd_favorites", JSON.stringify(v)); },
  get recent() { return JSON.parse(localStorage.getItem("rd_recent") || "[]"); },
  set recent(v) { localStorage.setItem("rd_recent", JSON.stringify(v)); },
  get settings() {
    return JSON.parse(
      localStorage.getItem("rd_settings") ||
        '{"fullscreen":false,"smoothing":false,"rewind":false,"volume":0.5,"fastForward":3,"shader":"disabled","saveSlot":1,"accent":"#6c8cff"}'
    );
  },
  set settings(v) { localStorage.setItem("rd_settings", JSON.stringify(v)); },
};

let allRoms = [];
let currentView = "all";
let currentPlatform = null;
let searchTerm = "";
let selectedRom = null;

const $ = (id) => document.getElementById(id);
const grid = $("grid");
const emptyState = $("emptyState");
const viewTitle = $("viewTitle");
const viewCount = $("viewCount");

// ---------- Init ----------
applyAccent(store.settings.accent);
buildHelp();
loadRoms();
loadBios();
wireEvents();

function buildHelp() {
  $("helpList").innerHTML = HELP_ITEMS.map((t) => `<li>${ICON.bullet}${esc(t)}</li>`).join("");
}

function mono(platform) {
  return `<span class="thumb-mono">${PLATFORM_MONO[platform] || "GAME"}</span>`;
}

async function loadRoms() {
  try {
    const res = await fetch("/api/roms");
    const data = await res.json();
    allRoms = data.roms || [];
    buildPlatformNav();
    render();
  } catch {
    grid.innerHTML = "";
    emptyState.innerHTML = `<div class="empty"><div class="big">${ICON.warn}</div><h3>Sin conexion con el servidor</h3><p>Esta corriendo <code>node server.js</code>?</p></div>`;
  }
}

function buildPlatformNav() {
  const nav = $("platformNav");
  const platforms = [...new Set(allRoms.map((r) => r.platform))].sort();
  nav.innerHTML = "";
  platforms.forEach((p) => {
    const btn = document.createElement("button");
    btn.className = "nav-item";
    btn.dataset.platform = p;
    const n = allRoms.filter((r) => r.platform === p).length;
    btn.innerHTML = `${ICON.gamepad}<span>${esc(p)}</span><span class="count">${n}</span>`;
    btn.onclick = () => {
      currentView = "platform";
      currentPlatform = p;
      setActiveNav(btn);
      render();
    };
    nav.appendChild(btn);
  });
}

function setActiveNav(el) {
  document.querySelectorAll(".nav-item").forEach((n) => n.classList.remove("active"));
  if (el) el.classList.add("active");
}

function visibleRoms() {
  let list = allRoms;
  if (currentView === "favorites") {
    const favs = store.favorites;
    list = allRoms.filter((r) => favs.includes(r.file));
  } else if (currentView === "recent") {
    const recent = store.recent;
    list = recent.map((f) => allRoms.find((r) => r.file === f)).filter(Boolean);
  } else if (currentView === "platform") {
    list = allRoms.filter((r) => r.platform === currentPlatform);
  }
  if (searchTerm) {
    list = list.filter((r) => r.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }
  return list;
}

function render() {
  const titles = {
    all: "Todos los juegos",
    favorites: "Favoritos",
    recent: "Jugados recientemente",
    platform: currentPlatform,
  };
  viewTitle.textContent = titles[currentView] || "Juegos";

  const list = visibleRoms();
  viewCount.textContent = list.length;
  grid.innerHTML = "";
  emptyState.innerHTML = "";

  if (allRoms.length === 0) {
    emptyState.innerHTML = `
      <div class="empty">
        <div class="big">${ICON.folder}</div>
        <h3>Tu biblioteca esta vacia</h3>
        <p>Pulsa <b>Subir ROM</b> o copia archivos a la carpeta <code>roms/</code> y recarga.</p>
        <p>Formatos: <code>.nes .sfc .n64 .gb .gbc .gba .nds .bin/.cue (PS1) .md .sms .gg .a26 .zip</code></p>
      </div>`;
    return;
  }
  if (list.length === 0) {
    emptyState.innerHTML = `<div class="empty"><div class="big">${ICON.search}</div><h3>Nada por aqui</h3><p>No hay juegos que coincidan con esta vista o busqueda.</p></div>`;
    return;
  }

  const favs = store.favorites;
  list.forEach((rom) => {
    const card = document.createElement("div");
    card.className = "card";
    const isFav = favs.includes(rom.file);
    card.innerHTML = `
      ${isFav ? `<span class="fav-star">${ICON.star}</span>` : ""}
      <div class="thumb">
        ${rom.cover ? `<img src="${rom.cover}" alt="">` : mono(rom.platform)}
        <div class="play-overlay">${ICON.play}</div>
      </div>
      <div class="meta">
        <div class="title" title="${esc(rom.name)}">${esc(rom.name)}</div>
        <div class="sub"><span class="badge">${esc(rom.label)}</span><span>${rom.sizeMB} MB</span></div>
      </div>`;
    card.onclick = () => openDetail(rom);
    grid.appendChild(card);
  });
}

// ---------- Detalle ----------
function openDetail(rom) {
  selectedRom = rom;
  const isFav = store.favorites.includes(rom.file);
  $("modalBadge").textContent = rom.label;
  $("modalTitle").textContent = rom.name;
  $("modalSub").textContent = `${rom.platform} - ${rom.sizeMB} MB - ${rom.file}`;
  $("modalCover").innerHTML = rom.cover ? `<img src="${rom.cover}" alt="">` : mono(rom.platform);
  $("modalFav").textContent = isFav ? "Quitar de favoritos" : "Favorito";
  $("detailModal").hidden = false;
}

function launch(rom) {
  const recent = store.recent.filter((f) => f !== rom.file);
  recent.unshift(rom.file);
  store.recent = recent.slice(0, 24);

  const s = store.settings;
  const params = new URLSearchParams({
    core: rom.core,
    rom: rom.url,
    name: rom.name,
    fullscreen: s.fullscreen ? "1" : "0",
    smoothing: s.smoothing ? "1" : "0",
  });
  location.href = `/play.html?${params.toString()}`;
}

async function deleteRom(rom) {
  if (!confirm(`Eliminar "${rom.name}"? Se borrara el archivo de roms/.`)) return;
  try {
    const res = await fetch(`/api/roms/${encodeURIComponent(rom.file)}`, { method: "DELETE" });
    if (!res.ok) throw new Error();
    store.favorites = store.favorites.filter((f) => f !== rom.file);
    store.recent = store.recent.filter((f) => f !== rom.file);
    toast(`Eliminado: ${rom.name}`);
    $("detailModal").hidden = true;
    loadRoms();
  } catch {
    toast("No se pudo eliminar", true);
  }
}

function toggleFav(rom) {
  let favs = store.favorites;
  if (favs.includes(rom.file)) favs = favs.filter((f) => f !== rom.file);
  else favs.push(rom.file);
  store.favorites = favs;
  openDetail(rom);
  render();
}

// ---------- Subidas ----------
async function uploadRoms(files) {
  for (const file of files) {
    toast(`Subiendo ${file.name}...`);
    try {
      const res = await fetch(`/api/upload?name=${encodeURIComponent(file.name)}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: file,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error");
      toast(`Anadido: ${file.name}`);
    } catch (err) {
      toast(`${file.name}: ${err.message}`, true);
    }
  }
  loadRoms();
}

async function uploadBios(file) {
  toast(`Subiendo BIOS ${file.name}...`);
  try {
    const res = await fetch(`/api/bios?name=${encodeURIComponent(file.name)}`, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: file,
    });
    if (!res.ok) throw new Error();
    toast("BIOS anadida");
    loadBios();
  } catch {
    toast("No se pudo subir la BIOS", true);
  }
}

async function loadBios() {
  try {
    const res = await fetch("/api/bios");
    const data = await res.json();
    const el = $("biosList");
    if (!el) return;
    if (data.bios && data.bios.length) {
      el.innerHTML = data.bios.map((b) => `<div class="ok">${ICON.check}<span>${esc(b)}</span></div>`).join("");
      localStorage.setItem("rd_bios", data.bios[0]);
    } else {
      el.innerHTML = "Sin BIOS (PS1 funcionara en modo HLE).";
      localStorage.removeItem("rd_bios");
    }
  } catch {}
}

// ---------- Ajustes ----------
function applyAccent(color) {
  document.documentElement.style.setProperty("--accent", color);
}

function openSettings() {
  const s = store.settings;
  $("setFullscreen").checked = !!s.fullscreen;
  $("setSmoothing").checked = !!s.smoothing;
  $("setRewind").checked = !!s.rewind;
  $("setVolume").value = Math.round((s.volume != null ? s.volume : 0.5) * 100);
  $("volVal").textContent = $("setVolume").value + "%";
  $("setFastForward").value = String(s.fastForward != null ? s.fastForward : 3);
  $("setShader").value = s.shader || "disabled";
  $("setSaveSlot").value = String(s.saveSlot || 1);
  $("setAccent").value = s.accent || "#6c8cff";
  $("settingsModal").hidden = false;
}

function saveSettings() {
  const s = {
    fullscreen: $("setFullscreen").checked,
    smoothing: $("setSmoothing").checked,
    rewind: $("setRewind").checked,
    volume: parseInt($("setVolume").value, 10) / 100,
    fastForward: parseInt($("setFastForward").value, 10),
    shader: $("setShader").value,
    saveSlot: parseInt($("setSaveSlot").value, 10),
    accent: $("setAccent").value,
  };
  store.settings = s;
  $("volVal").textContent = $("setVolume").value + "%";
  applyAccent(s.accent);
}

// ---------- Utils ----------
function esc(str) {
  return String(str).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}
let toastTimer;
function toast(msg, isError = false) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast"), 3200);
}

// ---------- Eventos ----------
function wireEvents() {
  $("nav").querySelectorAll(".nav-item").forEach((btn) => {
    btn.onclick = () => {
      currentView = btn.dataset.view;
      currentPlatform = null;
      setActiveNav(btn);
      render();
    };
  });

  $("search").oninput = (e) => { searchTerm = e.target.value; render(); };
  $("reloadBtn").onclick = () => { loadRoms(); toast("Biblioteca recargada"); };
  $("fileInput").onchange = (e) => uploadRoms([...e.target.files]);
  $("biosInput").onchange = (e) => e.target.files[0] && uploadBios(e.target.files[0]);

  $("detailClose").onclick = () => ($("detailModal").hidden = true);
  $("modalPlay").onclick = () => selectedRom && launch(selectedRom);
  $("modalFav").onclick = () => selectedRom && toggleFav(selectedRom);
  $("modalDelete").onclick = () => selectedRom && deleteRom(selectedRom);

  $("settingsBtn").onclick = openSettings;
  $("settingsClose").onclick = () => ($("settingsModal").hidden = true);
  ["setFullscreen", "setSmoothing", "setRewind", "setFastForward", "setShader", "setSaveSlot", "setAccent"].forEach(
    (id) => ($(id).onchange = saveSettings)
  );
  $("setVolume").oninput = saveSettings;
  $("helpBtn").onclick = () => ($("helpModal").hidden = false);
  $("helpClose").onclick = () => ($("helpModal").hidden = true);

  document.querySelectorAll(".modal-backdrop").forEach((m) => {
    m.onclick = (e) => { if (e.target === m) m.hidden = true; };
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") document.querySelectorAll(".modal-backdrop").forEach((m) => (m.hidden = true));
  });

  $("menuToggle").onclick = () => $("sidebar").classList.toggle("open");
}
