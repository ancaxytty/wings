"use strict";

const PLATFORM_ICON = {
  Nintendo: "🍄",
  Sony: "🎯",
  Sega: "🦔",
  Atari: "👾",
  Arcade: "🕹️",
};

// ---------- Estado ----------
const store = {
  get favorites() {
    return JSON.parse(localStorage.getItem("rd_favorites") || "[]");
  },
  set favorites(v) {
    localStorage.setItem("rd_favorites", JSON.stringify(v));
  },
  get recent() {
    return JSON.parse(localStorage.getItem("rd_recent") || "[]");
  },
  set recent(v) {
    localStorage.setItem("rd_recent", JSON.stringify(v));
  },
  get settings() {
    return JSON.parse(
      localStorage.getItem("rd_settings") ||
        '{"fullscreen":false,"smoothing":false,"accent":"#7c5cff"}'
    );
  },
  set settings(v) {
    localStorage.setItem("rd_settings", JSON.stringify(v));
  },
};

let allRoms = [];
let currentView = "all";
let currentPlatform = null;
let searchTerm = "";
let selectedRom = null;

// ---------- Refs ----------
const $ = (id) => document.getElementById(id);
const grid = $("grid");
const emptyState = $("emptyState");
const viewTitle = $("viewTitle");
const viewCount = $("viewCount");

// ---------- Init ----------
applyAccent(store.settings.accent);
loadRoms();
loadBios();
wireEvents();

async function loadRoms() {
  try {
    const res = await fetch("/api/roms");
    const data = await res.json();
    allRoms = data.roms || [];
    buildPlatformNav();
    render();
  } catch {
    grid.innerHTML = "";
    emptyState.innerHTML = `<div class="empty"><div class="big">⚠️</div><h3>Sin conexión con el servidor</h3><p>¿Está corriendo <code>node server.js</code>?</p></div>`;
  }
}

function buildPlatformNav() {
  const nav = $("platformNav");
  const platforms = [...new Set(allRoms.map((r) => r.platform))].sort();
  nav.innerHTML = "";
  platforms.forEach((p) => {
    const btn = document.createElement("button");
    btn.className = "nav-item";
    btn.dataset.platform = p;
    const n = allRoms.filter((r) => r.platform === p).length;
    btn.innerHTML = `<span class="ic">${PLATFORM_ICON[p] || "🎮"}</span> ${p} <span style="margin-left:auto;font-size:12px;color:var(--text-faint)">${n}</span>`;
    btn.onclick = () => {
      currentView = "platform";
      currentPlatform = p;
      setActiveNav(btn);
      render();
    };
    nav.appendChild(btn);
  });
}

function setActiveNav(el) {
  document.querySelectorAll(".nav-item").forEach((n) => n.classList.remove("active"));
  if (el) el.classList.add("active");
}

function visibleRoms() {
  let list = allRoms;
  if (currentView === "favorites") {
    const favs = store.favorites;
    list = allRoms.filter((r) => favs.includes(r.file));
  } else if (currentView === "recent") {
    const recent = store.recent;
    list = recent.map((f) => allRoms.find((r) => r.file === f)).filter(Boolean);
  } else if (currentView === "platform") {
    list = allRoms.filter((r) => r.platform === currentPlatform);
  }
  if (searchTerm) {
    list = list.filter((r) => r.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }
  return list;
}

function render() {
  const titles = {
    all: "Todos los juegos",
    favorites: "Favoritos",
    recent: "Jugados recientemente",
    platform: currentPlatform,
  };
  viewTitle.textContent = titles[currentView] || "Juegos";

  const list = visibleRoms();
  viewCount.textContent = list.length;
  grid.innerHTML = "";
  emptyState.innerHTML = "";

  if (allRoms.length === 0) {
    emptyState.innerHTML = `
      <div class="empty">
        <div class="big">📂</div>
        <h3>Tu biblioteca está vacía</h3>
        <p>Pulsa <b>⬆️ Subir ROM</b> o copia archivos a la carpeta <code>roms/</code> y recarga.</p>
        <p>Formatos: <code>.nes .sfc .n64 .gb .gbc .gba .nds .bin/.cue (PS1) .md .sms .gg .a26 .zip</code></p>
      </div>`;
    return;
  }
  if (list.length === 0) {
    emptyState.innerHTML = `<div class="empty"><div class="big">🔍</div><h3>Nada por aquí</h3><p>No hay juegos que coincidan con esta vista o búsqueda.</p></div>`;
    return;
  }

  const favs = store.favorites;
  list.forEach((rom) => {
    const card = document.createElement("div");
    card.className = "card";
    const isFav = favs.includes(rom.file);
    card.innerHTML = `
      ${isFav ? '<span class="fav-star">⭐</span>' : ""}
      <div class="thumb">
        ${rom.cover ? `<img src="${rom.cover}" alt="">` : PLATFORM_ICON[rom.platform] || "🎮"}
        <div class="play-overlay">▶</div>
      </div>
      <div class="meta">
        <div class="title" title="${esc(rom.name)}">${esc(rom.name)}</div>
        <div class="sub"><span class="badge">${rom.label}</span><span>${rom.sizeMB} MB</span></div>
      </div>`;
    card.onclick = () => openDetail(rom);
    grid.appendChild(card);
  });
}

// ---------- Detalle ----------
function openDetail(rom) {
  selectedRom = rom;
  const favs = store.favorites;
  const isFav = favs.includes(rom.file);
  $("modalBadge").textContent = rom.label;
  $("modalTitle").textContent = rom.name;
  $("modalSub").textContent = `${rom.platform} · ${rom.sizeMB} MB · ${rom.file}`;
  $("modalCover").innerHTML = rom.cover
    ? `<img src="${rom.cover}" alt="">`
    : PLATFORM_ICON[rom.platform] || "🎮";
  $("modalFav").innerHTML = isFav ? "★ Quitar de favoritos" : "⭐ Favorito";
  $("detailModal").hidden = false;
}

function launch(rom) {
  const recent = store.recent.filter((f) => f !== rom.file);
  recent.unshift(rom.file);
  store.recent = recent.slice(0, 24);

  const s = store.settings;
  const params = new URLSearchParams({
    core: rom.core,
    rom: rom.url,
    name: rom.name,
    fullscreen: s.fullscreen ? "1" : "0",
    smoothing: s.smoothing ? "1" : "0",
  });
  location.href = `/play.html?${params.toString()}`;
}

async function deleteRom(rom) {
  if (!confirm(`¿Eliminar "${rom.name}"? Se borrará el archivo de roms/.`)) return;
  try {
    const res = await fetch(`/api/roms/${encodeURIComponent(rom.file)}`, { method: "DELETE" });
    if (!res.ok) throw new Error();
    store.favorites = store.favorites.filter((f) => f !== rom.file);
    store.recent = store.recent.filter((f) => f !== rom.file);
    toast(`Eliminado: ${rom.name}`);
    $("detailModal").hidden = true;
    loadRoms();
  } catch {
    toast("No se pudo eliminar", true);
  }
}

function toggleFav(rom) {
  let favs = store.favorites;
  if (favs.includes(rom.file)) favs = favs.filter((f) => f !== rom.file);
  else favs.push(rom.file);
  store.favorites = favs;
  openDetail(rom);
  render();
}

// ---------- Subidas ----------
async function uploadRoms(files) {
  for (const file of files) {
    toast(`Subiendo ${file.name}...`);
    try {
      const res = await fetch(`/api/upload?name=${encodeURIComponent(file.name)}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: file,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error");
      toast(`✅ Añadido: ${file.name}`);
    } catch (err) {
      toast(`❌ ${file.name}: ${err.message}`, true);
    }
  }
  loadRoms();
}

async function uploadBios(file) {
  toast(`Subiendo BIOS ${file.name}...`);
  try {
    const res = await fetch(`/api/bios?name=${encodeURIComponent(file.name)}`, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: file,
    });
    if (!res.ok) throw new Error();
    toast(`✅ BIOS añadida`);
    loadBios();
  } catch {
    toast("No se pudo subir la BIOS", true);
  }
}

async function loadBios() {
  try {
    const res = await fetch("/api/bios");
    const data = await res.json();
    const el = $("biosList");
    if (!el) return;
    if (data.bios && data.bios.length) {
      el.innerHTML = data.bios.map((b) => `<div class="ok">✓ ${esc(b)}</div>`).join("");
      localStorage.setItem("rd_bios", data.bios[0]);
    } else {
      el.innerHTML = "Sin BIOS (PS1 funcionará en modo HLE).";
      localStorage.removeItem("rd_bios");
    }
  } catch {}
}

// ---------- Ajustes ----------
function applyAccent(color) {
  document.documentElement.style.setProperty("--accent", color);
}

function openSettings() {
  const s = store.settings;
  $("setFullscreen").checked = s.fullscreen;
  $("setSmoothing").checked = s.smoothing;
  $("setAccent").value = s.accent;
  $("settingsModal").hidden = false;
}

function saveSettings() {
  const s = {
    fullscreen: $("setFullscreen").checked,
    smoothing: $("setSmoothing").checked,
    accent: $("setAccent").value,
  };
  store.settings = s;
  applyAccent(s.accent);
}

// ---------- Utils ----------
function esc(str) {
  return String(str).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}
let toastTimer;
function toast(msg, isError = false) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast"), 3200);
}

// ---------- Eventos ----------
function wireEvents() {
  $("nav").querySelectorAll(".nav-item").forEach((btn) => {
    btn.onclick = () => {
      currentView = btn.dataset.view;
      currentPlatform = null;
      setActiveNav(btn);
      render();
    };
  });

  $("search").oninput = (e) => {
    searchTerm = e.target.value;
    render();
  };
  $("reloadBtn").onclick = () => {
    loadRoms();
    toast("Biblioteca recargada");
  };
  $("fileInput").onchange = (e) => uploadRoms([...e.target.files]);
  $("biosInput").onchange = (e) => e.target.files[0] && uploadBios(e.target.files[0]);

  // Detalle
  $("detailClose").onclick = () => ($("detailModal").hidden = true);
  $("modalPlay").onclick = () => selectedRom && launch(selectedRom);
  $("modalFav").onclick = () => selectedRom && toggleFav(selectedRom);
  $("modalDelete").onclick = () => selectedRom && deleteRom(selectedRom);

  // Ajustes / ayuda
  $("settingsBtn").onclick = openSettings;
  $("settingsClose").onclick = () => ($("settingsModal").hidden = true);
  ["setFullscreen", "setSmoothing", "setAccent"].forEach((id) => ($(id).onchange = saveSettings));
  $("helpBtn").onclick = () => ($("helpModal").hidden = false);
  $("helpClose").onclick = () => ($("helpModal").hidden = true);

  // Cerrar modales al hacer click en el fondo
  document.querySelectorAll(".modal-backdrop").forEach((m) => {
    m.onclick = (e) => {
      if (e.target === m) m.hidden = true;
    };
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") document.querySelectorAll(".modal-backdrop").forEach((m) => (m.hidden = true));
  });

  // Sidebar móvil
  $("menuToggle").onclick = () => $("sidebar").classList.toggle("open");
}
