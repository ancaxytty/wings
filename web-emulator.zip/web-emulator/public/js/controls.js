"use strict";

// Botones de consola -> indice de EmulatorJS (RetroPad) + tecla por defecto.
// Formato de EJS_defaultControls: { 0: { <index>: { value: '<tecla>' } } }
const BUTTONS = [
  { id: "up", label: "Arriba", hint: "D-Pad", idx: 4, def: "up arrow" },
  { id: "down", label: "Abajo", hint: "D-Pad", idx: 5, def: "down arrow" },
  { id: "left", label: "Izquierda", hint: "D-Pad", idx: 6, def: "left arrow" },
  { id: "right", label: "Derecha", hint: "D-Pad", idx: 7, def: "right arrow" },
  { id: "a", label: "A", hint: "Accion principal", idx: 8, def: "x" },
  { id: "b", label: "B", hint: "Accion secundaria", idx: 0, def: "z" },
  { id: "x", label: "X", hint: "Accion", idx: 9, def: "s" },
  { id: "y", label: "Y", hint: "Accion", idx: 1, def: "a" },
  { id: "l", label: "L", hint: "Gatillo izq.", idx: 10, def: "q" },
  { id: "r", label: "R", hint: "Gatillo der.", idx: 11, def: "w" },
  { id: "select", label: "Select", hint: "", idx: 2, def: "shift" },
  { id: "start", label: "Start", hint: "", idx: 3, def: "enter" },
];

// Distribucion de teclado para dibujar y resaltar
const KEYBOARD_ROWS = [
  ["esc", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
  ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
  ["a", "s", "d", "f", "g", "h", "j", "k", "l", "enter"],
  ["shift", "z", "x", "c", "v", "b", "n", "m"],
  ["space", "left arrow", "up arrow", "down arrow", "right arrow"],
];
const KEY_DISPLAY = {
  "up arrow": "UP",
  "down arrow": "DOWN",
  "left arrow": "LEFT",
  "right arrow": "RIGHT",
  enter: "Enter",
  shift: "Shift",
  space: "Space",
  esc: "Esc",
};
const WIDE_KEYS = { shift: "wide", enter: "wide", space: "xwide", esc: "wide" };

const $ = (id) => document.getElementById(id);
let mapping = loadMapping();
let listeningFor = null;

function defaults() {
  const m = {};
  BUTTONS.forEach((b) => (m[b.id] = b.def));
  return m;
}
function loadMapping() {
  try {
    const saved = JSON.parse(localStorage.getItem("rd_controls") || "null");
    if (saved && typeof saved === "object") return Object.assign(defaults(), saved);
  } catch (e) {}
  return defaults();
}

function normalizeKey(e) {
  const k = e.key;
  if (k === "ArrowUp") return "up arrow";
  if (k === "ArrowDown") return "down arrow";
  if (k === "ArrowLeft") return "left arrow";
  if (k === "ArrowRight") return "right arrow";
  if (k === " ") return "space";
  if (k === "Enter") return "enter";
  if (k === "Shift") return "shift";
  if (k === "Escape") return "esc";
  if (k === "Control") return "ctrl";
  if (k === "Alt") return "alt";
  if (k === "Tab") return "tab";
  if (k === "Backspace") return "backspace";
  return k.length === 1 ? k.toLowerCase() : k.toLowerCase();
}

function renderBinds() {
  const c = $("binds");
  c.innerHTML = "";
  BUTTONS.forEach((b) => {
    const row = document.createElement("div");
    row.className = "bind";
    row.innerHTML = `
      <div class="lbl">${b.label}${b.hint ? `<small>${b.hint}</small>` : ""}</div>
      <div class="key-chip" data-btn="${b.id}">${displayKey(mapping[b.id])}</div>`;
    const chip = row.querySelector(".key-chip");
    chip.onclick = () => startListening(b.id, chip);
    chip.onmouseenter = () => highlightGamepad(b.id, true);
    chip.onmouseleave = () => highlightGamepad(b.id, false);
    c.appendChild(row);
  });
}

function displayKey(k) {
  return KEY_DISPLAY[k] || (k ? k.toUpperCase() : "-");
}

function startListening(btnId, chip) {
  if (listeningFor) listeningFor.chip.classList.remove("listening");
  listeningFor = { btnId, chip };
  chip.classList.add("listening");
  chip.textContent = "Pulsa una tecla...";
  highlightGamepad(btnId, true);
}

function renderKeyboard() {
  const kb = $("keyboard");
  kb.innerHTML = "";
  const assigned = new Set(Object.values(mapping));
  KEYBOARD_ROWS.forEach((row) => {
    const r = document.createElement("div");
    r.className = "krow";
    row.forEach((key) => {
      const el = document.createElement("div");
      el.className = "key" + (WIDE_KEYS[key] ? " " + WIDE_KEYS[key] : "");
      if (assigned.has(key)) el.classList.add("assigned");
      el.textContent = KEY_DISPLAY[key] || key.toUpperCase();
      r.appendChild(el);
    });
    kb.appendChild(r);
  });
}

function highlightGamepad(btnId, on) {
  const el = document.getElementById("gp-" + btnId);
  if (el) el.style.fill = on ? "var(--accent)" : "var(--bg-elev)";
}

document.addEventListener("keydown", (e) => {
  if (!listeningFor) return;
  e.preventDefault();
  const key = normalizeKey(e);
  // Evita duplicados: si la tecla esta en otro boton, lo libera
  for (const b of BUTTONS) {
    if (b.id !== listeningFor.btnId && mapping[b.id] === key) mapping[b.id] = null;
  }
  mapping[listeningFor.btnId] = key;
  listeningFor.chip.classList.remove("listening");
  highlightGamepad(listeningFor.btnId, false);
  listeningFor = null;
  renderBinds();
  renderKeyboard();
});

$("saveBtn").onclick = () => {
  localStorage.setItem("rd_controls", JSON.stringify(mapping));
  toast("Controles guardados");
};
$("resetBtn").onclick = () => {
  mapping = defaults();
  localStorage.removeItem("rd_controls");
  renderBinds();
  renderKeyboard();
  toast("Valores por defecto restaurados");
};

let toastTimer;
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast"), 2600);
}

renderBinds();
renderKeyboard();
