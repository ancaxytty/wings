#!/usr/bin/env python3
"""RetroDeck - servidor en Python (sin dependencias externas).

Equivalente al server.js de Node. Sirve la interfaz web, gestiona la
biblioteca de ROMs/BIOS y entrega los archivos con soporte de Range.
Compatible con PyInstaller para generar un .exe.
"""

import json
import os
import re
import sys
import socket
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("PORT", "3000"))
HOST = os.environ.get("HOST", "0.0.0.0")

# Cuando se empaqueta con PyInstaller, los assets van dentro del binario
# (sys._MEIPASS) y los datos del usuario viven junto al ejecutable.
IS_FROZEN = getattr(sys, "frozen", False)
ASSET_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.dirname(sys.executable) if IS_FROZEN else os.path.dirname(os.path.abspath(__file__))

PUBLIC_DIR = os.path.join(ASSET_DIR, "public")
ROMS_DIR = os.path.join(DATA_DIR, "roms")
SAVES_DIR = os.path.join(DATA_DIR, "saves")
BIOS_DIR = os.path.join(DATA_DIR, "bios")

for d in (ROMS_DIR, SAVES_DIR, BIOS_DIR):
    os.makedirs(d, exist_ok=True)

# extension -> (core, label, platform)
SYSTEMS = {
    "nes": ("nes", "NES", "Nintendo"),
    "fds": ("nes", "Famicom Disk", "Nintendo"),
    "sfc": ("snes", "SNES", "Nintendo"),
    "smc": ("snes", "SNES", "Nintendo"),
    "n64": ("n64", "Nintendo 64", "Nintendo"),
    "z64": ("n64", "Nintendo 64", "Nintendo"),
    "v64": ("n64", "Nintendo 64", "Nintendo"),
    "gb": ("gb", "Game Boy", "Nintendo"),
    "gbc": ("gb", "Game Boy Color", "Nintendo"),
    "gba": ("gba", "Game Boy Advance", "Nintendo"),
    "nds": ("nds", "Nintendo DS", "Nintendo"),
    "bin": ("psx", "PlayStation", "Sony"),
    "cue": ("psx", "PlayStation", "Sony"),
    "pbp": ("psx", "PlayStation", "Sony"),
    "chd": ("psx", "PlayStation", "Sony"),
    "img": ("psx", "PlayStation", "Sony"),
    "iso": ("psx", "PlayStation", "Sony"),
    "md": ("segaMD", "Mega Drive / Genesis", "Sega"),
    "gen": ("segaMD", "Mega Drive / Genesis", "Sega"),
    "smd": ("segaMD", "Mega Drive / Genesis", "Sega"),
    "sms": ("segaMS", "Master System", "Sega"),
    "gg": ("segaGG", "Game Gear", "Sega"),
    "sat": ("segaSaturn", "Sega Saturn", "Sega"),
    "a26": ("atari2600", "Atari 2600", "Atari"),
    "zip": ("arcade", "Arcade (MAME/FBNeo)", "Arcade"),
}

IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif")

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
}


def system_for(filename):
    ext = os.path.splitext(filename)[1].lstrip(".").lower()
    return SYSTEMS.get(ext)


def safe_path(base_dir, name):
    name = os.path.basename(urllib.parse.unquote(name))
    return os.path.join(base_dir, name)


def find_cover(rom_file):
    stem = os.path.splitext(rom_file)[0]
    for ext in IMG_EXT:
        if os.path.exists(os.path.join(ROMS_DIR, stem + ext)):
            return "/roms/" + urllib.parse.quote(stem + ext)
    return None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass  # silencioso

    # -------- helpers --------
    def _json(self, status, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_file(self, path):
        if not os.path.isfile(path):
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        size = os.path.getsize(path)
        ctype = MIME.get(os.path.splitext(path)[1].lower(), "application/octet-stream")
        rng = self.headers.get("Range")
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            start = int(m.group(1)) if m and m.group(1) else 0
            end = int(m.group(2)) if m and m.group(2) else size - 1
            start = max(0, start)
            end = min(end, size - 1)
            if start > end:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.end_headers()
                return
            self.send_response(206)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            self.end_headers()
            with open(path, "rb") as f:
                f.seek(start)
                remaining = end - start + 1
                while remaining > 0:
                    chunk = f.read(min(65536, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        else:
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(size))
            self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            with open(path, "rb") as f:
                while True:
                    chunk = f.read(65536)
                    if not chunk:
                        break
                    self.wfile.write(chunk)

    def _save_body(self, target):
        length = int(self.headers.get("Content-Length", "0"))
        with open(target, "wb") as f:
            remaining = length
            while remaining > 0:
                chunk = self.rfile.read(min(65536, remaining))
                if not chunk:
                    break
                f.write(chunk)
                remaining -= len(chunk)

    # -------- routes --------
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(parsed.path)

        if path == "/api/health":
            return self._json(200, {"ok": True, "packaged": IS_FROZEN, "backend": "python"})
        if path == "/api/roms":
            return self._list_roms()
        if path == "/api/bios":
            files = [f for f in os.listdir(BIOS_DIR) if not f.startswith(".")]
            return self._json(200, {"bios": files})
        if path.startswith("/roms/"):
            return self._serve_file(safe_path(ROMS_DIR, path[len("/roms/"):]))
        if path.startswith("/bios/"):
            return self._serve_file(safe_path(BIOS_DIR, path[len("/bios/"):]))

        rel = "/index.html" if path == "/" else path
        file_path = os.path.normpath(os.path.join(PUBLIC_DIR, rel.lstrip("/")))
        if not file_path.startswith(PUBLIC_DIR):
            self.send_response(403)
            self.end_headers()
            return
        return self._serve_file(file_path)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        name = (query.get("name") or [None])[0]

        if path == "/api/upload":
            if not name:
                return self._json(400, {"error": "Falta el parametro name"})
            if not system_for(name):
                return self._json(415, {"error": "Extension no soportada"})
            self._save_body(safe_path(ROMS_DIR, name))
            return self._json(200, {"ok": True, "file": os.path.basename(name)})
        if path == "/api/bios":
            if not name:
                return self._json(400, {"error": "Falta el parametro name"})
            self._save_body(safe_path(BIOS_DIR, name))
            return self._json(200, {"ok": True, "file": os.path.basename(name)})
        self._json(404, {"error": "No encontrado"})

    def do_DELETE(self):
        path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        if path.startswith("/api/roms/"):
            target = safe_path(ROMS_DIR, path[len("/api/roms/"):])
            if not os.path.exists(target):
                return self._json(404, {"error": "No existe"})
            os.remove(target)
            return self._json(200, {"ok": True})
        self._json(404, {"error": "No encontrado"})

    def _list_roms(self):
        roms = []
        for name in os.listdir(ROMS_DIR):
            full = os.path.join(ROMS_DIR, name)
            if not os.path.isfile(full) or name.startswith("."):
                continue
            sys_info = system_for(name)
            if not sys_info:
                continue
            core, label, platform = sys_info
            size = os.path.getsize(full)
            roms.append({
                "file": name,
                "name": os.path.splitext(name)[0],
                "core": core,
                "label": label,
                "platform": platform,
                "sizeMB": round(size / (1024 * 1024), 2),
                "cover": find_cover(name),
                "url": "/roms/" + urllib.parse.quote(name),
            })
        roms.sort(key=lambda r: r["name"].lower())
        self._json(200, {"count": len(roms), "roms": roms})


def lan_addresses():
    ips = []
    try:
        host = socket.gethostname()
        for info in socket.getaddrinfo(host, None):
            ip = info[4][0]
            if "." in ip and not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except Exception:
        pass
    return ips


def main():
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print("\n  RetroDeck - Emulador web (backend Python)")
    print("  ------------------------------------------")
    print("  Local:    http://localhost:%d" % PORT)
    for ip in lan_addresses():
        print("  Red/LAN:  http://%s:%d" % (ip, PORT))
    print("  ------------------------------------------")
    print("  ROMs:  %s" % ROMS_DIR)
    print("  Saves: %s" % SAVES_DIR)
    print("  BIOS:  %s" % BIOS_DIR)
    print("\n  Pulsa Ctrl+C para detener.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Servidor detenido.")
        server.shutdown()


if __name__ == "__main__":
    main()
