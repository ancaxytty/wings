Coloca aqui tus archivos de ROM.

Usa unicamente ROMs de juegos que poseas legalmente.

Formatos soportados (se detecta la consola por la extension):

  Nintendo : .nes .fds .sfc .smc .n64 .z64 .v64 .gb .gbc .gba .nds
  Sony     : .bin .cue .pbp .chd .img .iso   (PlayStation 1)
  Sega     : .md .gen .smd .sms .gg .sat
  Atari    : .a26
  Arcade   : .zip   (sets de MAME / FBNeo)

Notas para PlayStation 1 (.bin/.cue):
  - Sube AMBOS archivos .cue y .bin (o usa un .chd / .pbp de un solo archivo).
  - Selecciona el .cue para iniciar el juego.

NO soportado en navegador: PS2, PSP y similares (necesitan emuladores
de escritorio como PCSX2 o PPSSPP por requisitos de rendimiento).
