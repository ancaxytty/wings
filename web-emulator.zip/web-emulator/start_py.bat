@echo off
title RetroDeck - Emulador Web (Python)
echo.
echo   ======================================
echo     RetroDeck - iniciando (Python)...
echo   ======================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
  echo  [ERROR] Python no esta instalado.
  echo  Descargalo desde https://python.org y vuelve a ejecutar este archivo.
  echo.
  pause
  exit /b 1
)

start "" cmd /c "timeout /t 2 >nul & start http://localhost:3000"

python server.py
pause
