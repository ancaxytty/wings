#!/usr/bin/env bash
# Genera un .exe (o binario) de RetroDeck usando el backend de Python + PyInstaller.
#
# Requisitos:
#   pip install pyinstaller
#
# En Windows ejecuta este contenido con los mismos argumentos, o usa:
#   pyinstaller --onefile --name RetroDeck --add-data "public;public" server.py
#
# En Linux/macOS el separador de --add-data es ":" en lugar de ";".
set -e

SEP=":"
case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) SEP=";" ;;
esac

pyinstaller --onefile --name RetroDeck \
  --add-data "public${SEP}public" \
  server.py

echo ""
echo "Listo. El ejecutable esta en la carpeta dist/"
echo "Colocalo donde quieras; creara las carpetas roms/ saves/ bios/ junto a el."
